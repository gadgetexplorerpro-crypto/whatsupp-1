package com.example.ui

import android.net.ConnectivityManager
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.auth.FamilyAuthSessionManager
import com.example.data.local.SavedMediaEntity
import com.example.data.local.VaultChatEntity
import com.example.data.local.VaultDao
import com.example.data.model.ConnectionEvent
import com.example.data.model.EncryptedChatMessage
import com.example.data.model.FamilyDevice
import com.example.data.model.WebRtcSignal
import com.example.data.model.SavedPlace
import com.example.data.model.SafetyAlert
import com.example.data.model.AppUsageReport
import com.example.data.repository.WhatsuppRepository
import com.example.data.security.LocalCryptoManager
import com.example.hardware.DeviceHardwareManager
import com.example.hardware.WhatsuppConnectionService
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

data class LocalDashboardState(
    val thisDeviceId: String = "",
    val thisDeviceName: String = "Android Phone",
    val thisDeviceRole: String = "CONTROLLER", // "CONTROLLER" or "CONNECTED"
    val pairingCode: String = "849201",
    val isPaired: Boolean = true,
    val autoReconnect: Boolean = true,
    val keepConnectedWhenClosed: Boolean = true,
    val selectedTargetDeviceId: String = "",
    val cameraConsentGranted: Boolean = true,
    val micConsentGranted: Boolean = true,
    val locationConsentGranted: Boolean = true,
    val activeCameraFacing: String = "OFF", // "OFF", "FRONT", "BACK"
    val isMicStreaming: Boolean = false,
    val isTwoWayVoiceActive: Boolean = false,
    val localAudioLevelDb: Int = 14,
    val batteryLevel: Int = 100,
    val isCharging: Boolean = false,
    val networkType: String = "Wi-Fi",
    val isOnline: Boolean = true,
    val latitude: Double = 37.4220,
    val longitude: Double = -122.0841,
    val locationAccuracy: Double = 5.0,
    val locationLabel: String = "Mountain View, CA",
    val statusBannerMessage: String? = null,
    val dtlsFingerprint: String = "",
    val webrtcState: String = "DTLS-SRTP Ready • Background Service Active",
    val lastHandledCommand: String = "NONE",
    val isMotionDetectionEnabled: Boolean = false,
    val motionSensitivity: String = "MEDIUM", // "LOW", "MEDIUM", "HIGH"
    val isSoundDetectionEnabled: Boolean = false,
    val soundThresholdDb: Int = 65,
    val isScreenSharingActive: Boolean = false,
    val isSosActive: Boolean = false,
    val isBedtimeActive: Boolean = false,
    val deviceModel: String = "${android.os.Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${android.os.Build.MODEL}",
    val osVersion: String = "Android ${android.os.Build.VERSION.RELEASE}"
)

@OptIn(ExperimentalCoroutinesApi::class)
class WhatsuppViewModel(
    private val repository: WhatsuppRepository,
    private val vaultDao: VaultDao,
    private val hardwareManager: DeviceHardwareManager,
    val currentUserId: String
) : ViewModel() {

    private val thisDeviceId = hardwareManager.getStableDeviceId()
    private val defaultName = hardwareManager.getDefaultDeviceName()
    private val savedConfig = FamilyAuthSessionManager.loadDeviceConfig(
        hardwareManager.appContext,
        defaultName
    )
    private val _pairingCodeFlow = MutableStateFlow(savedConfig.pairingCode)

    private val _localState = MutableStateFlow(
        LocalDashboardState(
            thisDeviceId = thisDeviceId,
            thisDeviceName = savedConfig.deviceName,
            thisDeviceRole = savedConfig.deviceRole,
            pairingCode = savedConfig.pairingCode,
            selectedTargetDeviceId = savedConfig.selectedTargetDeviceId,
            cameraConsentGranted = savedConfig.cameraConsentGranted,
            micConsentGranted = savedConfig.micConsentGranted,
            locationConsentGranted = savedConfig.locationConsentGranted,
            activeCameraFacing = if (savedConfig.cameraConsentGranted && hardwareManager.hasCameraPermission()) {
                savedConfig.activeCameraFacing
            } else {
                "OFF"
            },
            isMicStreaming = savedConfig.micConsentGranted && hardwareManager.hasMicPermission() && savedConfig.isMicStreaming,
            isTwoWayVoiceActive = savedConfig.micConsentGranted && hardwareManager.hasMicPermission() && savedConfig.isTwoWayVoiceActive,
            autoReconnect = savedConfig.autoReconnect,
            keepConnectedWhenClosed = savedConfig.keepConnectedWhenClosed,
            dtlsFingerprint = LocalCryptoManager.generateDtlsFingerprint(currentUserId, thisDeviceId)
        )
    )
    val localState: StateFlow<LocalDashboardState> = _localState.asStateFlow()

    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var lastFrameSentMs: Long = 0L
    private var lastPlayedAudioHash: Int = 0

    // Two-tier Flow error handling for Firestore streams (re-subscribes immediately when pairing code changes)
    val devicesState: StateFlow<UiState<List<FamilyDevice>>> = _pairingCodeFlow
        .flatMapLatest { repository.observeDevices(currentUserId) }
        .onEach { handleIncomingDeviceSync(it) }
        .map<List<FamilyDevice>, UiState<List<FamilyDevice>>> { UiState.Success(it) }
        .catch { error ->
            Log.w(TAG, "Error observing devices", error)
            emit(UiState.Error(error.message ?: "Failed to observe family devices"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = UiState.Loading
        )

    val signalsState: StateFlow<UiState<List<WebRtcSignal>>> = _pairingCodeFlow
        .flatMapLatest { repository.observeSignals(currentUserId) }
        .onEach { handleIncomingWebRtcSignals(it) }
        .map<List<WebRtcSignal>, UiState<List<WebRtcSignal>>> { UiState.Success(it) }
        .catch { error ->
            Log.w(TAG, "Error observing WebRTC signals", error)
            emit(UiState.Error(error.message ?: "Failed to observe WebRTC signals"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = UiState.Loading
        )

    val messagesState: StateFlow<UiState<List<EncryptedChatMessage>>> = _pairingCodeFlow
        .flatMapLatest { repository.observeMessages(currentUserId) }
        .onEach { cacheMessagesToEncryptedVault(it) }
        .map<List<EncryptedChatMessage>, UiState<List<EncryptedChatMessage>>> { UiState.Success(it) }
        .catch { error ->
            Log.w(TAG, "Error observing messages", error)
            emit(UiState.Error(error.message ?: "Failed to observe encrypted messages"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = UiState.Loading
        )

    val historyState: StateFlow<UiState<List<ConnectionEvent>>> = repository.observeHistory(currentUserId)
        .map<List<ConnectionEvent>, UiState<List<ConnectionEvent>>> { UiState.Success(it) }
        .catch { error ->
            Log.w(TAG, "Error observing connection history", error)
            emit(UiState.Error(error.message ?: "Failed to observe connection history"))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val localVaultChats: StateFlow<List<VaultChatEntity>> = vaultDao.observeEncryptedChats(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptyList()
        )

    val savedVaultMedia: StateFlow<List<SavedMediaEntity>> = vaultDao.observeSavedMedia(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptyList()
        )

    private val _savedPlaces = MutableStateFlow<List<SavedPlace>>(
        listOf(
            SavedPlace("place_1", "Home", "1600 Amphitheatre Pkwy, Mountain View", 37.4220, -122.0841, 150.0),
            SavedPlace("place_2", "School", "2000 Charleston Rd, Mountain View", 37.4190, -122.0860, 200.0)
        )
    )
    val savedPlaces: StateFlow<List<SavedPlace>> = _savedPlaces.asStateFlow()

    private val _safetyAlerts = MutableStateFlow<List<SafetyAlert>>(
        listOf(
            SafetyAlert(
                id = "alert_init",
                title = "Family Protection Armed",
                description = "All connected family devices are monitoring with verified encryption.",
                type = "SYSTEM",
                timestampMs = System.currentTimeMillis() - 120000L,
                deviceName = "Whatsupp Sentry"
            )
        )
    )
    val safetyAlerts: StateFlow<List<SafetyAlert>> = _safetyAlerts.asStateFlow()

    private val _appUsageReports = MutableStateFlow<List<AppUsageReport>>(emptyList())
    val appUsageReports: StateFlow<List<AppUsageReport>> = _appUsageReports.asStateFlow()

    init {
        isForegroundActive = true
        refreshAppUsage()
        if (savedConfig.keepConnectedWhenClosed && !savedConfig.userExplicitlyStoppedService) {
            WhatsuppConnectionService.start(hardwareManager.appContext)
        }
        observeServiceStreamControlEvents()
        initializeDeviceAndTelemetryLoop()
        // Restore active audio session if process was recreated while session was active
        if (_localState.value.isTwoWayVoiceActive) {
            toggleTwoWayVoice(true)
        } else if (_localState.value.isMicStreaming) {
            toggleMicStreaming(true)
        }
    }

    private fun observeServiceStreamControlEvents() {
        viewModelScope.launch {
            WhatsuppConnectionService.streamControlEvents.collect { action ->
                when (action) {
                    WhatsuppConnectionService.ACTION_STOP_ALL_STREAMS -> {
                        hardwareManager.stopLiveAudioCapture()
                        _localState.update {
                            it.copy(
                                activeCameraFacing = "OFF",
                                isMicStreaming = false,
                                isTwoWayVoiceActive = false,
                                webrtcState = "All Streams Stopped by User",
                                statusBannerMessage = "Active camera & audio streams stopped"
                            )
                        }
                        WhatsuppConnectionService.clearStreamControlEvent()
                    }
                    WhatsuppConnectionService.ACTION_STOP_CAMERA -> {
                        _localState.update {
                            it.copy(
                                activeCameraFacing = "OFF",
                                webrtcState = "Camera Stream Stopped"
                            )
                        }
                        WhatsuppConnectionService.clearStreamControlEvent()
                    }
                    WhatsuppConnectionService.ACTION_STOP_AUDIO -> {
                        hardwareManager.stopLiveAudioCapture()
                        _localState.update {
                            it.copy(
                                isMicStreaming = false,
                                isTwoWayVoiceActive = false,
                                webrtcState = "Audio Stream Stopped"
                            )
                        }
                        WhatsuppConnectionService.clearStreamControlEvent()
                    }
                    WhatsuppConnectionService.ACTION_RESTORE_CAMERA_IF_ELIGIBLE -> {
                        val cfg = FamilyAuthSessionManager.loadDeviceConfig(hardwareManager.appContext, defaultName)
                        if (isForegroundActive && cfg.activeCameraFacing in listOf("FRONT", "BACK") &&
                            cfg.cameraConsentGranted && hardwareManager.hasCameraPermission()
                        ) {
                            FamilyAuthSessionManager.saveDeviceConfig(
                                hardwareManager.appContext,
                                cameraPausedBySystem = false
                            )
                            _localState.update {
                                it.copy(
                                    activeCameraFacing = cfg.activeCameraFacing,
                                    webrtcState = "WebRTC Live (${cfg.activeCameraFacing}) • Restored",
                                    statusBannerMessage = "Live ${cfg.activeCameraFacing} camera restored automatically"
                                )
                            }
                        }
                        WhatsuppConnectionService.clearStreamControlEvent()
                    }
                }
            }
        }
    }

    fun onAppForegrounded() {
        isForegroundActive = true
        val cfg = FamilyAuthSessionManager.loadDeviceConfig(hardwareManager.appContext, defaultName)
        val hasCamPerm = hardwareManager.hasCameraPermission()
        val hasMicPerm = hardwareManager.hasMicPermission()
        val telemetry = hardwareManager.readBatteryAndNetwork()

        // Verify permissions were not revoked while in background
        val resolvedCam = if (cfg.activeCameraFacing in listOf("FRONT", "BACK") && cfg.cameraConsentGranted && hasCamPerm) {
            cfg.activeCameraFacing
        } else {
            if (cfg.activeCameraFacing != "OFF" && !hasCamPerm) {
                FamilyAuthSessionManager.saveDeviceConfig(hardwareManager.appContext, activeCameraFacing = "OFF", cameraPausedBySystem = false)
            }
            "OFF"
        }

        val resolvedMic = cfg.isMicStreaming && cfg.micConsentGranted && hasMicPerm
        val resolvedVoice = cfg.isTwoWayVoiceActive && cfg.micConsentGranted && hasMicPerm
        if ((cfg.isMicStreaming || cfg.isTwoWayVoiceActive) && !hasMicPerm) {
            FamilyAuthSessionManager.saveDeviceConfig(
                hardwareManager.appContext,
                isMicStreaming = false,
                isTwoWayVoiceActive = false
            )
            hardwareManager.stopLiveAudioCapture()
        }

        val restoredCameraNotice = if (cfg.cameraPausedBySystem && resolvedCam != "OFF") {
            FamilyAuthSessionManager.saveDeviceConfig(hardwareManager.appContext, cameraPausedBySystem = false)
            "Camera ($resolvedCam) automatically restored after returning to foreground"
        } else {
            null
        }

        _localState.update { state ->
            state.copy(
                activeCameraFacing = resolvedCam,
                isMicStreaming = resolvedMic,
                isTwoWayVoiceActive = resolvedVoice,
                batteryLevel = telemetry.batteryLevel,
                isCharging = telemetry.isCharging,
                networkType = telemetry.networkType,
                isOnline = telemetry.isOnline,
                statusBannerMessage = restoredCameraNotice ?: state.statusBannerMessage
            )
        }

        if (resolvedVoice) {
            startForegroundViewModelAudioCapture(isTwoWay = true)
        } else if (resolvedMic) {
            startForegroundViewModelAudioCapture(isTwoWay = false)
        }

        if ((cfg.keepConnectedWhenClosed || cfg.autoReconnect) && !cfg.userExplicitlyStoppedService) {
            WhatsuppConnectionService.start(hardwareManager.appContext, isBackgroundHandoff = false)
        }
        syncThisDeviceToFirestore()
    }

    fun onAppBackgrounded() {
        val currentState = _localState.value
        FamilyAuthSessionManager.saveDeviceConfig(
            context = hardwareManager.appContext,
            activeCameraFacing = currentState.activeCameraFacing,
            isMicStreaming = currentState.isMicStreaming,
            isTwoWayVoiceActive = currentState.isTwoWayVoiceActive
        )
        // Release ViewModel AudioRecord instance so WhatsuppConnectionService can seamlessly continue
        hardwareManager.stopLiveAudioCapture()
        isForegroundActive = false
        if (currentState.keepConnectedWhenClosed ||
            currentState.autoReconnect ||
            currentState.activeCameraFacing != "OFF" ||
            currentState.isMicStreaming ||
            currentState.isTwoWayVoiceActive
        ) {
            WhatsuppConnectionService.start(hardwareManager.appContext, isBackgroundHandoff = true)
        }
    }

    private fun startForegroundViewModelAudioCapture(isTwoWay: Boolean) {
        hardwareManager.startLiveAudioCapture(
            scope = viewModelScope,
            onPermissionRevoked = {
                _localState.update {
                    it.copy(
                        isMicStreaming = false,
                        isTwoWayVoiceActive = false,
                        statusBannerMessage = "Microphone permission was revoked; audio session stopped."
                    )
                }
                FamilyAuthSessionManager.saveDeviceConfig(
                    hardwareManager.appContext,
                    isMicStreaming = false,
                    isTwoWayVoiceActive = false
                )
            }
        ) { db, chunk ->
            _localState.update { it.copy(localAudioLevelDb = db) }
            if (chunk.isNotEmpty()) {
                viewModelScope.launch {
                    repository.updateDeviceFields(
                        thisDeviceId,
                        mapOf(
                            "isTwoWayVoiceActive" to isTwoWay,
                            "isMicStreaming" to true,
                            "audioLevelDb" to db.toLong(),
                            "latestAudioBase64" to chunk
                        )
                    )
                }
            }
        }
    }

    private fun initializeDeviceAndTelemetryLoop() {
        viewModelScope.launch {
            val telemetry = hardwareManager.readBatteryAndNetwork()
            val existingDoc = repository.getDeviceById(currentUserId, thisDeviceId).getOrNull()
            val pendingCmd = existingDoc?.remoteCommand?.takeIf { it != "NONE" }
            _localState.update { state ->
                val resolvedRole = if (existingDoc != null && state.thisDeviceRole == "CONTROLLER" && existingDoc.role == "CONNECTED") {
                    FamilyAuthSessionManager.saveDeviceConfig(hardwareManager.appContext, deviceRole = existingDoc.role)
                    existingDoc.role
                } else {
                    state.thisDeviceRole
                }
                val preservedCam = if (existingDoc != null &&
                    existingDoc.activeCameraFacing in listOf("FRONT", "BACK") &&
                    state.cameraConsentGranted &&
                    hardwareManager.hasCameraPermission()
                ) {
                    existingDoc.activeCameraFacing
                } else {
                    state.activeCameraFacing
                }
                state.copy(
                    thisDeviceRole = resolvedRole,
                    activeCameraFacing = preservedCam,
                    batteryLevel = telemetry.batteryLevel,
                    isCharging = telemetry.isCharging,
                    networkType = telemetry.networkType,
                    isOnline = telemetry.isOnline
                )
            }
            syncThisDeviceToFirestore()
            if (pendingCmd != null) {
                executeIncomingRemoteCommand(pendingCmd)
            }
            repository.logConnectionEvent(
                deviceId = thisDeviceId,
                deviceName = _localState.value.thisDeviceName,
                eventType = "CONNECTED",
                details = "${_localState.value.thisDeviceName} online via ${telemetry.networkType} (${telemetry.batteryLevel}%) • Background sync ready"
            )
        }

        // Automatic reconnection & Wi-Fi <-> Mobile Data handoff
        networkCallback = hardwareManager.registerNetworkTransitionCallback(
            onNetworkAvailableOrChanged = { netType ->
                if (_localState.value.autoReconnect) {
                    viewModelScope.launch {
                        val telemetry = hardwareManager.readBatteryAndNetwork()
                        val wasOffline = !_localState.value.isOnline
                        val prevNet = _localState.value.networkType
                        _localState.update {
                            it.copy(
                                isOnline = true,
                                networkType = netType,
                                batteryLevel = telemetry.batteryLevel,
                                isCharging = telemetry.isCharging,
                                statusBannerMessage = if (wasOffline || prevNet != netType) {
                                    "Connected securely via $netType"
                                } else {
                                    it.statusBannerMessage
                                }
                            )
                        }
                        syncThisDeviceToFirestore()
                        if (wasOffline) {
                            repository.logConnectionEvent(
                                deviceId = thisDeviceId,
                                deviceName = _localState.value.thisDeviceName,
                                eventType = "RECONNECTED",
                                details = "Automatic secure reconnection completed over $netType"
                            )
                        }
                    }
                }
            },
            onNetworkLost = {
                _localState.update {
                    it.copy(
                        isOnline = false,
                        networkType = "Offline",
                        statusBannerMessage = "Network disconnected • Waiting to auto-reconnect..."
                    )
                }
            }
        )

        // Periodic battery & network heartbeat with Doze awareness
        viewModelScope.launch {
            while (isActive) {
                val intervalMs = if (hardwareManager.isPowerSaveOrDozeMode()) 30_000L else 15_000L
                delay(intervalMs)
                val t = hardwareManager.readBatteryAndNetwork()
                _localState.update {
                    it.copy(
                        batteryLevel = t.batteryLevel,
                        isCharging = t.isCharging,
                        networkType = t.networkType,
                        isOnline = t.isOnline
                    )
                }
                if (t.isOnline) {
                    repository.updateDeviceFields(
                        thisDeviceId,
                        mapOf(
                            "batteryLevel" to t.batteryLevel.toLong(),
                            "isCharging" to t.isCharging,
                            "networkType" to t.networkType,
                            "isOnline" to t.isOnline
                        )
                    )
                }
            }
        }
    }

    private fun handleIncomingDeviceSync(devices: List<FamilyDevice>) {
        val currentTarget = _localState.value.selectedTargetDeviceId
        val otherDevices = devices.filter { it.id != thisDeviceId }
        if (otherDevices.isNotEmpty() && (currentTarget.isBlank() || currentTarget == thisDeviceId || otherDevices.none { it.id == currentTarget })) {
            val targetId = otherDevices.first().id
            _localState.update { it.copy(selectedTargetDeviceId = targetId) }
            FamilyAuthSessionManager.saveDeviceConfig(hardwareManager.appContext, selectedTargetDeviceId = targetId)
        } else if (currentTarget.isBlank() && devices.isNotEmpty()) {
            val targetId = devices.first().id
            _localState.update { it.copy(selectedTargetDeviceId = targetId) }
        }

        val myDoc = devices.find { it.id == thisDeviceId }
        if (myDoc != null) {
            val cmd = myDoc.remoteCommand
            if (cmd != "NONE" && cmd != _localState.value.lastHandledCommand) {
                _localState.update { it.copy(lastHandledCommand = cmd) }
                executeIncomingRemoteCommand(cmd)
            } else if (cmd == "NONE" && _localState.value.lastHandledCommand != "NONE") {
                _localState.update { it.copy(lastHandledCommand = "NONE") }
            }
            if (myDoc.activeCameraFacing in listOf("FRONT", "BACK") &&
                _localState.value.activeCameraFacing == "OFF" &&
                _localState.value.cameraConsentGranted
            ) {
                _localState.update {
                    it.copy(
                        activeCameraFacing = myDoc.activeCameraFacing,
                        webrtcState = "WebRTC Live (${myDoc.activeCameraFacing}) • DTLS-SRTP"
                    )
                }
            }
        }

        // Play incoming live audio stream on Controller when another device is streaming audio
        val remoteStreamingDevice = otherDevices.firstOrNull {
            (it.isMicStreaming || it.isTwoWayVoiceActive) && it.latestAudioBase64.isNotBlank()
        }
        if (remoteStreamingDevice != null) {
            val hash = remoteStreamingDevice.latestAudioBase64.hashCode()
            if (hash != lastPlayedAudioHash) {
                lastPlayedAudioHash = hash
                hardwareManager.playIncomingPcmAudio(remoteStreamingDevice.latestAudioBase64, viewModelScope)
            }
        }
    }

    private fun executeIncomingRemoteCommand(command: String) {
        val s = _localState.value
        viewModelScope.launch {
            when (command) {
                "START_CAM_FRONT" -> if (s.cameraConsentGranted) {
                    setCameraMode("FRONT")
                    hardwareManager.postPrivacyNotification(
                        "Live Front Camera Active",
                        "Main Controller started viewing Front Camera with your consent."
                    )
                }
                "START_CAM_BACK" -> if (s.cameraConsentGranted) {
                    setCameraMode("BACK")
                    hardwareManager.postPrivacyNotification(
                        "Live Back Camera Active",
                        "Main Controller started viewing Back Camera with your consent."
                    )
                }
                "STOP_CAM" -> setCameraMode("OFF")
                "START_MIC" -> if (s.micConsentGranted) {
                    toggleMicStreaming(true)
                    hardwareManager.postPrivacyNotification(
                        "Live Microphone Audio Active",
                        "Main Controller started listening to live microphone audio."
                    )
                }
                "STOP_MIC" -> toggleMicStreaming(false)
                "START_VOICE" -> if (s.micConsentGranted) {
                    toggleTwoWayVoice(true)
                    hardwareManager.postPrivacyNotification(
                        "Two-Way Voice Intercom Active",
                        "Two-way family voice communication is active."
                    )
                }
                "STOP_VOICE" -> toggleTwoWayVoice(false)
                "PING_LOCATION" -> if (s.locationConsentGranted) {
                    refreshGpsLocation()
                }
                "RING_DEVICE" -> {
                    hardwareManager.triggerDeviceRingAlert()
                    hardwareManager.postPrivacyNotification(
                        "Family Device Ring Alert",
                        "Main Controller pinged this phone!"
                    )
                }
            }
            repository.updateDeviceFields(thisDeviceId, mapOf("remoteCommand" to "NONE"))
        }
    }

    private fun handleIncomingWebRtcSignals(signals: List<WebRtcSignal>) {
        val latestForMe = signals.firstOrNull { it.targetDeviceId == thisDeviceId || it.senderDeviceId != thisDeviceId }
        if (latestForMe != null) {
            _localState.update {
                it.copy(
                    webrtcState = "WebRTC ${latestForMe.type} (${latestForMe.mediaMode}) • ${latestForMe.encryptionFingerprint.take(20)}"
                )
            }
        }
    }

    private fun cacheMessagesToEncryptedVault(messages: List<EncryptedChatMessage>) {
        viewModelScope.launch {
            messages.takeLast(50).forEach { msg ->
                val ts = msg.createdAt?.toDate()?.time ?: System.currentTimeMillis()
                vaultDao.insertEncryptedChat(
                    VaultChatEntity(
                        id = msg.id.ifBlank { "msg_$ts" },
                        userId = currentUserId,
                        senderDeviceId = msg.senderDeviceId,
                        senderName = msg.senderName,
                        senderRole = msg.senderRole,
                        messageType = msg.messageType,
                        encryptedPayload = msg.cipherText,
                        encryptedMediaBase64 = LocalCryptoManager.encrypt(msg.mediaBase64),
                        durationSec = msg.durationSec,
                        timestampMs = ts
                    )
                )
            }
        }
    }

    fun syncThisDeviceToFirestore() {
        val s = _localState.value
        viewModelScope.launch {
            val device = FamilyDevice(
                id = s.thisDeviceId,
                userId = currentUserId,
                deviceName = s.thisDeviceName,
                role = s.thisDeviceRole,
                pairingCode = s.pairingCode,
                isPaired = s.isPaired,
                isOnline = s.isOnline,
                autoReconnect = s.autoReconnect,
                batteryLevel = s.batteryLevel.toLong(),
                isCharging = s.isCharging,
                networkType = s.networkType,
                latitude = s.latitude,
                longitude = s.longitude,
                locationAccuracy = s.locationAccuracy,
                locationLabel = s.locationLabel,
                cameraConsentGranted = s.cameraConsentGranted,
                micConsentGranted = s.micConsentGranted,
                locationConsentGranted = s.locationConsentGranted,
                activeCameraFacing = s.activeCameraFacing,
                isMicStreaming = s.isMicStreaming,
                isTwoWayVoiceActive = s.isTwoWayVoiceActive,
                audioLevelDb = s.localAudioLevelDb.toLong(),
                remoteCommand = "NONE"
            )
            repository.registerOrSyncDevice(device)
        }
    }

    fun switchThisDeviceRole(newRole: String) {
        val validRole = if (newRole == "CONNECTED") "CONNECTED" else "CONTROLLER"
        FamilyAuthSessionManager.saveDeviceConfig(
            hardwareManager.appContext,
            deviceRole = validRole
        )
        _localState.update {
            it.copy(
                thisDeviceRole = validRole,
                statusBannerMessage = "Switched role to ${if (validRole == "CONTROLLER") "Main Device (Controller)" else "Connected Device"} • Active even when app closed"
            )
        }
        syncThisDeviceToFirestore()
        WhatsuppConnectionService.start(hardwareManager.appContext)
        viewModelScope.launch {
            repository.logConnectionEvent(
                deviceId = thisDeviceId,
                deviceName = _localState.value.thisDeviceName,
                eventType = "CONNECTED",
                details = "Switched device role to $validRole"
            )
        }
    }

    fun updateDeviceName(newName: String) {
        val clean = newName.trim().take(80)
        if (clean.isBlank()) return
        FamilyAuthSessionManager.saveDeviceConfig(
            hardwareManager.appContext,
            deviceName = clean
        )
        _localState.update { it.copy(thisDeviceName = clean) }
        syncThisDeviceToFirestore()
        WhatsuppConnectionService.start(hardwareManager.appContext)
    }

    fun selectTargetDevice(deviceId: String) {
        FamilyAuthSessionManager.saveDeviceConfig(
            hardwareManager.appContext,
            selectedTargetDeviceId = deviceId
        )
        _localState.update { it.copy(selectedTargetDeviceId = deviceId) }
    }

    fun completeDevicePairing(enteredCode: String) {
        val code = enteredCode.trim().filter { it.isDigit() }.take(6).padEnd(6, '0')
        FamilyAuthSessionManager.saveDeviceConfig(
            hardwareManager.appContext,
            pairingCode = code
        )
        _pairingCodeFlow.value = code
        _localState.update {
            it.copy(
                pairingCode = code,
                isPaired = true,
                statusBannerMessage = "Device paired securely with code $code • Background connection active"
            )
        }
        syncThisDeviceToFirestore()
        WhatsuppConnectionService.start(hardwareManager.appContext)
        viewModelScope.launch {
            repository.logConnectionEvent(
                deviceId = thisDeviceId,
                deviceName = _localState.value.thisDeviceName,
                eventType = "PAIRED",
                details = "Completed encrypted pairing handshake (Code: $code)"
            )
            hardwareManager.postPrivacyNotification(
                "Whatsupp Device Paired",
                "${_localState.value.thisDeviceName} is now paired and stays connected even when closed."
            )
        }
    }

    fun updatePrivacyConsent(camera: Boolean, mic: Boolean, location: Boolean) {
        FamilyAuthSessionManager.saveDeviceConfig(
            hardwareManager.appContext,
            cameraConsentGranted = camera,
            micConsentGranted = mic,
            locationConsentGranted = location
        )
        _localState.update {
            it.copy(
                cameraConsentGranted = camera,
                micConsentGranted = mic,
                locationConsentGranted = location,
                activeCameraFacing = if (!camera) "OFF" else it.activeCameraFacing,
                isMicStreaming = if (!mic) false else it.isMicStreaming,
                isTwoWayVoiceActive = if (!mic) false else it.isTwoWayVoiceActive,
                statusBannerMessage = "Updated hardware consent settings"
            )
        }
        if (!mic) hardwareManager.stopLiveAudioCapture()
        syncThisDeviceToFirestore()
        viewModelScope.launch {
            repository.logConnectionEvent(
                deviceId = thisDeviceId,
                deviceName = _localState.value.thisDeviceName,
                eventType = "CONSENT_CHANGED",
                details = "Consent updated — Cam: $camera, Mic: $mic, GPS: $location"
            )
        }
    }

    fun toggleAutoReconnect(enabled: Boolean) {
        FamilyAuthSessionManager.saveDeviceConfig(
            hardwareManager.appContext,
            autoReconnect = enabled,
            keepConnectedWhenClosed = enabled
        )
        _localState.update {
            it.copy(
                autoReconnect = enabled,
                keepConnectedWhenClosed = enabled,
                statusBannerMessage = if (enabled) {
                    "Persistent background connection enabled (stays connected when app is closed)"
                } else {
                    "Background auto-reconnect paused"
                }
            )
        }
        if (enabled) {
            WhatsuppConnectionService.start(hardwareManager.appContext)
        } else {
            WhatsuppConnectionService.stop(hardwareManager.appContext)
        }
        syncThisDeviceToFirestore()
    }

    // Camera Streaming & WebRTC SDP Signaling
    fun setCameraMode(facing: String) {
        val mode = if (facing in listOf("OFF", "FRONT", "BACK")) facing else "OFF"
        if (mode != "OFF" && !_localState.value.cameraConsentGranted) {
            _localState.update {
                it.copy(statusBannerMessage = "Camera consent is required before starting live camera.")
            }
            return
        }
        FamilyAuthSessionManager.saveDeviceConfig(
            context = hardwareManager.appContext,
            activeCameraFacing = mode,
            cameraPausedBySystem = false
        )
        _localState.update {
            it.copy(
                activeCameraFacing = mode,
                webrtcState = if (mode == "OFF") "Camera Stream Closed" else "WebRTC Live ($mode) • DTLS-SRTP"
            )
        }
        WhatsuppConnectionService.start(hardwareManager.appContext)
        viewModelScope.launch {
            val camUpdates = if (mode == "OFF") {
                mapOf("activeCameraFacing" to mode, "latestFrameBase64" to "")
            } else {
                mapOf("activeCameraFacing" to mode)
            }
            repository.updateDeviceFields(thisDeviceId, camUpdates)
            val targetId = _localState.value.selectedTargetDeviceId.ifBlank { thisDeviceId }
            if (mode != "OFF") {
                val mediaMode = if (mode == "FRONT") "CAMERA_FRONT" else "CAMERA_BACK"
                repository.sendWebRtcSignal(
                    senderDeviceId = thisDeviceId,
                    targetDeviceId = targetId,
                    type = "OFFER",
                    sdpOrCandidate = "v=0\r\no=- ${System.currentTimeMillis()} 2 IN IP4 127.0.0.1\r\ns=WhatsuppLiveCamera\r\nm=video 9 UDP/TLS/RTP/SAVPF 96\r\na=setup:actpass\r\na=mid:video_$mode",
                    mediaMode = mediaMode
                )
                repository.logConnectionEvent(
                    deviceId = thisDeviceId,
                    deviceName = _localState.value.thisDeviceName,
                    eventType = "CAMERA_SESSION",
                    details = "Started live $mode camera stream with visible consent indicator"
                )
                hardwareManager.postPrivacyNotification(
                    "Whatsupp Camera Active ($mode)",
                    "Your $mode camera is actively streaming to your paired family device."
                )
            } else {
                repository.sendWebRtcSignal(
                    senderDeviceId = thisDeviceId,
                    targetDeviceId = targetId,
                    type = "BYE",
                    sdpOrCandidate = "a=end-of-candidates",
                    mediaMode = "CAMERA_BACK"
                )
            }
        }
    }

    fun onLocalCameraFrameEncoded(base64Jpeg: String) {
        if (base64Jpeg.isBlank()) return
        val now = System.currentTimeMillis()
        if (now - lastFrameSentMs < 950L) return
        if (_localState.value.activeCameraFacing == "OFF") return
        lastFrameSentMs = now
        viewModelScope.launch {
            repository.updateDeviceFields(
                thisDeviceId,
                mapOf("latestFrameBase64" to base64Jpeg.take(300000))
            )
        }
    }

    fun saveEncryptedSnapshot(base64Jpeg: String, sourceLabel: String) {
        if (base64Jpeg.isBlank()) return
        viewModelScope.launch {
            val mediaId = "snap_${UUID.randomUUID().toString().take(10)}"
            vaultDao.insertSavedMedia(
                SavedMediaEntity(
                    id = mediaId,
                    userId = currentUserId,
                    deviceId = thisDeviceId,
                    deviceName = _localState.value.thisDeviceName,
                    mediaType = "CAMERA_SNAPSHOT",
                    encryptedBase64 = LocalCryptoManager.encrypt(base64Jpeg, currentUserId),
                    encryptedCaption = LocalCryptoManager.encrypt("Snapshot ($sourceLabel)", currentUserId),
                    createdAtMs = System.currentTimeMillis()
                )
            )
            repository.sendEncryptedMessage(
                senderDeviceId = thisDeviceId,
                senderName = _localState.value.thisDeviceName,
                senderRole = _localState.value.thisDeviceRole,
                messageType = "SNAPSHOT",
                plainText = "Encrypted Camera Snapshot ($sourceLabel)",
                mediaBase64 = base64Jpeg.take(250000)
            )
            _localState.update {
                it.copy(statusBannerMessage = "Snapshot encrypted & saved to Local Vault")
            }
        }
    }

    // Live Microphone & Two-Way Voice Intercom
    fun toggleMicStreaming(enable: Boolean) {
        if (enable && !_localState.value.micConsentGranted) {
            _localState.update {
                it.copy(statusBannerMessage = "Microphone consent is required before streaming audio.")
            }
            return
        }
        FamilyAuthSessionManager.saveDeviceConfig(
            context = hardwareManager.appContext,
            isMicStreaming = enable
        )
        _localState.update {
            it.copy(
                isMicStreaming = enable,
                webrtcState = if (enable) "WebRTC Audio Stream • Opus/PCM" else "Idle"
            )
        }
        WhatsuppConnectionService.start(hardwareManager.appContext)
        if (enable) {
            startForegroundViewModelAudioCapture(isTwoWay = _localState.value.isTwoWayVoiceActive)
            viewModelScope.launch {
                val targetId = _localState.value.selectedTargetDeviceId.ifBlank { thisDeviceId }
                repository.sendWebRtcSignal(
                    senderDeviceId = thisDeviceId,
                    targetDeviceId = targetId,
                    type = "OFFER",
                    sdpOrCandidate = "v=0\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111\r\na=rtpmap:111 opus/48000/2",
                    mediaMode = "AUDIO_STREAM"
                )
                repository.logConnectionEvent(
                    deviceId = thisDeviceId,
                    deviceName = _localState.value.thisDeviceName,
                    eventType = "MIC_SESSION",
                    details = "Live microphone audio stream started with visible consent indicator"
                )
                hardwareManager.postPrivacyNotification(
                    "Whatsupp Microphone Active",
                    "Live microphone audio streaming is active."
                )
            }
        } else {
            if (!_localState.value.isTwoWayVoiceActive) {
                hardwareManager.stopLiveAudioCapture()
            }
            viewModelScope.launch {
                repository.updateDeviceFields(
                    thisDeviceId,
                    mapOf(
                        "isMicStreaming" to false,
                        "audioLevelDb" to 0L,
                        "latestAudioBase64" to ""
                    )
                )
            }
        }
    }

    fun toggleTwoWayVoice(enable: Boolean) {
        if (enable && !_localState.value.micConsentGranted) {
            _localState.update {
                it.copy(statusBannerMessage = "Microphone consent is required for two-way voice.")
            }
            return
        }
        FamilyAuthSessionManager.saveDeviceConfig(
            context = hardwareManager.appContext,
            isTwoWayVoiceActive = enable,
            isMicStreaming = enable
        )
        _localState.update {
            it.copy(
                isTwoWayVoiceActive = enable,
                isMicStreaming = enable,
                webrtcState = if (enable) "Two-Way Voice Call Active • DTLS-SRTP" else "Voice Call Ended"
            )
        }
        WhatsuppConnectionService.start(hardwareManager.appContext)
        if (enable) {
            startForegroundViewModelAudioCapture(isTwoWay = true)
            viewModelScope.launch {
                val targetId = _localState.value.selectedTargetDeviceId.ifBlank { thisDeviceId }
                repository.sendWebRtcSignal(
                    senderDeviceId = thisDeviceId,
                    targetDeviceId = targetId,
                    type = "OFFER",
                    sdpOrCandidate = "v=0\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111\r\na=sendrecv\r\na=mid:twoway_voice",
                    mediaMode = "TWO_WAY_VOICE"
                )
                repository.logConnectionEvent(
                    deviceId = thisDeviceId,
                    deviceName = _localState.value.thisDeviceName,
                    eventType = "VOICE_CALL",
                    details = "Started two-way encrypted voice communication"
                )
            }
        } else {
            hardwareManager.stopLiveAudioCapture()
            viewModelScope.launch {
                repository.updateDeviceFields(
                    thisDeviceId,
                    mapOf(
                        "isTwoWayVoiceActive" to false,
                        "isMicStreaming" to false,
                        "audioLevelDb" to 0L,
                        "latestAudioBase64" to ""
                    )
                )
            }
        }
    }

    // Send Remote Command from Main Controller to Connected Device
    fun sendRemoteCommandToTarget(command: String) {
        val currentDevices = (devicesState.value as? UiState.Success)?.data.orEmpty()
        val selectedId = _localState.value.selectedTargetDeviceId
        val resolvedTarget = currentDevices.find { it.id == selectedId && it.id != thisDeviceId }
            ?: currentDevices.firstOrNull { it.id != thisDeviceId }
            ?: currentDevices.find { it.id == selectedId }
        val targetId = resolvedTarget?.id ?: selectedId.ifBlank { thisDeviceId }
        val targetName = resolvedTarget?.deviceName ?: "paired device"

        if (resolvedTarget != null && resolvedTarget.id != selectedId) {
            _localState.update { it.copy(selectedTargetDeviceId = resolvedTarget.id) }
            FamilyAuthSessionManager.saveDeviceConfig(hardwareManager.appContext, selectedTargetDeviceId = resolvedTarget.id)
        }

        viewModelScope.launch {
            repository.sendRemoteCommand(
                targetDeviceId = targetId,
                command = command,
                targetChannelUserId = resolvedTarget?.userId
            )
            _localState.update {
                it.copy(
                    statusBannerMessage = "Connected to $targetName ($command)",
                    webrtcState = when (command) {
                        "START_CAM_BACK" -> "Requesting Remote BACK Camera from $targetName..."
                        "START_CAM_FRONT" -> "Requesting Remote FRONT Camera from $targetName..."
                        "STOP_CAM" -> "Remote Camera Stopped"
                        else -> it.webrtcState
                    }
                )
            }
        }
    }

    // Real-time GPS Location Sync
    fun refreshGpsLocation() {
        if (!_localState.value.locationConsentGranted) {
            _localState.update {
                it.copy(statusBannerMessage = "Location consent is disabled on this device.")
            }
            return
        }
        viewModelScope.launch {
            val gps = hardwareManager.fetchCurrentGpsLocation()
            if (gps != null) {
                _localState.update {
                    it.copy(
                        latitude = gps.latitude,
                        longitude = gps.longitude,
                        locationAccuracy = gps.accuracy,
                        locationLabel = gps.locationLabel,
                        batteryLevel = gps.batteryLevel,
                        isCharging = gps.isCharging,
                        networkType = gps.networkType,
                        statusBannerMessage = "GPS synced: ${gps.locationLabel} (±${gps.accuracy.toInt()}m)"
                    )
                }
                repository.updateDeviceFields(
                    thisDeviceId,
                    mapOf(
                        "latitude" to gps.latitude,
                        "longitude" to gps.longitude,
                        "locationAccuracy" to gps.accuracy,
                        "locationLabel" to gps.locationLabel
                    )
                )
                repository.logConnectionEvent(
                    deviceId = thisDeviceId,
                    deviceName = _localState.value.thisDeviceName,
                    eventType = "LOCATION_SYNC",
                    details = "Updated live GPS location: ${gps.locationLabel}"
                )
            } else {
                _localState.update {
                    it.copy(statusBannerMessage = "Ensure GPS permission is granted and location is enabled.")
                }
            }
        }
    }

    // Encrypted Chat & Voice Notes
    fun sendTextChatMessage(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val s = _localState.value
        viewModelScope.launch {
            repository.sendEncryptedMessage(
                senderDeviceId = s.thisDeviceId,
                senderName = s.thisDeviceName,
                senderRole = s.thisDeviceRole,
                messageType = "TEXT",
                plainText = clean
            )
        }
    }

    fun sendVoiceNoteMessage(durationSec: Long) {
        val s = _localState.value
        viewModelScope.launch {
            repository.sendEncryptedMessage(
                senderDeviceId = s.thisDeviceId,
                senderName = s.thisDeviceName,
                senderRole = s.thisDeviceRole,
                messageType = "VOICE_NOTE",
                plainText = "Encrypted Voice Message (${durationSec}s)",
                durationSec = durationSec.coerceIn(1L, 300L)
            )
        }
    }

    fun shareCurrentLocationPinToChat() {
        val s = _localState.value
        viewModelScope.launch {
            repository.sendEncryptedMessage(
                senderDeviceId = s.thisDeviceId,
                senderName = s.thisDeviceName,
                senderRole = s.thisDeviceRole,
                messageType = "LOCATION_PIN",
                plainText = "Live GPS Pin: ${s.locationLabel} (${"%.4f".format(s.latitude)}, ${"%.4f".format(s.longitude)})"
            )
        }
    }

    fun deleteSavedMediaItem(id: String) {
        viewModelScope.launch {
            vaultDao.deleteSavedMedia(id)
        }
    }

    fun dismissBanner() {
        _localState.update { it.copy(statusBannerMessage = null) }
    }

    fun calculateDistanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    fun triggerSosEmergencyAlert() {
        _localState.update { it.copy(isSosActive = true) }
        viewModelScope.launch {
            val alert = SafetyAlert(
                id = "sos_${UUID.randomUUID().toString().take(8)}",
                title = "EMERGENCY SOS BEACON",
                description = "SOS Distress signal triggered by ${_localState.value.thisDeviceName} at ${_localState.value.locationLabel} (GPS: ${_localState.value.latitude}, ${_localState.value.longitude})",
                type = "SOS",
                deviceName = _localState.value.thisDeviceName
            )
            _safetyAlerts.update { listOf(alert) + it }
            repository.logConnectionEvent(
                deviceId = thisDeviceId,
                deviceName = _localState.value.thisDeviceName,
                eventType = "BATTERY_ALERT",
                details = "EMERGENCY SOS BEACON TRIGGERED: Live GPS ${_localState.value.latitude}, ${_localState.value.longitude}"
            )
            repository.sendEncryptedMessage(
                senderDeviceId = thisDeviceId,
                senderName = _localState.value.thisDeviceName,
                senderRole = _localState.value.thisDeviceRole,
                messageType = "LOCATION_PIN",
                plainText = "🚨 EMERGENCY SOS DISTRESS SIGNAL! Live Location: ${_localState.value.latitude}, ${_localState.value.longitude}"
            )
            hardwareManager.postPrivacyNotification(
                "🚨 Emergency SOS Active",
                "Broadcasting SOS emergency distress beacon and live GPS to all family devices."
            )
        }
    }

    fun dismissSosAlert() {
        _localState.update { it.copy(isSosActive = false) }
    }

    fun toggleMotionDetection(enable: Boolean) {
        _localState.update { it.copy(isMotionDetectionEnabled = enable) }
        if (enable) {
            val alert = SafetyAlert(
                id = "motion_${System.currentTimeMillis()}",
                title = "Camera Motion Sentry Armed",
                description = "Smart pixel delta sentry armed on ${_localState.value.thisDeviceName}.",
                type = "MOTION",
                deviceName = _localState.value.thisDeviceName
            )
            _safetyAlerts.update { listOf(alert) + it }
        }
    }

    fun setMotionSensitivity(level: String) {
        _localState.update { it.copy(motionSensitivity = level) }
    }

    fun toggleSoundDetection(enable: Boolean) {
        _localState.update { it.copy(isSoundDetectionEnabled = enable) }
        if (enable) {
            val alert = SafetyAlert(
                id = "sound_${System.currentTimeMillis()}",
                title = "Sound Event Sentry Armed",
                description = "Microphone acoustic threshold monitoring armed (> ${_localState.value.soundThresholdDb} dB).",
                type = "SOUND",
                deviceName = _localState.value.thisDeviceName
            )
            _safetyAlerts.update { listOf(alert) + it }
        }
    }

    fun setSoundThreshold(db: Int) {
        _localState.update { it.copy(soundThresholdDb = db.coerceIn(40, 100)) }
    }

    fun toggleScreenSharing(enable: Boolean) {
        _localState.update { it.copy(isScreenSharingActive = enable) }
        if (enable) {
            hardwareManager.postPrivacyNotification(
                "Screen Sharing Active",
                "Remote assistance screen sharing session is currently active."
            )
        }
    }

    fun toggleBedtime(enable: Boolean) {
        _localState.update { it.copy(isBedtimeActive = enable) }
    }

    fun addSavedPlace(label: String, address: String, lat: Double, lng: Double, radius: Double) {
        val newPlace = SavedPlace(
            id = "place_${UUID.randomUUID().toString().take(8)}",
            label = label.ifBlank { "Saved Place" },
            address = address.ifBlank { "Custom Location" },
            latitude = if (lat != 0.0) lat else _localState.value.latitude,
            longitude = if (lng != 0.0) lng else _localState.value.longitude,
            radiusMeters = radius.coerceIn(50.0, 5000.0)
        )
        _savedPlaces.update { it + newPlace }
    }

    fun deleteSavedPlace(id: String) {
        _savedPlaces.update { list -> list.filterNot { it.id == id } }
    }

    fun removeDevice(deviceId: String) {
        viewModelScope.launch {
            repository.deleteDevice(deviceId)
            _localState.update {
                it.copy(
                    selectedTargetDeviceId = if (it.selectedTargetDeviceId == deviceId) "" else it.selectedTargetDeviceId,
                    statusBannerMessage = "Device removed from family network"
                )
            }
        }
    }

    fun ringTargetDevice(targetDeviceId: String) {
        viewModelScope.launch {
            if (targetDeviceId == thisDeviceId) {
                hardwareManager.triggerDeviceRingAlert()
            } else {
                repository.sendRemoteCommand(targetDeviceId, "RING_DEVICE")
                _localState.update {
                    it.copy(statusBannerMessage = "Sent high-volume ring signal to device")
                }
            }
        }
    }

    fun refreshAppUsage() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val stats = hardwareManager.queryTodayUsageStats()
            _appUsageReports.value = stats
        }
    }

    fun getUsageSettingsIntent() = hardwareManager.getUsageSettingsIntent()
    fun hasUsageStatsPermission() = hardwareManager.hasUsageStatsPermission()

    fun deleteAccountAndAllData(
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            WhatsuppConnectionService.stop(hardwareManager.appContext)
            try {
                // 1. Delete all Firestore records for devices, signals, and messages
                repository.deleteAllUserData(currentUserId)
            } catch (e: Exception) {
                Log.w(TAG, "Failed deleting Firestore user data", e)
            }
            try {
                // 2. Wipe local encrypted Room vault
                vaultDao.deleteAllChats(currentUserId)
                vaultDao.deleteAllMedia(currentUserId)
            } catch (e: Exception) {
                Log.w(TAG, "Failed wiping local encrypted Room vault", e)
            }
            try {
                // 3. Stop all media hardware
                hardwareManager.stopLiveAudioCapture()
            } catch (e: Exception) {
                Log.w(TAG, "Failed stopping hardware", e)
            }
            try {
                // 4. Delete Firebase Auth user if supported, or sign out
                val user = Firebase.auth.currentUser
                user?.delete()?.await()
            } catch (e: Exception) {
                Log.w(TAG, "Firebase auth user delete failed (may require re-auth), signing out", e)
                try {
                    Firebase.auth.signOut()
                } catch (_: Exception) {}
            }
            onComplete()
        }
    }

    override fun onCleared() {
        isForegroundActive = false
        super.onCleared()
        hardwareManager.unregisterNetworkCallback(networkCallback)
        if (_localState.value.keepConnectedWhenClosed || _localState.value.autoReconnect) {
            WhatsuppConnectionService.start(hardwareManager.appContext)
        } else {
            hardwareManager.stopLiveAudioCapture()
        }
    }

    companion object {
        const val TAG = "WhatsuppVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
        @Volatile
        var isForegroundActive: Boolean = false
    }
}
