package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.util.Base64
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CameraFront
import androidx.compose.material.icons.filled.CameraRear
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.model.FamilyDevice
import com.example.ui.LocalDashboardState
import com.example.ui.UiState
import com.example.ui.theme.BrandGreenAccent
import com.example.ui.theme.BrandGreenDeep
import com.example.ui.theme.BrandGreenPrimary
import com.example.ui.theme.BrandGreenSoft
import com.example.ui.theme.StatusAlert
import com.example.ui.theme.StatusConnecting
import com.example.ui.theme.StatusOffline
import com.example.ui.theme.StatusOnline
import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

enum class CameraConnectionStatus {
    READY,
    WAITING_PERMISSION,
    CONNECTING,
    LIVE,
    CONNECTION_LOST,
    UNAVAILABLE
}

@Composable
fun LiveCameraTab(
    localState: LocalDashboardState,
    devicesState: UiState<List<FamilyDevice>>,
    onSetLocalCameraMode: (String) -> Unit,
    onSendRemoteCommand: (String) -> Unit,
    onLocalFrameEncoded: (String) -> Unit,
    onSaveEncryptedSnapshot: (String, String) -> Unit,
    onRequestCameraPermission: () -> Unit
) {
    val context = LocalContext.current
    val devices = (devicesState as? UiState.Success)?.data ?: emptyList()
    val targetDevice = devices.find { it.id == localState.selectedTargetDeviceId }
        ?: devices.firstOrNull { it.id != localState.thisDeviceId }
        ?: devices.firstOrNull()

    val hasCameraPermission = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED

    var showSavedFeedback by remember { mutableStateOf(false) }

    LaunchedEffect(showSavedFeedback) {
        if (showSavedFeedback) {
            delay(2800)
            showSavedFeedback = false
        }
    }

    var localCapturedFrameBase64 by remember { mutableStateOf("") }

    // Determine whether we are streaming local camera or receiving remote camera
    val isLocalActive = localState.activeCameraFacing != "OFF"
    val isRemoteActive = targetDevice?.activeCameraFacing != null && targetDevice.activeCameraFacing != "OFF"
    val isLive = isLocalActive || isRemoteActive

    // Status state
    val status = when {
        !hasCameraPermission && isLocalActive -> CameraConnectionStatus.WAITING_PERMISSION
        targetDevice != null && !targetDevice.isOnline && !isLocalActive -> CameraConnectionStatus.CONNECTION_LOST
        isLive -> CameraConnectionStatus.LIVE
        localState.statusBannerMessage?.contains("fail", ignoreCase = true) == true -> CameraConnectionStatus.UNAVAILABLE
        else -> CameraConnectionStatus.READY
    }

    // Active frame available for capture
    val activeFrameBase64 = when {
        isRemoteActive && targetDevice?.latestFrameBase64?.isNotBlank() == true ->
            targetDevice.latestFrameBase64
        isLocalActive && localCapturedFrameBase64.isNotBlank() ->
            localCapturedFrameBase64
        else -> ""
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header with 'Live Camera', Device Name, and Status Badge
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Live Camera",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${if (isLocalActive) "This Phone" else (targetDevice?.deviceName ?: "Connected Device")} • ${when (status) {
                            CameraConnectionStatus.READY -> "Ready"
                            CameraConnectionStatus.WAITING_PERMISSION -> "Waiting for permission"
                            CameraConnectionStatus.CONNECTING -> "Connecting"
                            CameraConnectionStatus.LIVE -> "Live feed"
                            CameraConnectionStatus.CONNECTION_LOST -> "Connection lost"
                            CameraConnectionStatus.UNAVAILABLE -> "Camera unavailable"
                        }}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                CameraStatusBadge(status = status)
            }
        }

        // 2. Video Player Area (Large 4:3 view with rounded corners)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(4f / 3f)
                .testTag("camera_view_card"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1713))
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                when {
                    isLocalActive && hasCameraPermission -> {
                        CameraXLivePreview(
                            cameraFacing = localState.activeCameraFacing,
                            onFrameEncoded = { frame ->
                                localCapturedFrameBase64 = frame
                                onLocalFrameEncoded(frame)
                            }
                        )
                    }
                    isRemoteActive && activeFrameBase64.isNotBlank() -> {
                        RemoteFrameRenderer(base64Frame = activeFrameBase64)
                    }
                    status == CameraConnectionStatus.WAITING_PERMISSION -> {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = null,
                                tint = StatusConnecting,
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = "Camera Permission Needed",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Grant camera permission to start video stream.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFB2DFDB),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Button(
                                onClick = onRequestCameraPermission,
                                colors = ButtonDefaults.buttonColors(containerColor = BrandGreenPrimary)
                            ) {
                                Text("Grant Permission")
                            }
                        }
                    }
                    status == CameraConnectionStatus.CONNECTION_LOST -> {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VideocamOff,
                                contentDescription = null,
                                tint = StatusAlert,
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = "Connection Lost",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Target phone appears offline or in sleep mode.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                            Button(
                                onClick = {
                                    onSendRemoteCommand("CAMERA_BACK")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = BrandGreenPrimary)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Retry Connection")
                            }
                        }
                    }
                    else -> {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.5f),
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = "Camera is currently off",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Tap Front Camera or Back Camera below to start.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.7f),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                // Security watermark & live pill overlay
                if (isLive) {
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(14.dp),
                        shape = RoundedCornerShape(10.dp),
                        color = Color.Black.copy(alpha = 0.6f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(StatusOnline)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "LIVE • AES-256",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }

                // Instant Photo Saved Feedback Banner
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 16.dp)
                ) {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = showSavedFeedback,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = BrandGreenPrimary,
                            tonalElevation = 8.dp
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Photo saved to family vault!",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Four Main Controls: Front Camera | Back Camera | Stop Camera | Save Photo
        Text(
            text = "Camera Controls",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        val activeFacing = if (isLocalActive) localState.activeCameraFacing else (targetDevice?.activeCameraFacing ?: "OFF")

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Front Camera
            val isFrontSelected = activeFacing == "FRONT"
            Button(
                onClick = {
                    if (localState.thisDeviceRole == "CONNECTED") {
                        onSetLocalCameraMode("FRONT")
                    } else {
                        onSendRemoteCommand("CAMERA_FRONT")
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 52.dp)
                    .testTag("camera_front_button"),
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isFrontSelected) BrandGreenPrimary else BrandGreenSoft,
                    contentColor = if (isFrontSelected) Color.White else BrandGreenPrimary
                )
            ) {
                Icon(Icons.Default.CameraFront, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Front Camera",
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Back Camera
            val isBackSelected = activeFacing == "BACK"
            Button(
                onClick = {
                    if (localState.thisDeviceRole == "CONNECTED") {
                        onSetLocalCameraMode("BACK")
                    } else {
                        onSendRemoteCommand("CAMERA_BACK")
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 52.dp)
                    .testTag("camera_back_button"),
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isBackSelected) BrandGreenPrimary else BrandGreenSoft,
                    contentColor = if (isBackSelected) Color.White else BrandGreenPrimary
                )
            ) {
                Icon(Icons.Default.CameraRear, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Back Camera",
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Stop Camera
            Button(
                onClick = {
                    onSetLocalCameraMode("OFF")
                    onSendRemoteCommand("CAMERA_OFF")
                },
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 52.dp)
                    .testTag("camera_stop_button"),
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            ) {
                Icon(Icons.Default.StopCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Stop Camera",
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Save Photo (enabled only when active frame is present)
            Button(
                onClick = {
                    if (activeFrameBase64.isNotBlank()) {
                        onSaveEncryptedSnapshot(activeFrameBase64, "CAMERA_SNAPSHOT")
                        showSavedFeedback = true
                    } else {
                        Toast.makeText(context, "Start camera to capture a frame", Toast.LENGTH_SHORT).show()
                    }
                },
                enabled = activeFrameBase64.isNotBlank(),
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 52.dp)
                    .testTag("camera_save_photo_button"),
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrandGreenPrimary,
                    contentColor = Color.White
                )
            ) {
                Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Save Photo",
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // Retry connection button if error / offline
        if (status == CameraConnectionStatus.CONNECTION_LOST || status == CameraConnectionStatus.UNAVAILABLE) {
            OutlinedButton(
                onClick = {
                    onSendRemoteCommand("CAMERA_BACK")
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 50.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Retry Connection", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun CameraStatusBadge(status: CameraConnectionStatus) {
    val (label, bg, fg) = when (status) {
        CameraConnectionStatus.READY -> Triple("Ready", StatusOffline.copy(alpha = 0.12f), StatusOffline)
        CameraConnectionStatus.WAITING_PERMISSION -> Triple("Waiting for permission", StatusConnecting.copy(alpha = 0.15f), StatusConnecting)
        CameraConnectionStatus.CONNECTING -> Triple("Connecting", StatusConnecting.copy(alpha = 0.15f), StatusConnecting)
        CameraConnectionStatus.LIVE -> Triple("Live", StatusOnline.copy(alpha = 0.15f), StatusOnline)
        CameraConnectionStatus.CONNECTION_LOST -> Triple("Connection lost", StatusAlert.copy(alpha = 0.15f), StatusAlert)
        CameraConnectionStatus.UNAVAILABLE -> Triple("Camera unavailable", StatusAlert.copy(alpha = 0.15f), StatusAlert)
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bg
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(fg)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = fg
            )
        }
    }
}

@Composable
private fun RemoteFrameRenderer(base64Frame: String) {
    val bitmap = remember(base64Frame) {
        try {
            val bytes = Base64.decode(base64Frame, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Exception) {
            null
        }
    }

    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = "Live Remote Camera Frame",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
    } else {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Connecting video feed...",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White
            )
        }
    }
}

/**
 * CameraX live preview with real ImageAnalysis encoder for WebRTC/data stream.
 */
@Composable
fun CameraXLivePreview(
    cameraFacing: String,
    onFrameEncoded: (String) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember { PreviewView(context) }
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(cameraFacing) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().build().also {
                it.surfaceProvider = previewView.surfaceProvider
            }

            val imageAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            var lastFrameTime = 0L
            imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                val now = System.currentTimeMillis()
                if (now - lastFrameTime > 250) { // ~4 FPS lightweight background/foreground stream
                    lastFrameTime = now
                    val base64 = imageProxyToBase64Jpeg(imageProxy, cameraFacing == "FRONT")
                    if (base64 != null) {
                        onFrameEncoded(base64)
                    }
                }
                imageProxy.close()
            }

            val selector = if (cameraFacing == "FRONT") {
                CameraSelector.DEFAULT_FRONT_CAMERA
            } else {
                CameraSelector.DEFAULT_BACK_CAMERA
            }

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    selector,
                    preview,
                    imageAnalysis
                )
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            try {
                cameraProviderFuture.get().unbindAll()
            } catch (_: Exception) {}
            cameraExecutor.shutdown()
        }
    }

    AndroidView(
        factory = { previewView },
        modifier = Modifier.fillMaxSize()
    )
}

private fun imageProxyToBase64Jpeg(imageProxy: ImageProxy, isFront: Boolean): String? {
    return try {
        val buffer = imageProxy.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null

        val rotation = imageProxy.imageInfo.rotationDegrees.toFloat()
        val matrix = Matrix()
        matrix.postRotate(rotation)
        if (isFront) {
            matrix.postScale(-1f, 1f)
        }

        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        val stream = ByteArrayOutputStream()
        rotated.compress(Bitmap.CompressFormat.JPEG, 45, stream)
        Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    } catch (_: Exception) {
        null
    }
}
