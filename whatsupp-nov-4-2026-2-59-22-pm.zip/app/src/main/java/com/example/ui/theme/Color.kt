package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Soft Green Accent Palette & Modern Clean White
val BrandGreenPrimary = Color(0xFF1B8755)       // Rich forest green
val BrandGreenAccent = Color(0xFF22C55E)        // Vibrant soft emerald
val BrandGreenSoft = Color(0xFFE8F5E9)          // Pastel mint container
val BrandGreenDeep = Color(0xFF0F5132)          // Deep readable green

// Light Theme - Clean White with Soft Green
val LightBackground = Color(0xFFFAFCFA)        // Pure crisp off-white
val LightSurface = Color(0xFFFFFFFF)           // Clean white
val LightCard = Color(0xFFFFFFFF)              // Pure card white
val LightCardBorder = Color(0xFFE6EFE8)        // Soft mint border
val LightSurfaceSubtle = Color(0xFFF1F6F2)     // Very soft light green-gray
val LightTextPrimary = Color(0xFF19211D)       // High contrast charcoal
val LightTextSecondary = Color(0xFF5F6E65)     // Muted green-gray
val LightTextTertiary = Color(0xFF8A9A90)      // Soft placeholder
val LightChatBubbleOutgoing = Color(0xFFDCF8C6) // WhatsApp classic soft green
val LightChatBubbleIncoming = Color(0xFFFFFFFF) // White with subtle shadow

// Dark Theme - Sleek Modern Dark Slate/Pine
val DarkBackground = Color(0xFF0E1612)         // Deep slate pine
val DarkSurface = Color(0xFF141F1A)            // Soft dark surface
val DarkCard = Color(0xFF1A2822)               // Elevated dark card
val DarkCardBorder = Color(0xFF243830)         // Subtle dark green outline
val DarkSurfaceSubtle = Color(0xFF21322B)
val DarkTextPrimary = Color(0xFFF2F7F4)        // Crisp light text
val DarkTextSecondary = Color(0xFF9FB2A7)      // Readable secondary text
val DarkChatBubbleOutgoing = Color(0xFF005C4B) // Dark mode outgoing green
val DarkChatBubbleIncoming = Color(0xFF1F2C34)

// Functional Status Colors
val StatusOnline = Color(0xFF16A34A)           // Confirmed online green
val StatusOffline = Color(0xFF94A3B8)          // Calm slate gray
val StatusConnecting = Color(0xFFF59E0B)       // Warm amber
val StatusAlert = Color(0xFFEF4444)            // Coral red error
val StatusSos = Color(0xFFDC2626)              // Vibrant SOS emergency red

// Soft Blue, Teal & Safety Accent Palette
val BrandTeal = Color(0xFF0D9488)              // Modern safety teal
val BrandTealSoft = Color(0xFFE6FFFA)          // Soft pastel teal container
val BrandBluePrimary = Color(0xFF0284C7)       // Family safety sky blue
val BrandBlueSoft = Color(0xFFE0F2FE)          // Soft blue container
val BrandPurple = Color(0xFF8B5CF6)            // Screen time purple
val BrandPurpleSoft = Color(0xFFF3E8FF)

// Compatibility Aliases for existing code
val WhatsAppTealDark = BrandGreenPrimary
val WhatsAppTealMedium = BrandGreenDeep
val WhatsAppEmerald = BrandGreenAccent
val WhatsAppLightGreen = BrandGreenSoft
val DarkBg = DarkBackground
val LightBg = LightBackground
val OnlineGreen = StatusOnline
val PrivacyAmber = StatusConnecting
val AlertRed = StatusAlert
