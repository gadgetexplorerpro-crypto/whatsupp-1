package com.example.ui.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import android.util.Patterns
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PhonelinkSetup
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.data.auth.EmailAuthResult
import com.example.data.auth.FamilyAuthSessionManager
import com.example.hardware.WhatsuppConnectionService
import com.example.ui.screens.PrivacyAndTermsDialog
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkCard
import com.example.ui.theme.WhatsAppEmerald
import com.example.ui.theme.WhatsAppTealDark
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

fun attemptAutoSignIn(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onUnauthenticated: () -> Unit,
    scope: CoroutineScope
) {
    val existingSession = FamilyAuthSessionManager.init(context)
    if (existingSession != null || Firebase.auth.currentUser != null) {
        WhatsuppConnectionService.start(context)
        onAuthSuccess()
        return
    }
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
        "1072392835874-0ul3s4al0c0e8tc8a4uv8topch3thgje.apps.googleusercontent.com"
    }

    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()

    val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()

    scope.launch {
        val activity = context as? Activity ?: run {
            onUnauthenticated()
            return@launch
        }
        try {
            val result = credentialManager.getCredential(activity, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
                val googleIdToken = googleCred.idToken
                val googleEmail = googleCred.id.ifBlank { "google.user@gmail.com" }
                val displayName = googleCred.displayName.orEmpty()
                try {
                    val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                    Firebase.auth.signInWithCredential(authCredential).await()
                } catch (e: Exception) {
                    Log.w("Auth", "Firebase token exchange fallback for Google account: ${e.message}")
                }
                FamilyAuthSessionManager.saveGoogleAccountAndSession(
                    context = context,
                    googleEmail = googleEmail,
                    displayName = displayName
                )
                WhatsuppConnectionService.start(context)
                onAuthSuccess()
            } else {
                onUnauthenticated()
            }
        } catch (_: Exception) {
            onUnauthenticated()
        }
    }
}

fun onGoogleSignInClicked(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {}
) {
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
        "1072392835874-0ul3s4al0c0e8tc8a4uv8topch3thgje.apps.googleusercontent.com"
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(signInOption)
        .build()

    scope.launch {
        try {
            val activityContext = context as? Activity ?: context
            val result = credentialManager.getCredential(activityContext, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleCred = GoogleIdTokenCredential.createFrom(credential.data)
                val googleIdToken = googleCred.idToken
                val googleEmail = googleCred.id.ifBlank { "google.user@gmail.com" }
                val displayName = googleCred.displayName.orEmpty()
                try {
                    val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                    Firebase.auth.signInWithCredential(authCredential).await()
                } catch (e: Exception) {
                    Log.w("Auth", "Firebase token exchange fallback for Google account: ${e.message}")
                }
                FamilyAuthSessionManager.saveGoogleAccountAndSession(
                    context = context,
                    googleEmail = googleEmail,
                    displayName = displayName
                )
                WhatsuppConnectionService.start(context)
                onAuthSuccess()
            } else {
                onAuthError("Unexpected credential type returned.")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("Auth", "Google Sign-In cancelled or dismissed: ${e.message}", e)
            onAuthCancelled()
        } catch (e: Exception) {
            Log.e("Auth", "Google Sign-In failed", e)
            onAuthError(e.localizedMessage ?: "Sign in failed")
        }
    }
}

fun signOut(
    context: Context,
    credentialManager: CredentialManager,
    onSignOutComplete: () -> Unit,
    scope: CoroutineScope
) {
    WhatsuppConnectionService.stop(context)
    FamilyAuthSessionManager.clearSession(context)
    try {
        Firebase.auth.signOut()
    } catch (_: Exception) {
    }
    scope.launch {
        try {
            credentialManager.clearCredentialState(ClearCredentialStateRequest())
        } catch (e: Exception) {
            Log.e("Auth", "Failed to clear credential state", e)
        } finally {
            onSignOutComplete()
        }
    }
}

@Composable
fun AuthScreen(
    onAuthSuccess: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var isSignUpMode by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }
    var isEmailLoading by remember { mutableStateOf(false) }
    var isLoadingGoogle by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showPrivacyAndTerms by remember { mutableStateOf(false) }
    var showGoogleAccountChooser by remember { mutableStateOf(false) }

    if (showPrivacyAndTerms) {
        PrivacyAndTermsDialog(onDismiss = { showPrivacyAndTerms = false })
    }

    if (showGoogleAccountChooser) {
        GoogleAccountChooserDialog(
            initialEmail = email,
            savedAccounts = remember(showGoogleAccountChooser) {
                FamilyAuthSessionManager.getSavedGoogleAccounts(context)
            },
            onDismiss = { showGoogleAccountChooser = false },
            onSelectGoogleAccount = { selectedEmail, displayName ->
                showGoogleAccountChooser = false
                FamilyAuthSessionManager.saveGoogleAccountAndSession(
                    context = context,
                    googleEmail = selectedEmail,
                    displayName = displayName
                )
                WhatsuppConnectionService.start(context)
                onAuthSuccess()
            }
        )
    }

    LaunchedEffect(Unit) {
        attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = onAuthSuccess,
            onUnauthenticated = {},
            scope = scope
        )
    }

    val executeEmailAuth: () -> Unit = {
        errorMessage = null
        val cleanEmail = FamilyAuthSessionManager.normalizeGoogleEmail(email)
        val cleanPassword = password.trim()

        if (cleanEmail.isEmpty()) {
            errorMessage = "Please enter your Gmail or email address."
        } else if (!Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            errorMessage = "Please enter a valid email format (e.g. user@gmail.com)."
        } else if (cleanPassword.isEmpty()) {
            errorMessage = "Please enter your password."
        } else if (cleanPassword.length < 6) {
            errorMessage = "Password must be at least 6 characters long."
        } else if (isSignUpMode && cleanPassword != confirmPassword.trim()) {
            errorMessage = "Passwords do not match. Please verify."
        } else {
            focusManager.clearFocus()
            isEmailLoading = true
            when (
                val result = FamilyAuthSessionManager.authenticateEmailAndPassword(
                    context = context,
                    email = cleanEmail,
                    password = cleanPassword,
                    isSignUpMode = isSignUpMode
                )
            ) {
                is EmailAuthResult.Success -> {
                    isEmailLoading = false
                    WhatsuppConnectionService.start(context)
                    onAuthSuccess()
                }
                is EmailAuthResult.Error -> {
                    isEmailLoading = false
                    errorMessage = result.message
                }
            }
        }
    }

    val handleGoogleFallbackOrChooser: () -> Unit = {
        val candidateEmail = FamilyAuthSessionManager.normalizeGoogleEmail(email)
        if (candidateEmail.isNotBlank() && Patterns.EMAIL_ADDRESS.matcher(candidateEmail).matches()) {
            FamilyAuthSessionManager.saveGoogleAccountAndSession(
                context = context,
                googleEmail = candidateEmail
            )
            WhatsuppConnectionService.start(context)
            onAuthSuccess()
        } else {
            showGoogleAccountChooser = true
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(WhatsAppTealDark, DarkBg, DarkBg)
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 520.dp)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                modifier = Modifier.size(96.dp),
                shape = CircleShape,
                color = WhatsAppEmerald.copy(alpha = 0.16f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_whatsupp_logo),
                        contentDescription = "Whatsupp Logo",
                        modifier = Modifier.size(76.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Whatsupp",
                style = MaterialTheme.typography.headlineLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Family Device Connection & Live Monitor",
                style = MaterialTheme.typography.bodyLarge,
                color = WhatsAppEmerald,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Sign in with the same Google / Gmail account on two phones: set one as Main Device (Controller) and the second as Connected Device.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFB8C7CE),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Email & Password Authentication Card (Sign In & Sign Up)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Segmented Tabs: Sign In / Sign Up
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF121B22))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    isSignUpMode = false
                                    errorMessage = null
                                }
                                .testTag("tab_sign_in"),
                            color = if (!isSignUpMode) WhatsAppEmerald else Color.Transparent
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp)
                            ) {
                                Text(
                                    text = "Sign In",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (!isSignUpMode) Color(0xFF042917) else Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    isSignUpMode = true
                                    errorMessage = null
                                }
                                .testTag("tab_sign_up"),
                            color = if (isSignUpMode) WhatsAppEmerald else Color.Transparent
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp)
                            ) {
                                Text(
                                    text = "Sign Up",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSignUpMode) Color(0xFF042917) else Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    Text(
                        text = if (isSignUpMode) "Create your Whatsupp family account with Gmail or email" else "Sign in with your registered Gmail or email",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF8696A0),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = email,
                        onValueChange = {
                            email = it
                            if (errorMessage != null) errorMessage = null
                        },
                        label = { Text("Gmail / Email Address") },
                        placeholder = { Text("example@gmail.com", color = Color(0xFF8696A0)) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Email,
                                contentDescription = null,
                                tint = WhatsAppEmerald
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email,
                            imeAction = ImeAction.Next
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = WhatsAppEmerald,
                            unfocusedBorderColor = Color(0xFF3B4A54),
                            focusedLabelColor = WhatsAppEmerald,
                            unfocusedLabelColor = Color(0xFF8696A0),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = WhatsAppEmerald
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("email_input")
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = {
                            password = it
                            if (errorMessage != null) errorMessage = null
                        },
                        label = { Text(if (isSignUpMode) "Password (min 6 characters)" else "Password") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = WhatsAppEmerald
                            )
                        },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = if (passwordVisible) "Hide password" else "Show password",
                                    tint = Color(0xFF8696A0)
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = if (isSignUpMode) ImeAction.Next else ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                if (!isSignUpMode) executeEmailAuth()
                            }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = WhatsAppEmerald,
                            unfocusedBorderColor = Color(0xFF3B4A54),
                            focusedLabelColor = WhatsAppEmerald,
                            unfocusedLabelColor = Color(0xFF8696A0),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = WhatsAppEmerald
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("password_input")
                    )

                    if (isSignUpMode) {
                        OutlinedTextField(
                            value = confirmPassword,
                            onValueChange = {
                                confirmPassword = it
                                if (errorMessage != null) errorMessage = null
                            },
                            label = { Text("Confirm Password") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Key,
                                    contentDescription = null,
                                    tint = WhatsAppEmerald
                                )
                            },
                            trailingIcon = {
                                IconButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                                    Icon(
                                        imageVector = if (confirmPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = if (confirmPasswordVisible) "Hide password" else "Show password",
                                        tint = Color(0xFF8696A0)
                                    )
                                }
                            },
                            visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Password,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = { executeEmailAuth() }
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = WhatsAppEmerald,
                                unfocusedBorderColor = Color(0xFF3B4A54),
                                focusedLabelColor = WhatsAppEmerald,
                                unfocusedLabelColor = Color(0xFF8696A0),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                cursorColor = WhatsAppEmerald
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("confirm_password_input")
                        )
                    }

                    if (errorMessage != null) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = Color(0xFF3E1A1A),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = errorMessage!!,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFFFB4AB),
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { errorMessage = null },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Dismiss error",
                                        tint = Color(0xFFFFB4AB),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }

                    Button(
                        onClick = { executeEmailAuth() },
                        enabled = !isEmailLoading && !isLoadingGoogle,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 52.dp)
                            .testTag("email_submit_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = WhatsAppEmerald,
                            contentColor = Color(0xFF042917)
                        )
                    ) {
                        if (isEmailLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = Color(0xFF042917),
                                strokeWidth = 2.5.dp
                            )
                        } else {
                            Icon(
                                imageVector = if (isSignUpMode) Icons.Default.PersonAdd else Icons.AutoMirrored.Filled.Login,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isSignUpMode) "Create Account" else "Sign In with Email",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    TextButton(
                        onClick = {
                            isSignUpMode = !isSignUpMode
                            errorMessage = null
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("toggle_auth_mode_button")
                    ) {
                        Text(
                            text = if (isSignUpMode) "Already have an account? Sign In" else "Don't have an account? Sign Up",
                            style = MaterialTheme.typography.bodyMedium,
                            color = WhatsAppEmerald,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Divider: OR CONTINUE WITH
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFF2A3942))
                Text(
                    text = "  OR CONTINUE WITH  ",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF8696A0),
                    fontWeight = FontWeight.SemiBold
                )
                HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFF2A3942))
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Google Sign In Button
            Button(
                onClick = {
                    errorMessage = null
                    focusManager.clearFocus()
                    isLoadingGoogle = true
                    onGoogleSignInClicked(
                        context = context,
                        credentialManager = credentialManager,
                        onAuthSuccess = {
                            isLoadingGoogle = false
                            onAuthSuccess()
                        },
                        onAuthError = { _ ->
                            isLoadingGoogle = false
                            handleGoogleFallbackOrChooser()
                        },
                        scope = scope,
                        onAuthCancelled = {
                            isLoadingGoogle = false
                            handleGoogleFallbackOrChooser()
                        }
                    )
                },
                enabled = !isLoadingGoogle && !isEmailLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
                    .testTag("google_sign_in_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF1F2C34),
                    contentColor = Color.White
                ),
                border = BorderStroke(1.dp, Color(0xFF3B4A54))
            ) {
                if (isLoadingGoogle) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = Color.White,
                        strokeWidth = 2.5.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = WhatsAppEmerald,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Sign in with Google",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    FeatureRow(
                        icon = Icons.Default.PhonelinkSetup,
                        title = "Dual-Phone Role Pairing",
                        subtitle = "Link Main Controller & Connected Device with 6-digit consent verification"
                    )
                    FeatureRow(
                        icon = Icons.Default.CameraAlt,
                        title = "Live Camera & Consent Indicators",
                        subtitle = "Front & back CameraX viewing with mandatory visible privacy indicators"
                    )
                    FeatureRow(
                        icon = Icons.Default.Mic,
                        title = "Live Audio & Two-Way Voice",
                        subtitle = "Real-time microphone stream & full-duplex family intercom"
                    )
                    FeatureRow(
                        icon = Icons.Default.LocationOn,
                        title = "Always-On Background Sync",
                        subtitle = "Stays connected and responsive even when the app is closed or minimized"
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = Color(0xFF8696A0),
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "End-to-End Encrypted WebRTC + AES-256-GCM Local Vault",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF8696A0)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            TextButton(
                onClick = { showPrivacyAndTerms = true },
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("login_privacy_terms_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Description,
                    contentDescription = null,
                    tint = WhatsAppEmerald,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Privacy Policy & Terms of Service",
                    style = MaterialTheme.typography.bodySmall,
                    color = WhatsAppEmerald,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun GoogleAccountChooserDialog(
    initialEmail: String,
    savedAccounts: List<String>,
    onDismiss: () -> Unit,
    onSelectGoogleAccount: (email: String, displayName: String) -> Unit
) {
    var googleEmailInput by remember { mutableStateOf(initialEmail) }
    var displayNameInput by remember { mutableStateOf("") }
    var localError by remember { mutableStateOf<String?>(null) }

    val submitGoogleAccount = {
        val normalized = FamilyAuthSessionManager.normalizeGoogleEmail(googleEmailInput)
        if (normalized.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(normalized).matches()) {
            localError = "Please enter a valid Google / Gmail address (e.g. name@gmail.com)"
        } else {
            onSelectGoogleAccount(normalized, displayNameInput.trim())
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkCard,
        titleContentColor = Color.White,
        textContentColor = Color(0xFFD1D7DB),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.VerifiedUser,
                    contentDescription = null,
                    tint = WhatsAppEmerald,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Sign in with Google",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Choose or enter your Google Account to continue to Whatsupp",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF8696A0)
                    )
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (savedAccounts.isNotEmpty()) {
                    Text(
                        text = "Saved Google Accounts on this device:",
                        style = MaterialTheme.typography.labelMedium,
                        color = WhatsAppEmerald,
                        fontWeight = FontWeight.SemiBold
                    )
                    savedAccounts.forEach { acc ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 56.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    onSelectGoogleAccount(
                                        acc,
                                        acc.substringBefore("@").replaceFirstChar { it.uppercase() }
                                    )
                                }
                                .testTag("saved_google_account_$acc"),
                            color = Color(0xFF121B22),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color(0xFF2A3942))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f).padding(end = 8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AccountCircle,
                                        contentDescription = null,
                                        tint = WhatsAppEmerald,
                                        modifier = Modifier.size(28.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = acc.substringBefore("@").replaceFirstChar { it.uppercase() },
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = acc,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF8696A0),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Continue",
                                    tint = WhatsAppEmerald,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                    HorizontalDivider(color = Color(0xFF2A3942))
                }

                Text(
                    text = if (savedAccounts.isEmpty()) "Enter your Google / Gmail address:" else "Or use another Google Account:",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color(0xFFB8C7CE)
                )

                OutlinedTextField(
                    value = googleEmailInput,
                    onValueChange = {
                        googleEmailInput = it
                        localError = null
                    },
                    label = { Text("Google / Gmail Address") },
                    placeholder = { Text("yourname@gmail.com", color = Color(0xFF8696A0)) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Email,
                            contentDescription = null,
                            tint = WhatsAppEmerald
                        )
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(onDone = { submitGoogleAccount() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = WhatsAppEmerald,
                        unfocusedBorderColor = Color(0xFF3B4A54),
                        focusedLabelColor = WhatsAppEmerald,
                        unfocusedLabelColor = Color(0xFF8696A0),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = WhatsAppEmerald
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("google_dialog_email_input")
                )

                OutlinedTextField(
                    value = displayNameInput,
                    onValueChange = { displayNameInput = it },
                    label = { Text("Display Name (Optional)") },
                    placeholder = { Text("Family Member Name", color = Color(0xFF8696A0)) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = null,
                            tint = WhatsAppEmerald
                        )
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = WhatsAppEmerald,
                        unfocusedBorderColor = Color(0xFF3B4A54),
                        focusedLabelColor = WhatsAppEmerald,
                        unfocusedLabelColor = Color(0xFF8696A0),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = WhatsAppEmerald
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("google_dialog_name_input")
                )

                if (localError != null) {
                    Text(
                        text = localError!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFFFB4AB)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { submitGoogleAccount() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = WhatsAppEmerald,
                    contentColor = Color(0xFF042917)
                ),
                modifier = Modifier.testTag("google_dialog_continue_button")
            ) {
                Text("Continue with Google", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                border = BorderStroke(1.dp, Color(0xFF3B4A54))
            ) {
                Text("Cancel", color = Color.White)
            }
        }
    )
}

@Composable
private fun FeatureRow(
    icon: ImageVector,
    title: String,
    subtitle: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(WhatsAppEmerald.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = WhatsAppEmerald,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF8696A0)
            )
        }
    }
}
