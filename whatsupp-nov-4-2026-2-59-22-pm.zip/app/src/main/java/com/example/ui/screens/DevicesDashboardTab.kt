package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.ConnectionEvent
import com.example.data.model.FamilyDevice
import com.example.ui.LocalDashboardState
import com.example.ui.UiState
import com.example.ui.theme.BrandGreenAccent
import com.example.ui.theme.BrandGreenDeep
import com.example.ui.theme.BrandGreenPrimary
import com.example.ui.theme.BrandGreenSoft
import com.example.ui.theme.StatusAlert
import com.example.ui.theme.StatusOffline
import com.example.ui.theme.StatusOnline
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun DevicesDashboardTab(
    localState: LocalDashboardState,
    devicesState: UiState<List<FamilyDevice>>,
    historyState: UiState<List<ConnectionEvent>>,
    onSwitchRole: (String) -> Unit,
    onUpdateDeviceName: (String) -> Unit,
    onCompletePairing: (String) -> Unit,
    onSelectTargetDevice: (String) -> Unit,
    onUpdateConsent: (Boolean, Boolean, Boolean) -> Unit,
    onToggleAutoReconnect: (Boolean) -> Unit,
    onSendRemoteCommand: (String) -> Unit,
    onRequestPermissions: () -> Unit,
    onNavigateToTab: (Int) -> Unit,
    onOpenAccountPrivacy: () -> Unit = {},
    onRemoveDevice: (String) -> Unit = {}
) {
    var showAddDeviceDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    val allDevices = (devicesState as? UiState.Success)?.data ?: emptyList()
    // Other devices paired in this family network
    val remoteDevices = allDevices.filter { it.id != localState.thisDeviceId }
    val history = (historyState as? UiState.Success)?.data ?: emptyList()

    if (showAddDeviceDialog) {
        SimpleDevicePairingDialog(
            myPairingCode = localState.pairingCode,
            onCompletePairing = onCompletePairing,
            onDismiss = { showAddDeviceDialog = false }
        )
    }

    if (showSettingsDialog) {
        SettingsDialog(
            localState = localState,
            historyEvents = history,
            userEmail = localState.thisDeviceName,
            onSwitchRole = onSwitchRole,
            onUpdateDeviceName = onUpdateDeviceName,
            onUpdateConsent = onUpdateConsent,
            onToggleAutoReconnect = onToggleAutoReconnect,
            onOpenAccountPrivacy = onOpenAccountPrivacy,
            onDismiss = { showSettingsDialog = false }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("devices_dashboard_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Simple Friendly Header
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 12.dp)
                    ) {
                        Text(
                            text = "Whatsupp",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Your connected devices",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    IconButton(
                        onClick = { showSettingsDialog = true },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .testTag("settings_gear_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }

        // 2. This Phone Role Card (Controller or Connected Phone)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(BrandGreenSoft),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PhoneAndroid,
                                    contentDescription = null,
                                    tint = BrandGreenPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = localState.thisDeviceName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "This Phone • Battery ${localState.batteryLevel}%",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        // Online indicator pill
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (localState.isOnline) StatusOnline.copy(alpha = 0.12f) else StatusOffline.copy(alpha = 0.12f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (localState.isOnline) StatusOnline else StatusOffline)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (localState.isOnline) "Active" else "Offline",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (localState.isOnline) StatusOnline else StatusOffline
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

                    Text(
                        text = "This Phone's Mode:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FilterChip(
                            selected = localState.thisDeviceRole == "CONTROLLER",
                            onClick = { onSwitchRole("CONTROLLER") },
                            label = {
                                Text(
                                    text = "Controller",
                                    fontWeight = if (localState.thisDeviceRole == "CONTROLLER") FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            leadingIcon = if (localState.thisDeviceRole == "CONTROLLER") {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                            } else null,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BrandGreenSoft,
                                selectedLabelColor = BrandGreenPrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("role_controller_chip")
                        )

                        FilterChip(
                            selected = localState.thisDeviceRole == "CONNECTED",
                            onClick = { onSwitchRole("CONNECTED") },
                            label = {
                                Text(
                                    text = "Connected Phone",
                                    fontWeight = if (localState.thisDeviceRole == "CONNECTED") FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            leadingIcon = if (localState.thisDeviceRole == "CONNECTED") {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                            } else null,
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BrandGreenSoft,
                                selectedLabelColor = BrandGreenPrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("role_connected_chip")
                        )
                    }
                }
            }
        }

        // 3. Simple Prominent "Add Device" Button
        item {
            Button(
                onClick = { showAddDeviceDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 54.dp)
                    .testTag("add_device_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrandGreenPrimary
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Add Device",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 4. Remote Connected Devices Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Paired Phones (${remoteDevices.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 5. Empty State if no remote devices
        if (remoteDevices.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(BrandGreenSoft),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhoneAndroid,
                                contentDescription = null,
                                tint = BrandGreenPrimary,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Text(
                            text = "No other phones paired yet",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Tap 'Add Device' above to connect your family phone in 5 simple steps.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        } else {
            // Render clean, modern device cards
            items(remoteDevices, key = { it.id }) { device ->
                PairedDeviceCard(
                    device = device,
                    isSelected = localState.selectedTargetDeviceId == device.id,
                    onSelect = { onSelectTargetDevice(device.id) },
                    onNavigateToCamera = {
                        onSelectTargetDevice(device.id)
                        onNavigateToTab(1)
                    },
                    onNavigateToVoice = {
                        onSelectTargetDevice(device.id)
                        onNavigateToTab(2)
                    },
                    onNavigateToLocation = {
                        onSelectTargetDevice(device.id)
                        onNavigateToTab(3)
                    },
                    onNavigateToChat = {
                        onSelectTargetDevice(device.id)
                        onNavigateToTab(4)
                    },
                    onRemove = { onRemoveDevice(device.id) }
                )
            }
        }
    }
}

/**
 * Beautiful, clean Paired Phone Card.
 * Displays:
 * - Device name
 * - Online / Offline status
 * - Battery percentage
 * - Last connected time
 * - Connection status
 * - 4 Clear Actions: Camera | Voice | Location | Chat
 */
@Composable
private fun PairedDeviceCard(
    device: FamilyDevice,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onNavigateToCamera: () -> Unit,
    onNavigateToVoice: () -> Unit,
    onNavigateToLocation: () -> Unit,
    onNavigateToChat: () -> Unit,
    onRemove: () -> Unit = {}
) {
    val isOnline = device.isOnline
    var showDeleteConfirm by remember { mutableStateOf(false) }

    if (showDeleteConfirm) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            icon = { Icon(Icons.Default.Close, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Remove Device?") },
            text = { Text("Are you sure you want to remove '${device.deviceName}' from your connected family devices?") },
            confirmButton = {
                Button(
                    onClick = {
                        onRemove()
                        showDeleteConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Remove")
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    val lastSeenFormatted = remember(device.updatedAt) {
        val lastSeenMs = device.updatedAt?.toDate()?.time ?: System.currentTimeMillis()
        val diffMinutes = (System.currentTimeMillis() - lastSeenMs) / 60000L
        when {
            diffMinutes < 1L -> "Just now"
            diffMinutes < 60L -> "${diffMinutes}m ago"
            else -> SimpleDateFormat("h:mm a", Locale.getDefault()).format(lastSeenMs)
        }
    }

    val connectionStatusText = when {
        isOnline && (device.activeCameraFacing != "OFF" || device.isMicStreaming) -> "Streaming active"
        isOnline -> "Connected & Ready"
        else -> "Offline"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("device_card_${device.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) BrandGreenPrimary else MaterialTheme.colorScheme.outline
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Top Row: Device Name, Delete button & Online Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (isOnline) BrandGreenSoft else MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhoneAndroid,
                            contentDescription = null,
                            tint = if (isOnline) BrandGreenPrimary else StatusOffline,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = device.deviceName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = connectionStatusText,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isOnline) StatusOnline else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Online/Offline badge
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isOnline) StatusOnline.copy(alpha = 0.12f) else StatusOffline.copy(alpha = 0.12f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (isOnline) StatusOnline else StatusOffline)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isOnline) "Online" else "Offline",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isOnline) StatusOnline else StatusOffline
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = { showDeleteConfirm = true },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("remove_device_${device.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Remove Device",
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Middle Row: Battery & Last Seen Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.BatteryFull,
                        contentDescription = "Battery",
                        tint = if (device.batteryLevel < 20) StatusAlert else BrandGreenPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${device.batteryLevel}% Battery",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                }

                Text(
                    text = "Last seen: $lastSeenFormatted",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

            // Four Clear Action Buttons in a responsive 2x2 Grid: Camera | Voice / Location | Chat
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DeviceActionButton(
                        icon = Icons.Default.Videocam,
                        label = "Camera",
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToCamera,
                        testTag = "action_camera_${device.id}"
                    )
                    DeviceActionButton(
                        icon = Icons.Default.Mic,
                        label = "Voice",
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToVoice,
                        testTag = "action_voice_${device.id}"
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DeviceActionButton(
                        icon = Icons.Default.LocationOn,
                        label = "Location",
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToLocation,
                        testTag = "action_location_${device.id}"
                    )
                    DeviceActionButton(
                        icon = Icons.AutoMirrored.Filled.Chat,
                        label = "Chat",
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToChat,
                        testTag = "action_chat_${device.id}"
                    )
                }
            }
        }
    }
}

@Composable
private fun DeviceActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    testTag: String
) {
    Button(
        onClick = onClick,
        modifier = modifier
            .heightIn(min = 48.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = BrandGreenSoft,
            contentColor = BrandGreenPrimary
        ),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
