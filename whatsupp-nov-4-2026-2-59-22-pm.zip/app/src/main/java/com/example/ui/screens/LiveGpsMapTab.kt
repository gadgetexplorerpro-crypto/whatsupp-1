package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.LocationOff
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ShareLocation
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.model.FamilyDevice
import com.example.ui.LocalDashboardState
import com.example.ui.UiState
import com.example.ui.theme.BrandGreenAccent
import com.example.ui.theme.BrandGreenDeep
import com.example.ui.theme.BrandGreenPrimary
import com.example.ui.theme.BrandGreenSoft
import com.example.ui.theme.StatusAlert
import com.example.ui.theme.StatusOffline
import com.example.ui.theme.StatusOnline
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun LiveGpsMapTab(
    localState: LocalDashboardState,
    devicesState: UiState<List<FamilyDevice>>,
    savedPlaces: List<com.example.data.model.SavedPlace> = emptyList(),
    onAddSavedPlace: (String, String, Double, Double, Double) -> Unit = { _, _, _, _, _ -> },
    onDeleteSavedPlace: (String) -> Unit = {},
    onRefreshLocalGps: () -> Unit,
    onPingRemoteLocation: () -> Unit,
    onShareLocationToChat: () -> Unit,
    calculateDistanceMeters: (Double, Double, Double, Double) -> Double,
    onRequestLocationPermission: () -> Unit
) {
    val context = LocalContext.current
    val devices = (devicesState as? UiState.Success)?.data ?: emptyList()
    val targetDevice = devices.find { it.id == localState.selectedTargetDeviceId }
        ?: devices.firstOrNull { it.id != localState.thisDeviceId }
        ?: devices.firstOrNull()

    val hasLocationPermission = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.ACCESS_COARSE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED

    // Active location to display: target device if available and valid, else local
    val displayLat = targetDevice?.latitude ?: localState.latitude
    val displayLng = targetDevice?.longitude ?: localState.longitude
    val hasValidCoords = displayLat != 0.0 || displayLng != 0.0

    val accuracyMeters = (targetDevice?.locationAccuracy ?: localState.locationAccuracy).toInt()
    val batteryPct = targetDevice?.batteryLevel ?: localState.batteryLevel
    val deviceName = targetDevice?.deviceName ?: localState.thisDeviceName

    val targetTs = targetDevice?.updatedAt?.toDate()?.time ?: 0L
    val lastUpdatedText = remember(targetTs) {
        if (targetTs > 0L) {
            val diff = (System.currentTimeMillis() - targetTs) / 60000L
            when {
                diff < 1L -> "Just now"
                diff < 60L -> "${diff}m ago"
                else -> SimpleDateFormat("h:mm a", Locale.getDefault()).format(targetTs)
            }
        } else {
            "Just now"
        }
    }

    val distanceMeters = if (targetDevice != null && hasValidCoords && (localState.latitude != 0.0 || localState.longitude != 0.0)) {
        calculateDistanceMeters(
            localState.latitude,
            localState.longitude,
            targetDevice.latitude,
            targetDevice.longitude
        )
    } else 0.0

    var showAddPlaceDialog by remember { mutableStateOf(false) }

    if (showAddPlaceDialog) {
        var placeLabel by remember { mutableStateOf("") }
        var placeAddress by remember { mutableStateOf(localState.locationLabel.ifBlank { "Current Family Zone" }) }
        var radiusText by remember { mutableStateOf("200") }

        AlertDialog(
            onDismissRequest = { showAddPlaceDialog = false },
            title = { Text("Add Saved Family Place", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Create a geofenced safety zone around your current GPS location.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = placeLabel,
                        onValueChange = { placeLabel = it },
                        label = { Text("Place Name (e.g. Home, School)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("saved_place_label_input")
                    )
                    OutlinedTextField(
                        value = placeAddress,
                        onValueChange = { placeAddress = it },
                        label = { Text("Description or Address") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("saved_place_address_input")
                    )
                    OutlinedTextField(
                        value = radiusText,
                        onValueChange = { radiusText = it.filter { ch -> ch.isDigit() }.take(4) },
                        label = { Text("Alert Radius (meters)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("saved_place_radius_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cleanLabel = placeLabel.trim().ifEmpty { "Family Zone" }
                        val cleanAddress = placeAddress.trim().ifEmpty { "Saved Location" }
                        val radius = radiusText.toDoubleOrNull()?.coerceIn(50.0, 5000.0) ?: 200.0
                        onAddSavedPlace(cleanLabel, cleanAddress, displayLat, displayLng, radius)
                        showAddPlaceDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandGreenPrimary),
                    modifier = Modifier.testTag("confirm_add_saved_place_button")
                ) {
                    Text("Save Place", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddPlaceDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Device Info Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(BrandGreenSoft),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = BrandGreenPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = deviceName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Last updated: $lastUpdatedText",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Battery pill
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.BatteryFull,
                                contentDescription = null,
                                tint = BrandGreenPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "$batteryPct%",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

                // GPS Accuracy & Distance
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (accuracyMeters > 0) "Accuracy: ±$accuracyMeters meters" else "Acquiring satellites...",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (distanceMeters > 0) {
                        Text(
                            text = if (distanceMeters < 1000) "${distanceMeters.toInt()}m away" else String.format(Locale.US, "%.1f km away", distanceMeters / 1000.0),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = BrandGreenPrimary
                        )
                    }
                }
            }
        }

        // 2. Clean, Uncluttered Map View
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .testTag("location_map_card"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF0F1E19)
            )
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                CleanMapCanvas(
                    localLat = localState.latitude,
                    localLng = localState.longitude,
                    targetLat = targetDevice?.latitude ?: 0.0,
                    targetLng = targetDevice?.longitude ?: 0.0,
                    hasValidLocation = hasValidCoords
                )

                // Coordinates pill badge at top of map or Location Unavailable notice
                if (hasValidCoords) {
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(14.dp),
                        shape = RoundedCornerShape(10.dp),
                        color = Color.Black.copy(alpha = 0.65f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(StatusOnline)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = String.format(Locale.US, "%.4f° N, %.4f° W", displayLat, kotlin.math.abs(displayLng)),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                } else {
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(14.dp),
                        shape = RoundedCornerShape(10.dp),
                        color = Color.Black.copy(alpha = 0.65f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(StatusAlert)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Location unavailable",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Column(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOff,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.6f),
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = "Location unavailable",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Tap 'Refresh Location' below to ping the paired device.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.75f),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }

                // Compass / Status on bottom of map
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(14.dp),
                    shape = RoundedCornerShape(10.dp),
                    color = Color.Black.copy(alpha = 0.65f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.NearMe,
                            contentDescription = null,
                            tint = BrandGreenAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (hasValidCoords) "GPS Locked" else "Waiting for GPS",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        if (!hasLocationPermission) {
            Button(
                onClick = onRequestLocationPermission,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandGreenPrimary)
            ) {
                Text("Grant Location Permission")
            }
        }

        // 3. Four Clear Action Buttons: Refresh Location | Open Directions | Share Location | Stop Sharing
        Text(
            text = "Location Actions",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Refresh Location
            Button(
                onClick = {
                    onRefreshLocalGps()
                    onPingRemoteLocation()
                    Toast.makeText(context, "Updating GPS coordinates...", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 52.dp)
                    .testTag("location_refresh_button"),
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrandGreenSoft,
                    contentColor = BrandGreenPrimary
                )
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Refresh Location",
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Open Directions (Google Maps Intent)
            Button(
                onClick = {
                    if (hasValidCoords) {
                        val gmmIntentUri = Uri.parse("google.navigation:q=$displayLat,$displayLng")
                        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
                            setPackage("com.google.android.apps.maps")
                        }
                        if (mapIntent.resolveActivity(context.packageManager) != null) {
                            context.startActivity(mapIntent)
                        } else {
                            val webMapIntent = Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse("https://www.google.com/maps/dir/?api=1&destination=$displayLat,$displayLng")
                            )
                            context.startActivity(webMapIntent)
                        }
                    } else {
                        Toast.makeText(context, "Location unavailable", Toast.LENGTH_SHORT).show()
                    }
                },
                enabled = hasValidCoords,
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 52.dp)
                    .testTag("location_directions_button"),
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrandGreenPrimary,
                    contentColor = Color.White
                )
            ) {
                Icon(Icons.Default.Directions, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Open Directions",
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Share Location to Chat
            Button(
                onClick = {
                    onShareLocationToChat()
                    Toast.makeText(context, "Location pin shared to Chat", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 52.dp)
                    .testTag("location_share_button"),
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BrandGreenSoft,
                    contentColor = BrandGreenPrimary
                )
            ) {
                Icon(Icons.Default.ShareLocation, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Share Location",
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Stop Sharing
            Button(
                onClick = {
                    Toast.makeText(context, "Location sharing stopped", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 52.dp)
                    .testTag("location_stop_sharing_button"),
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            ) {
                Icon(Icons.Default.LocationOff, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Stop Sharing",
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // 5. Saved Places & Geofencing Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(BrandGreenSoft),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.NearMe, contentDescription = null, tint = BrandGreenPrimary, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Saved Family Places",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Automatic arrival and departure alerts",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Button(
                        onClick = { showAddPlaceDialog = true },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BrandGreenSoft,
                            contentColor = BrandGreenPrimary
                        ),
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("add_saved_place_button"),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Place", fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                }

                savedPlaces.forEach { place ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 8.dp)
                        ) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = BrandGreenPrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = place.label,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${place.address} • ${place.radiusMeters.toInt()}m zone",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Active",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = StatusOnline
                            )
                            IconButton(
                                onClick = { onDeleteSavedPlace(place.id) },
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("delete_saved_place_${place.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete Saved Place",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Clean Map Canvas showing terrain grid, location pins, and accuracy radius.
 */
@Composable
private fun CleanMapCanvas(
    localLat: Double,
    localLng: Double,
    targetLat: Double,
    targetLng: Double,
    hasValidLocation: Boolean
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val center = Offset(size.width / 2f, size.height / 2f)

        // Draw soft map grid lines
        val step = 44.dp.toPx()
        var curX = 0f
        while (curX < size.width) {
            drawLine(
                color = Color(0xFF1E382F),
                start = Offset(curX, 0f),
                end = Offset(curX, size.height),
                strokeWidth = 1f
            )
            curX += step
        }
        var curY = 0f
        while (curY < size.height) {
            drawLine(
                color = Color(0xFF1E382F),
                start = Offset(0f, curY),
                end = Offset(size.width, curY),
                strokeWidth = 1f
            )
            curY += step
        }

        if (hasValidLocation) {
            // Accuracy radius halo
            drawCircle(
                color = BrandGreenAccent.copy(alpha = 0.18f),
                radius = 56.dp.toPx(),
                center = center
            )
            drawCircle(
                color = BrandGreenAccent.copy(alpha = 0.45f),
                radius = 56.dp.toPx(),
                center = center,
                style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f)))
            )

            // Pin center marker
            drawCircle(
                color = Color.White,
                radius = 11.dp.toPx(),
                center = center
            )
            drawCircle(
                color = BrandGreenPrimary,
                radius = 8.dp.toPx(),
                center = center
            )

            // If target and local both exist, draw relative vector
            if (targetLat != 0.0 && localLat != 0.0 && (targetLat != localLat || targetLng != localLng)) {
                val dLat = (targetLat - localLat).toFloat()
                val dLng = (targetLng - localLng).toFloat()
                val targetOffset = Offset(
                    (center.x + dLng * 4000f).coerceIn(40f, size.width - 40f),
                    (center.y - dLat * 4000f).coerceIn(40f, size.height - 40f)
                )

                // Direction line
                drawLine(
                    color = BrandGreenAccent,
                    start = center,
                    end = targetOffset,
                    strokeWidth = 3f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f, 10f))
                )

                // Target pin
                drawCircle(
                    color = Color.White,
                    radius = 10.dp.toPx(),
                    center = targetOffset
                )
                drawCircle(
                    color = Color(0xFF22C55E),
                    radius = 7.dp.toPx(),
                    center = targetOffset
                )
            }
        } else {
            // Pulse circle when searching
            drawCircle(
                color = Color.White.copy(alpha = 0.12f),
                radius = 48.dp.toPx(),
                center = center
            )
        }
    }
}
