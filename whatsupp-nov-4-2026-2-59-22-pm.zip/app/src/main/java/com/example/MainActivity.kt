package com.example

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import android.content.pm.PackageManager
import com.example.data.auth.FamilyAuthSessionManager
import com.example.data.local.LocalVaultDatabase
import com.example.data.repository.WhatsuppRepository
import com.example.data.security.LocalCryptoManager
import com.example.hardware.DeviceHardwareManager
import com.example.hardware.WhatsuppConnectionService
import com.example.ui.WhatsuppViewModel
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOut
import com.example.ui.screens.AccountAndPrivacyDialog
import com.example.ui.screens.CameraXLivePreview
import com.example.ui.screens.DevicesDashboardTab
import com.example.ui.screens.EncryptedChatVaultTab
import com.example.ui.screens.LiveAudioVoiceTab
import com.example.ui.screens.LiveCameraTab
import com.example.ui.screens.LiveGpsMapTab
import com.example.ui.theme.BrandGreenPrimary
import com.example.ui.theme.BrandGreenSoft
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.PrivacyAmber
import com.example.ui.theme.StatusAlert
import com.example.ui.theme.WhatsAppEmerald
import com.example.ui.theme.WhatsAppTealDark
import com.example.ui.theme.WhatsuppTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WhatsuppViewModel.isForegroundActive = true
        val session = FamilyAuthSessionManager.init(this)
        if (session != null) {
            WhatsuppConnectionService.start(this)
        }
        enableEdgeToEdge()
        setContent {
            WhatsuppTheme {
                AppNavigation()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        WhatsuppViewModel.isForegroundActive = true
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) {
            WhatsuppViewModel.isForegroundActive = false
            if (FamilyAuthSessionManager.currentSession.value != null) {
                WhatsuppConnectionService.start(this, isBackgroundHandoff = true)
            }
        }
    }
}

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val authFlow = remember(auth) { auth.authStateFlow() }
    val currentUser by authFlow.collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val familySession by FamilyAuthSessionManager.currentSession.collectAsStateWithLifecycle()

    val activeUserId = familySession?.userId
        ?: currentUser?.email?.let { LocalCryptoManager.generateFamilyUserId(it) }
        ?: currentUser?.uid
    val activeEmail = familySession?.email ?: currentUser?.email ?: "Family Account"

    if (activeUserId == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        WhatsuppMainScreen(
            currentUserId = activeUserId,
            userEmail = activeEmail
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WhatsuppMainScreen(
    currentUserId: String,
    userEmail: String
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    LaunchedEffect(currentUserId) {
        WhatsuppConnectionService.start(context)
    }

    val viewModel: WhatsuppViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                val vaultDao = LocalVaultDatabase.getInstance(app).vaultDao()
                val hardware = DeviceHardwareManager(app)
                val defaultName = hardware.getDefaultDeviceName()
                WhatsuppViewModel(
                    repository = WhatsuppRepository(
                        db = db,
                        activeUserId = currentUserId,
                        pairingCodeProvider = {
                            FamilyAuthSessionManager.loadDeviceConfig(app, defaultName).pairingCode
                        }
                    ),
                    vaultDao = vaultDao,
                    hardwareManager = hardware,
                    currentUserId = currentUserId
                )
            }
        }
    )

    val localState by viewModel.localState.collectAsStateWithLifecycle()
    val devicesState by viewModel.devicesState.collectAsStateWithLifecycle()
    val messagesState by viewModel.messagesState.collectAsStateWithLifecycle()
    val historyState by viewModel.historyState.collectAsStateWithLifecycle()
    val savedVaultMedia by viewModel.savedVaultMedia.collectAsStateWithLifecycle()
    val savedPlaces by viewModel.savedPlaces.collectAsStateWithLifecycle()
    val safetyAlerts by viewModel.safetyAlerts.collectAsStateWithLifecycle()
    val appUsageReports by viewModel.appUsageReports.collectAsStateWithLifecycle()
    // Observe WebRTC signals continuously
    viewModel.signalsState.collectAsStateWithLifecycle()

    val lifecycleOwner = LocalLifecycleOwner.current
    var isActivityResumed by remember { mutableStateOf(true) }

    DisposableEffect(lifecycleOwner, viewModel) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START, Lifecycle.Event.ON_RESUME -> {
                    isActivityResumed = true
                    viewModel.onAppForegrounded()
                }
                Lifecycle.Event.ON_STOP -> {
                    isActivityResumed = false
                    val activity = context as? Activity
                    if (activity?.isChangingConfigurations != true) {
                        viewModel.onAppBackgrounded()
                    }
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var previousMainTab by rememberSaveable { mutableIntStateOf(0) }
    var showAccountPrivacyDialog by remember { mutableStateOf(false) }

    val navigateToTab: (Int) -> Unit = { target ->
        if (selectedTab in 0..4 && target in 5..7) {
            previousMainTab = selectedTab
        }
        selectedTab = target
    }

    val isSubScreen = selectedTab in 5..7

    BackHandler(enabled = true) {
        when {
            isSubScreen -> selectedTab = previousMainTab.coerceIn(0, 4)
            selectedTab != 0 -> selectedTab = 0
            else -> {
                viewModel.onAppBackgrounded()
                (context as? Activity)?.moveTaskToBack(true)
            }
        }
    }

    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        ) {
            viewModel.refreshGpsLocation()
        }
    }

    val requestAllPermissions = {
        val perms = buildList {
            add(Manifest.permission.CAMERA)
            add(Manifest.permission.RECORD_AUDIO)
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }.toTypedArray()
        permissionsLauncher.launch(perms)
    }

    LaunchedEffect(localState.activeCameraFacing) {
        if (localState.activeCameraFacing != "OFF") {
            val camGranted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
            if (!camGranted) {
                requestAllPermissions()
            }
        }
    }

    val isHardwareStreamingActive = localState.activeCameraFacing != "OFF" ||
        localState.isMicStreaming ||
        localState.isTwoWayVoiceActive

    val topBarTitle = when (selectedTab) {
        5 -> "Live Camera"
        6 -> "Voice & Audio"
        7 -> "Family Chat & Vault"
        else -> "Whatsupp"
    }

    val roleLabel = if (localState.thisDeviceRole == "CONTROLLER") "Controller" else "Connected"

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            Column {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    navigationIcon = {
                        if (isSubScreen) {
                            IconButton(
                                onClick = { selectedTab = previousMainTab.coerceIn(0, 4) },
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("top_back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    },
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (!isSubScreen) {
                                Image(
                                    painter = painterResource(id = R.drawable.ic_whatsupp_logo),
                                    contentDescription = "Whatsupp Logo",
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = topBarTitle,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "$roleLabel • $userEmail",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    },
                    actions = {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (localState.isOnline) OnlineGreen.copy(alpha = 0.12f) else PrivacyAmber.copy(alpha = 0.12f),
                            modifier = Modifier.padding(end = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (localState.isOnline) OnlineGreen else PrivacyAmber)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${localState.batteryLevel}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (localState.isOnline) OnlineGreen else PrivacyAmber,
                                    maxLines = 1
                                )
                            }
                        }
                        IconButton(
                            onClick = { showAccountPrivacyDialog = true },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("account_privacy_top_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Account & Data Privacy",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(
                            onClick = {
                                signOut(
                                    context = context,
                                    credentialManager = credentialManager,
                                    onSignOutComplete = {},
                                    scope = scope
                                )
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("sign_out_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Logout,
                                contentDescription = "Sign Out",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                )

                // Sub-screen Quick Switcher Bar (Camera | Voice | Chat) when inside any live communication screen
                AnimatedVisibility(visible = isSubScreen) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.surface
                    ) {
                        Column {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val subTabs = listOf(
                                    Triple(5, "Camera", Icons.Default.Videocam),
                                    Triple(6, "Voice", Icons.Default.Mic),
                                    Triple(7, "Chat", Icons.AutoMirrored.Filled.Chat)
                                )
                                subTabs.forEach { (tabIdx, label, icon) ->
                                    val isCurrent = selectedTab == tabIdx
                                    Surface(
                                        onClick = { navigateToTab(tabIdx) },
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (isCurrent) BrandGreenPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier
                                            .weight(1f)
                                            .heightIn(min = 48.dp)
                                            .testTag("sub_nav_tab_$tabIdx")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                                            horizontalArrangement = Arrangement.Center,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = icon,
                                                contentDescription = null,
                                                tint = if (isCurrent) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = label,
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isCurrent) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        }
                    }
                }

                if (showAccountPrivacyDialog) {
                    AccountAndPrivacyDialog(
                        userEmail = userEmail,
                        currentUserId = currentUserId,
                        onDismiss = { showAccountPrivacyDialog = false },
                        onDeleteAccountConfirmed = {
                            viewModel.deleteAccountAndAllData(
                                onComplete = {
                                    signOut(
                                        context = context,
                                        credentialManager = credentialManager,
                                        onSignOutComplete = {
                                            showAccountPrivacyDialog = false
                                        },
                                        scope = scope
                                    )
                                }
                            )
                        }
                    )
                }

                // Visible Hardware Privacy Indicator Banner when Camera or Mic is active
                AnimatedVisibility(visible = isHardwareStreamingActive) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = OnlineGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = buildString {
                                        append("Active: ")
                                        if (localState.activeCameraFacing != "OFF") append("Camera (${localState.activeCameraFacing}) ")
                                        if (localState.isMicStreaming) append("Live Mic ")
                                        if (localState.isTwoWayVoiceActive) append("Voice Call ")
                                    },
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Button(
                                onClick = {
                                    viewModel.setCameraMode("OFF")
                                    viewModel.toggleTwoWayVoice(false)
                                    viewModel.toggleMicStreaming(false)
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = StatusAlert,
                                    contentColor = Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .defaultMinSize(minWidth = 72.dp, minHeight = 48.dp)
                                    .testTag("stop_all_streaming_button")
                            ) {
                                Text(
                                    text = "Stop All",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                // Status notification banner
                AnimatedVisibility(visible = localState.statusBannerMessage != null) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.secondaryContainer
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = localState.statusBannerMessage.orEmpty(),
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(vertical = 4.dp),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            IconButton(
                                onClick = { viewModel.dismissBanner() },
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("dismiss_status_banner_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dismiss",
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                val items = listOf(
                    Triple(0, "Home", Icons.Default.Shield),
                    Triple(1, "Devices", Icons.Default.Devices),
                    Triple(2, "Map", Icons.Default.LocationOn),
                    Triple(3, "Safety", Icons.Default.Security),
                    Triple(4, "Profile", Icons.Default.AccountCircle)
                )
                val highlightedMainTab = if (selectedTab in 0..4) selectedTab else previousMainTab.coerceIn(0, 4)
                items.forEach { (index, label, icon) ->
                    val isSelected = highlightedMainTab == index && !isSubScreen
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            previousMainTab = index
                            selectedTab = index
                        },
                        icon = { Icon(imageVector = icon, contentDescription = label) },
                        label = {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BrandGreenPrimary,
                            selectedTextColor = BrandGreenPrimary,
                            indicatorColor = BrandGreenSoft,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier.testTag("nav_tab_$index")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = selectedTab, label = "main_tab_transition") { currentTab ->
                when (currentTab) {
                    0 -> com.example.ui.screens.FamilyHomeDashboardTab(
                        localState = localState,
                        devicesState = devicesState,
                        safetyAlerts = safetyAlerts,
                        historyEvents = historyState,
                        onOpenLiveCamera = { navigateToTab(5) },
                        onOpenLiveVoice = { navigateToTab(6) },
                        onOpenGpsMap = { navigateToTab(2) },
                        onOpenChat = { navigateToTab(7) },
                        onOpenDevicesTab = { navigateToTab(1) },
                        onOpenSafetyTab = { navigateToTab(3) },
                        onTriggerSos = viewModel::triggerSosEmergencyAlert,
                        onDismissSos = viewModel::dismissSosAlert,
                        onRingDevice = viewModel::ringTargetDevice,
                        onSelectTargetDevice = viewModel::selectTargetDevice
                    )
                    1 -> DevicesDashboardTab(
                        localState = localState,
                        devicesState = devicesState,
                        historyState = historyState,
                        onSwitchRole = viewModel::switchThisDeviceRole,
                        onUpdateDeviceName = viewModel::updateDeviceName,
                        onCompletePairing = viewModel::completeDevicePairing,
                        onSelectTargetDevice = viewModel::selectTargetDevice,
                        onUpdateConsent = viewModel::updatePrivacyConsent,
                        onToggleAutoReconnect = viewModel::toggleAutoReconnect,
                        onSendRemoteCommand = viewModel::sendRemoteCommandToTarget,
                        onRequestPermissions = requestAllPermissions,
                        onNavigateToTab = { tab ->
                            when (tab) {
                                1 -> navigateToTab(5) // Camera
                                2 -> navigateToTab(6) // Voice
                                3 -> navigateToTab(2) // Map
                                4 -> navigateToTab(7) // Chat
                                else -> navigateToTab(tab)
                            }
                        },
                        onOpenAccountPrivacy = { showAccountPrivacyDialog = true },
                        onRemoveDevice = viewModel::removeDevice
                    )
                    2 -> LiveGpsMapTab(
                        localState = localState,
                        devicesState = devicesState,
                        savedPlaces = savedPlaces,
                        onAddSavedPlace = viewModel::addSavedPlace,
                        onDeleteSavedPlace = viewModel::deleteSavedPlace,
                        onRefreshLocalGps = viewModel::refreshGpsLocation,
                        onPingRemoteLocation = { viewModel.sendRemoteCommandToTarget("PING_LOCATION") },
                        onShareLocationToChat = viewModel::shareCurrentLocationPinToChat,
                        calculateDistanceMeters = viewModel::calculateDistanceMeters,
                        onRequestLocationPermission = requestAllPermissions
                    )
                    3 -> com.example.ui.screens.FamilySafetyTab(
                        localState = localState,
                        devicesState = devicesState,
                        safetyAlerts = safetyAlerts,
                        appUsageReports = appUsageReports,
                        isMotionDetectionEnabled = localState.isMotionDetectionEnabled,
                        motionSensitivity = localState.motionSensitivity,
                        isSoundDetectionEnabled = localState.isSoundDetectionEnabled,
                        soundThresholdDb = localState.soundThresholdDb,
                        isScreenSharingActive = localState.isScreenSharingActive,
                        isSosActive = localState.isSosActive,
                        isBedtimeActive = localState.isBedtimeActive,
                        hasUsageStatsPermission = viewModel.hasUsageStatsPermission(),
                        onToggleMotionDetection = viewModel::toggleMotionDetection,
                        onSetMotionSensitivity = viewModel::setMotionSensitivity,
                        onToggleSoundDetection = viewModel::toggleSoundDetection,
                        onSetSoundThreshold = viewModel::setSoundThreshold,
                        onToggleScreenSharing = viewModel::toggleScreenSharing,
                        onTriggerSos = viewModel::triggerSosEmergencyAlert,
                        onDismissSos = viewModel::dismissSosAlert,
                        onToggleBedtime = viewModel::toggleBedtime,
                        onRingTargetDevice = viewModel::ringTargetDevice,
                        onOpenUsageSettings = { context.startActivity(viewModel.getUsageSettingsIntent()) },
                        onRefreshUsage = viewModel::refreshAppUsage
                    )
                    4 -> com.example.ui.screens.FamilyProfileTab(
                        localState = localState,
                        userEmail = userEmail,
                        currentUserId = currentUserId,
                        savedVaultMedia = savedVaultMedia,
                        onDeleteSavedMedia = viewModel::deleteSavedMediaItem,
                        onOpenAccountPrivacy = { showAccountPrivacyDialog = true },
                        onSignOut = {
                            signOut(
                                context = context,
                                credentialManager = credentialManager,
                                onSignOutComplete = {},
                                scope = scope
                            )
                        },
                        onRequestPermissions = requestAllPermissions
                    )
                    5 -> LiveCameraTab(
                        localState = localState,
                        devicesState = devicesState,
                        onSetLocalCameraMode = viewModel::setCameraMode,
                        onSendRemoteCommand = viewModel::sendRemoteCommandToTarget,
                        onLocalFrameEncoded = viewModel::onLocalCameraFrameEncoded,
                        onSaveEncryptedSnapshot = viewModel::saveEncryptedSnapshot,
                        onRequestCameraPermission = requestAllPermissions
                    )
                    6 -> LiveAudioVoiceTab(
                        localState = localState,
                        devicesState = devicesState,
                        onToggleMicStream = viewModel::toggleMicStreaming,
                        onToggleTwoWayVoice = viewModel::toggleTwoWayVoice,
                        onSendRemoteCommand = viewModel::sendRemoteCommandToTarget,
                        onSendVoiceNote = viewModel::sendVoiceNoteMessage,
                        onRequestMicPermission = requestAllPermissions
                    )
                    7 -> EncryptedChatVaultTab(
                        localState = localState,
                        messagesState = messagesState,
                        savedVaultMedia = savedVaultMedia,
                        currentUserId = currentUserId,
                        onSendTextMessage = viewModel::sendTextChatMessage,
                        onSendVoiceNote = viewModel::sendVoiceNoteMessage,
                        onShareLocationPin = viewModel::shareCurrentLocationPinToChat,
                        onAttachPhoto = viewModel::saveEncryptedSnapshot,
                        onDeleteSavedMedia = viewModel::deleteSavedMediaItem
                    )
                }
            }

            // Keep CameraX frame encoder active in foreground even when user is viewing another tab
            if (isActivityResumed &&
                selectedTab != 5 &&
                localState.activeCameraFacing != "OFF" &&
                localState.cameraConsentGranted &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            ) {
                Box(
                    modifier = Modifier
                        .size(1.dp)
                        .alpha(0.01f)
                        .align(Alignment.BottomEnd)
                ) {
                    CameraXLivePreview(
                        cameraFacing = localState.activeCameraFacing,
                        onFrameEncoded = viewModel::onLocalCameraFrameEncoded
                    )
                }
            }
        }
    }
}

