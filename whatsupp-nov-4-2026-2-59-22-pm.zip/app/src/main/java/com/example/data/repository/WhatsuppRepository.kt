package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.ConnectionEvent
import com.example.data.model.EncryptedChatMessage
import com.example.data.model.FamilyDevice
import com.example.data.model.WebRtcSignal
import com.example.data.remote.OperationType
import com.example.data.remote.handleFirestoreError
import com.example.data.security.LocalCryptoManager
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class WhatsuppRepository(
    private val db: FirebaseFirestore,
    private val activeUserId: String? = null,
    private val pairingCodeProvider: (() -> String)? = null
) {

    constructor(
        context: Context,
        activeUserId: String? = null,
        pairingCodeProvider: (() -> String)? = null
    ) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        activeUserId,
        pairingCodeProvider
    )

    private val auth get() = Firebase.auth

    private fun requireUserId(): String {
        return activeUserId
            ?: auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in before accessing Firestore.")
    }

    private fun resolvePairingRoomId(explicitCode: String? = null): String? {
        val raw = explicitCode ?: pairingCodeProvider?.invoke() ?: return null
        val digits = raw.filter { it.isDigit() }.take(6)
        if (digits.length < 4) return null
        return "fam_code_${digits.padEnd(6, '0')}"
    }

    private fun observeDevicesForChannel(channelUserId: String, ignoreErrors: Boolean = false): Flow<List<FamilyDevice>> = flow {
        val path = "users/$channelUserId/devices"
        emitAll(
            db.collection("users").document(channelUserId).collection("devices")
                .whereEqualTo("userId", channelUserId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        FamilyDevice::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    if (ignoreErrors) {
                        emit(emptyList())
                    } else {
                        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                        throw error
                    }
                }
        )
    }

    // 1. Observe all paired/registered devices under the same Google account or shared 6-digit pairing code
    fun observeDevices(userId: String = requireUserId()): Flow<List<FamilyDevice>> {
        val primaryFlow = observeDevicesForChannel(userId, ignoreErrors = false)
        val roomId = resolvePairingRoomId()
        if (roomId == null || roomId == userId) {
            return primaryFlow
        }
        val roomFlow = observeDevicesForChannel(roomId, ignoreErrors = true)
        return combine(primaryFlow, roomFlow) { primaryList, roomList ->
            val merged = LinkedHashMap<String, FamilyDevice>()
            (primaryList + roomList).forEach { dev ->
                val existing = merged[dev.id]
                if (existing == null) {
                    merged[dev.id] = dev
                } else {
                    val existingTs = existing.updatedAt ?: existing.createdAt ?: Timestamp(0, 0)
                    val newTs = dev.updatedAt ?: dev.createdAt ?: Timestamp(0, 0)
                    val newer = if (newTs >= existingTs) dev else existing
                    val older = if (newTs >= existingTs) existing else dev
                    merged[dev.id] = newer.copy(
                        latestFrameBase64 = if (newer.activeCameraFacing == "OFF") {
                            ""
                        } else {
                            newer.latestFrameBase64.ifBlank { older.latestFrameBase64 }
                        },
                        latestAudioBase64 = if (!newer.isMicStreaming && !newer.isTwoWayVoiceActive) {
                            ""
                        } else {
                            newer.latestAudioBase64.ifBlank { older.latestAudioBase64 }
                        },
                        remoteCommand = newer.remoteCommand
                    )
                }
            }
            merged.values.sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
        }
    }

    private suspend fun upsertDeviceInChannel(channelUserId: String, deviceId: String, device: FamilyDevice) {
        val docRef = db.collection("users").document(channelUserId).collection("devices").document(deviceId)
        val payload = device.copy(userId = channelUserId).toCreateMap()
        val updateMap = buildMap<String, Any> {
            put("deviceName", device.deviceName.take(80).ifBlank { "Android Phone" })
            put("role", if (device.role == "CONNECTED") "CONNECTED" else "CONTROLLER")
            put("pairingCode", device.pairingCode.take(12).padEnd(6, '0'))
            put("isPaired", device.isPaired)
            put("isOnline", device.isOnline)
            put("autoReconnect", device.autoReconnect)
            put("batteryLevel", device.batteryLevel.coerceIn(0L, 100L))
            put("isCharging", device.isCharging)
            put("networkType", device.networkType.take(40).ifBlank { "Wi-Fi" })
            put("latitude", device.latitude.coerceIn(-90.0, 90.0))
            put("longitude", device.longitude.coerceIn(-180.0, 180.0))
            put("locationAccuracy", device.locationAccuracy.coerceIn(0.0, 10000.0))
            put("locationLabel", device.locationLabel.take(200))
            put("cameraConsentGranted", device.cameraConsentGranted)
            put("micConsentGranted", device.micConsentGranted)
            put("locationConsentGranted", device.locationConsentGranted)
            put("activeCameraFacing", device.activeCameraFacing)
            put("isMicStreaming", device.isMicStreaming)
            put("isTwoWayVoiceActive", device.isTwoWayVoiceActive)
            put("audioLevelDb", device.audioLevelDb.coerceIn(0L, 120L))
            put("latestFrameBase64", if (device.activeCameraFacing == "OFF") "" else device.latestFrameBase64.take(350000))
            put("latestAudioBase64", if (!device.isMicStreaming && !device.isTwoWayVoiceActive) "" else device.latestAudioBase64.take(200000))
            put("remoteCommand", device.remoteCommand.take(64).ifBlank { "NONE" })
            put("updatedAt", FieldValue.serverTimestamp())
        }
        try {
            val existing = docRef.get().await()
            if (!existing.exists()) {
                docRef.set(payload).await()
            } else {
                docRef.update(updateMap).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            docRef.set(payload).await()
        }
    }

    // 2. Register or initialize a device in Firestore
    suspend fun registerOrSyncDevice(device: FamilyDevice): Result<String> = runCatching {
        val uid = requireUserId()
        val deviceId = device.id.ifBlank { "dev_${UUID.randomUUID().toString().take(8)}" }
        val docRef = db.collection("users").document(uid).collection("devices").document(deviceId)
        try {
            upsertDeviceInChannel(uid, deviceId, device)
            val roomId = resolvePairingRoomId(device.pairingCode)
            if (roomId != null && roomId != uid && pairingCodeProvider != null) {
                try {
                    upsertDeviceInChannel(roomId, deviceId, device)
                } catch (_: Exception) {
                }
            }
            deviceId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    suspend fun getDeviceById(targetUserId: String, deviceId: String): Result<FamilyDevice?> = runCatching {
        val docRef = db.collection("users").document(targetUserId).collection("devices").document(deviceId)
        try {
            val snap = docRef.get().await()
            val primary = snap.toObject(FamilyDevice::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            if (primary != null) {
                primary
            } else {
                val roomId = resolvePairingRoomId()
                if (roomId != null && roomId != targetUserId) {
                    val roomSnap = db.collection("users").document(roomId).collection("devices").document(deviceId).get().await()
                    roomSnap.toObject(FamilyDevice::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            throw e
        }
    }

    suspend fun updateDeviceFields(deviceId: String, updates: Map<String, Any>): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("devices").document(deviceId)
        val payload = (updates + ("updatedAt" to FieldValue.serverTimestamp())).filterValues { it != null }
        var updatedAny = false
        try {
            docRef.update(payload).await()
            updatedAny = true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val roomId = resolvePairingRoomId()
            if (roomId == null) {
                handleFirestoreError(e, OperationType.UPDATE, docRef.path)
                throw e
            }
        }
        val roomId = resolvePairingRoomId()
        if (roomId != null && roomId != uid) {
            try {
                db.collection("users").document(roomId).collection("devices").document(deviceId)
                    .update(payload).await()
                updatedAny = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (!updatedAny) {
                    handleFirestoreError(e, OperationType.UPDATE, docRef.path)
                    throw e
                }
            }
        }
    }

    suspend fun sendRemoteCommand(
        targetDeviceId: String,
        command: String,
        targetChannelUserId: String? = null
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val roomId = resolvePairingRoomId()
        val channels = linkedSetOf(uid)
        if (!roomId.isNullOrBlank()) channels.add(roomId)
        if (!targetChannelUserId.isNullOrBlank()) channels.add(targetChannelUserId)

        val payload = mapOf(
            "remoteCommand" to command.take(64).ifBlank { "NONE" },
            "updatedAt" to FieldValue.serverTimestamp()
        )
        var updatedAny = false
        var lastException: Exception? = null
        for (channelId in channels) {
            try {
                db.collection("users").document(channelId).collection("devices").document(targetDeviceId)
                    .update(payload).await()
                updatedAny = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastException = e
            }
        }
        if (!updatedAny && lastException != null) {
            val docPath = "users/$uid/devices/$targetDeviceId"
            handleFirestoreError(lastException, OperationType.UPDATE, docPath)
            throw lastException
        }
    }

    private fun observeSignalsForChannel(channelUserId: String, ignoreErrors: Boolean = false): Flow<List<WebRtcSignal>> = flow {
        val path = "users/$channelUserId/signals"
        emitAll(
            db.collection("users").document(channelUserId).collection("signals")
                .whereEqualTo("userId", channelUserId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        WebRtcSignal::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    if (ignoreErrors) {
                        emit(emptyList())
                    } else {
                        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                        throw error
                    }
                }
        )
    }

    // 3. WebRTC Signaling (SDP Offer/Answer & ICE Candidates)
    fun observeSignals(userId: String = requireUserId()): Flow<List<WebRtcSignal>> {
        val primaryFlow = observeSignalsForChannel(userId, ignoreErrors = false)
        val roomId = resolvePairingRoomId()
        if (roomId == null || roomId == userId) {
            return primaryFlow
        }
        val roomFlow = observeSignalsForChannel(roomId, ignoreErrors = true)
        return combine(primaryFlow, roomFlow) { primaryList, roomList ->
            val merged = LinkedHashMap<String, WebRtcSignal>()
            (primaryList + roomList).forEach { sig ->
                merged[sig.id] = sig
            }
            merged.values.sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
        }
    }

    suspend fun sendWebRtcSignal(
        senderDeviceId: String,
        targetDeviceId: String,
        type: String,
        sdpOrCandidate: String,
        mediaMode: String
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val signalId = "sig_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = db.collection("users").document(uid).collection("signals").document(signalId)
        val signal = WebRtcSignal(
            id = signalId,
            userId = uid,
            senderDeviceId = senderDeviceId,
            targetDeviceId = targetDeviceId,
            type = type,
            sdpOrCandidate = sdpOrCandidate,
            mediaMode = mediaMode,
            encryptionFingerprint = LocalCryptoManager.generateDtlsFingerprint(uid, senderDeviceId)
        )
        try {
            docRef.set(signal.toCreateMap()).await()
            val roomId = resolvePairingRoomId()
            if (roomId != null && roomId != uid) {
                try {
                    val roomSignal = signal.copy(
                        userId = roomId,
                        encryptionFingerprint = LocalCryptoManager.generateDtlsFingerprint(roomId, senderDeviceId)
                    )
                    db.collection("users").document(roomId).collection("signals").document(signalId)
                        .set(roomSignal.toCreateMap()).await()
                } catch (_: Exception) {
                }
            }
            signalId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    private fun observeMessagesForChannel(channelUserId: String, ignoreErrors: Boolean = false): Flow<List<EncryptedChatMessage>> = flow {
        val path = "users/$channelUserId/messages"
        emitAll(
            db.collection("users").document(channelUserId).collection("messages")
                .whereEqualTo("userId", channelUserId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        EncryptedChatMessage::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedBy { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    if (ignoreErrors) {
                        emit(emptyList())
                    } else {
                        if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                        throw error
                    }
                }
        )
    }

    // 4. Encrypted Family Chat & Media Vault Messages
    fun observeMessages(userId: String = requireUserId()): Flow<List<EncryptedChatMessage>> {
        val primaryFlow = observeMessagesForChannel(userId, ignoreErrors = false)
        val roomId = resolvePairingRoomId()
        if (roomId == null || roomId == userId) {
            return primaryFlow
        }
        val roomFlow = observeMessagesForChannel(roomId, ignoreErrors = true)
        return combine(primaryFlow, roomFlow) { primaryList, roomList ->
            val merged = LinkedHashMap<String, EncryptedChatMessage>()
            (primaryList + roomList).forEach { msg ->
                merged[msg.id] = msg
            }
            merged.values.sortedBy { it.createdAt ?: Timestamp(0, 0) }
        }
    }

    suspend fun sendEncryptedMessage(
        senderDeviceId: String,
        senderName: String,
        senderRole: String,
        messageType: String,
        plainText: String,
        mediaBase64: String = "",
        durationSec: Long = 0L
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val msgId = "msg_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = db.collection("users").document(uid).collection("messages").document(msgId)
        val cipherText = LocalCryptoManager.encrypt(plainText, uid)
        val message = EncryptedChatMessage(
            id = msgId,
            userId = uid,
            senderDeviceId = senderDeviceId,
            senderName = senderName,
            senderRole = senderRole,
            messageType = messageType,
            cipherText = cipherText,
            plainPreview = plainText.take(500),
            mediaBase64 = mediaBase64,
            durationSec = durationSec,
            isDelivered = true
        )
        try {
            docRef.set(message.toCreateMap()).await()
            val roomId = resolvePairingRoomId()
            if (roomId != null && roomId != uid) {
                try {
                    val roomMessage = message.copy(
                        userId = roomId,
                        cipherText = LocalCryptoManager.encrypt(plainText, roomId)
                    )
                    db.collection("users").document(roomId).collection("messages").document(msgId)
                        .set(roomMessage.toCreateMap()).await()
                } catch (_: Exception) {
                }
            }
            msgId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    // 5. Connection History & Privacy Consent Audit Log
    fun observeHistory(userId: String = requireUserId()): Flow<List<ConnectionEvent>> = flow {
        val path = "users/$userId/history"
        emitAll(
            db.collection("users").document(userId).collection("history")
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        ConnectionEvent::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun logConnectionEvent(
        deviceId: String,
        deviceName: String,
        eventType: String,
        details: String
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val eventId = "evt_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = db.collection("users").document(uid).collection("history").document(eventId)
        val event = ConnectionEvent(
            id = eventId,
            userId = uid,
            deviceId = deviceId,
            deviceName = deviceName,
            eventType = eventType,
            details = details,
            encryptedFlag = true
        )
        try {
            docRef.set(event.toCreateMap()).await()
            eventId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteDevice(deviceId: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("devices").document(deviceId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    suspend fun deleteAllUserData(userId: String = requireUserId()): Result<Unit> = runCatching {
        val userDoc = db.collection("users").document(userId)

        try {
            val devices = userDoc.collection("devices").get().await()
            for (doc in devices.documents) {
                doc.reference.delete().await()
            }
        } catch (e: Exception) {
            if (e is CancellationException) throw e
        }

        try {
            val signals = userDoc.collection("signals").get().await()
            for (doc in signals.documents) {
                doc.reference.delete().await()
            }
        } catch (e: Exception) {
            if (e is CancellationException) throw e
        }

        try {
            val messages = userDoc.collection("messages").get().await()
            for (doc in messages.documents) {
                doc.reference.delete().await()
            }
        } catch (e: Exception) {
            if (e is CancellationException) throw e
        }
    }
}
