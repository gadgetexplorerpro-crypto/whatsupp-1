package com.example.data.auth

import android.content.Context
import androidx.core.content.edit
import com.example.data.security.LocalCryptoManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.MessageDigest

data class AuthSession(
    val userId: String,
    val email: String,
    val displayName: String = "",
    val authProvider: String = "GOOGLE",
    val isFamilyAccount: Boolean = true
)

data class SavedDeviceConfig(
    val deviceRole: String = "CONTROLLER",
    val deviceName: String = "",
    val pairingCode: String = "849201",
    val selectedTargetDeviceId: String = "",
    val cameraConsentGranted: Boolean = true,
    val micConsentGranted: Boolean = true,
    val locationConsentGranted: Boolean = true,
    val autoReconnect: Boolean = true,
    val keepConnectedWhenClosed: Boolean = true,
    val activeCameraFacing: String = "OFF",
    val isMicStreaming: Boolean = false,
    val isTwoWayVoiceActive: Boolean = false,
    val cameraPausedBySystem: Boolean = false,
    val userExplicitlyStoppedService: Boolean = false,
    val fcmToken: String = ""
)

sealed interface EmailAuthResult {
    data class Success(val session: AuthSession) : EmailAuthResult
    data class Error(val message: String) : EmailAuthResult
}

object FamilyAuthSessionManager {
    private const val PREFS_NAME = "whatsupp_auth_session"
    private const val KEY_USER_ID = "saved_user_id"
    private const val KEY_EMAIL = "saved_email"
    private const val KEY_DISPLAY_NAME = "saved_display_name"
    private const val KEY_PROVIDER = "saved_provider"
    private const val KEY_GOOGLE_ACCOUNTS = "saved_google_accounts_csv"
    private const val KEY_PASSWORD_PREFIX = "pwd_hash_"

    private const val DEVICE_PREFS_NAME = "whatsupp_device_config"
    private const val KEY_DEVICE_ROLE = "device_role"
    private const val KEY_DEVICE_NAME = "device_name"
    private const val KEY_PAIRING_CODE = "pairing_code"
    private const val KEY_TARGET_DEVICE_ID = "target_device_id"
    private const val KEY_CAM_CONSENT = "cam_consent"
    private const val KEY_MIC_CONSENT = "mic_consent"
    private const val KEY_LOC_CONSENT = "loc_consent"
    private const val KEY_AUTO_RECONNECT = "auto_reconnect"
    private const val KEY_KEEP_CONNECTED_CLOSED = "keep_connected_closed"
    private const val KEY_ACTIVE_CAMERA_FACING = "active_camera_facing"
    private const val KEY_IS_MIC_STREAMING = "is_mic_streaming"
    private const val KEY_IS_TWO_WAY_VOICE = "is_two_way_voice"
    private const val KEY_CAMERA_PAUSED_BY_SYSTEM = "camera_paused_by_system"
    private const val KEY_USER_STOPPED_SERVICE = "user_explicitly_stopped_service"
    private const val KEY_FCM_TOKEN = "fcm_token"

    private val _currentSession = MutableStateFlow<AuthSession?>(null)
    val currentSession: StateFlow<AuthSession?> = _currentSession.asStateFlow()

    fun init(context: Context): AuthSession? {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedUid = prefs.getString(KEY_USER_ID, null)
        val savedEmail = prefs.getString(KEY_EMAIL, null)
        val savedName = prefs.getString(KEY_DISPLAY_NAME, null).orEmpty()
        val savedProvider = prefs.getString(KEY_PROVIDER, "GOOGLE") ?: "GOOGLE"
        if (!savedUid.isNullOrBlank() && !savedEmail.isNullOrBlank()) {
            val session = AuthSession(
                userId = savedUid,
                email = savedEmail,
                displayName = savedName,
                authProvider = savedProvider
            )
            _currentSession.value = session
            return session
        }
        return _currentSession.value
    }

    fun normalizeGoogleEmail(rawInput: String): String {
        val trimmed = rawInput.trim().lowercase()
        if (trimmed.isEmpty()) return ""
        return if (!trimmed.contains("@")) {
            "$trimmed@gmail.com"
        } else {
            trimmed
        }
    }

    fun saveSession(
        context: Context,
        email: String,
        explicitUid: String? = null,
        displayName: String = "",
        authProvider: String = "EMAIL"
    ): AuthSession {
        val cleanEmail = normalizeGoogleEmail(email)
        val uid = if (!explicitUid.isNullOrBlank() && explicitUid.startsWith("fam_")) {
            explicitUid
        } else {
            LocalCryptoManager.generateFamilyUserId(cleanEmail)
        }
        val resolvedName = displayName.ifBlank {
            cleanEmail.substringBefore("@").replaceFirstChar { it.uppercase() }
        }
        val session = AuthSession(
            userId = uid,
            email = cleanEmail,
            displayName = resolvedName,
            authProvider = authProvider
        )
        val appContext = context.applicationContext
        val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val existingGoogleAccounts = getSavedGoogleAccounts(appContext).toMutableList()
        if (cleanEmail.isNotBlank() && !existingGoogleAccounts.contains(cleanEmail)) {
            existingGoogleAccounts.add(0, cleanEmail)
        }
        prefs.edit {
            putString(KEY_USER_ID, uid)
            putString(KEY_EMAIL, cleanEmail)
            putString(KEY_DISPLAY_NAME, resolvedName)
            putString(KEY_PROVIDER, authProvider)
            putString(KEY_GOOGLE_ACCOUNTS, existingGoogleAccounts.take(6).joinToString(","))
        }
        _currentSession.value = session
        return session
    }

    fun saveGoogleAccountAndSession(
        context: Context,
        googleEmail: String,
        displayName: String = ""
    ): AuthSession {
        val normalized = normalizeGoogleEmail(googleEmail)
        return saveSession(
            context = context,
            email = normalized,
            explicitUid = LocalCryptoManager.generateFamilyUserId(normalized),
            displayName = displayName,
            authProvider = "GOOGLE"
        )
    }

    fun getSavedGoogleAccounts(context: Context): List<String> {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_GOOGLE_ACCOUNTS, null).orEmpty()
        val lastEmail = prefs.getString(KEY_EMAIL, null).orEmpty()
        return buildList {
            if (lastEmail.isNotBlank()) add(lastEmail)
            raw.split(",")
                .map { it.trim().lowercase() }
                .filter { it.isNotBlank() && it.contains("@") }
                .forEach { if (!contains(it)) add(it) }
        }
    }

    fun authenticateEmailAndPassword(
        context: Context,
        email: String,
        password: String,
        isSignUpMode: Boolean
    ): EmailAuthResult {
        val cleanEmail = normalizeGoogleEmail(email)
        val cleanPassword = password.trim()
        if (cleanEmail.isBlank()) {
            return EmailAuthResult.Error("Please enter your Gmail or email address.")
        }
        if (cleanPassword.length < 6) {
            return EmailAuthResult.Error("Password must be at least 6 characters long.")
        }

        val appContext = context.applicationContext
        val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val pwdKey = KEY_PASSWORD_PREFIX + cleanEmail
        val incomingHash = hashPassword(cleanEmail, cleanPassword)
        val storedHash = prefs.getString(pwdKey, null)

        if (!isSignUpMode && storedHash != null && storedHash != incomingHash) {
            return EmailAuthResult.Error("Invalid password for $cleanEmail. Please verify your password or use Sign Up to reset.")
        }

        prefs.edit {
            putString(pwdKey, incomingHash)
        }

        val session = saveSession(
            context = appContext,
            email = cleanEmail,
            authProvider = "EMAIL"
        )
        return EmailAuthResult.Success(session)
    }

    private fun hashPassword(email: String, password: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest("whatsupp_pwd:$email:$password".toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun clearSession(context: Context) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit {
            remove(KEY_USER_ID)
            remove(KEY_EMAIL)
            remove(KEY_DISPLAY_NAME)
            remove(KEY_PROVIDER)
        }
        _currentSession.value = null
    }

    fun loadDeviceConfig(context: Context, defaultDeviceName: String): SavedDeviceConfig {
        val prefs = context.applicationContext.getSharedPreferences(DEVICE_PREFS_NAME, Context.MODE_PRIVATE)
        return SavedDeviceConfig(
            deviceRole = prefs.getString(KEY_DEVICE_ROLE, "CONTROLLER") ?: "CONTROLLER",
            deviceName = prefs.getString(KEY_DEVICE_NAME, defaultDeviceName)?.ifBlank { defaultDeviceName } ?: defaultDeviceName,
            pairingCode = prefs.getString(KEY_PAIRING_CODE, "849201") ?: "849201",
            selectedTargetDeviceId = prefs.getString(KEY_TARGET_DEVICE_ID, "") ?: "",
            cameraConsentGranted = prefs.getBoolean(KEY_CAM_CONSENT, true),
            micConsentGranted = prefs.getBoolean(KEY_MIC_CONSENT, true),
            locationConsentGranted = prefs.getBoolean(KEY_LOC_CONSENT, true),
            autoReconnect = prefs.getBoolean(KEY_AUTO_RECONNECT, true),
            keepConnectedWhenClosed = prefs.getBoolean(KEY_KEEP_CONNECTED_CLOSED, true),
            activeCameraFacing = prefs.getString(KEY_ACTIVE_CAMERA_FACING, "OFF") ?: "OFF",
            isMicStreaming = prefs.getBoolean(KEY_IS_MIC_STREAMING, false),
            isTwoWayVoiceActive = prefs.getBoolean(KEY_IS_TWO_WAY_VOICE, false),
            cameraPausedBySystem = prefs.getBoolean(KEY_CAMERA_PAUSED_BY_SYSTEM, false),
            userExplicitlyStoppedService = prefs.getBoolean(KEY_USER_STOPPED_SERVICE, false),
            fcmToken = prefs.getString(KEY_FCM_TOKEN, "") ?: ""
        )
    }

    fun saveDeviceConfig(
        context: Context,
        deviceRole: String? = null,
        deviceName: String? = null,
        pairingCode: String? = null,
        selectedTargetDeviceId: String? = null,
        cameraConsentGranted: Boolean? = null,
        micConsentGranted: Boolean? = null,
        locationConsentGranted: Boolean? = null,
        autoReconnect: Boolean? = null,
        keepConnectedWhenClosed: Boolean? = null,
        activeCameraFacing: String? = null,
        isMicStreaming: Boolean? = null,
        isTwoWayVoiceActive: Boolean? = null,
        cameraPausedBySystem: Boolean? = null,
        userExplicitlyStoppedService: Boolean? = null,
        fcmToken: String? = null
    ) {
        val prefs = context.applicationContext.getSharedPreferences(DEVICE_PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit {
            deviceRole?.let { putString(KEY_DEVICE_ROLE, it) }
            deviceName?.let { putString(KEY_DEVICE_NAME, it) }
            pairingCode?.let { putString(KEY_PAIRING_CODE, it) }
            selectedTargetDeviceId?.let { putString(KEY_TARGET_DEVICE_ID, it) }
            cameraConsentGranted?.let { putBoolean(KEY_CAM_CONSENT, it) }
            micConsentGranted?.let { putBoolean(KEY_MIC_CONSENT, it) }
            locationConsentGranted?.let { putBoolean(KEY_LOC_CONSENT, it) }
            autoReconnect?.let { putBoolean(KEY_AUTO_RECONNECT, it) }
            keepConnectedWhenClosed?.let { putBoolean(KEY_KEEP_CONNECTED_CLOSED, it) }
            activeCameraFacing?.let { putString(KEY_ACTIVE_CAMERA_FACING, it) }
            isMicStreaming?.let { putBoolean(KEY_IS_MIC_STREAMING, it) }
            isTwoWayVoiceActive?.let { putBoolean(KEY_IS_TWO_WAY_VOICE, it) }
            cameraPausedBySystem?.let { putBoolean(KEY_CAMERA_PAUSED_BY_SYSTEM, it) }
            userExplicitlyStoppedService?.let { putBoolean(KEY_USER_STOPPED_SERVICE, it) }
            fcmToken?.let { putString(KEY_FCM_TOKEN, it) }
        }
    }
}
