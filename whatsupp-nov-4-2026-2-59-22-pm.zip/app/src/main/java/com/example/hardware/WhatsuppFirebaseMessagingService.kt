package com.example.hardware

import android.util.Log
import com.example.data.auth.FamilyAuthSessionManager
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Firebase Cloud Messaging (FCM) service for handling incoming remote connection events,
 * wake-up notifications, and device alerts when the app is minimized, closed, or in Doze mode.
 *
 * Strictly complies with Android 12–16 foreground service and privacy rules:
 * never secretly activates camera or microphone from the background; instead, enqueues
 * WorkManager sync and displays a clear user notification to open or approve the session.
 */
class WhatsuppFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        if (token.isBlank()) return
        try {
            FamilyAuthSessionManager.saveDeviceConfig(
                context = applicationContext,
                fcmToken = token
            )
            WhatsuppSyncWorker.enqueueImmediateRecoverySync(applicationContext)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to persist refreshed FCM token: ${e.message}")
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        val session = FamilyAuthSessionManager.init(applicationContext) ?: return
        val hardwareManager = DeviceHardwareManager(applicationContext)
        val cfg = FamilyAuthSessionManager.loadDeviceConfig(
            applicationContext,
            hardwareManager.getDefaultDeviceName()
        )
        if (cfg.userExplicitlyStoppedService) return

        val data = remoteMessage.data
        val eventType = data["eventType"] ?: data["command"] ?: "SYNC_WAKEUP"
        val senderName = data["senderName"] ?: "Paired Family Device"

        // Always trigger a compliant WorkManager sync for state/telemetry recovery
        WhatsuppSyncWorker.enqueueImmediateRecoverySync(applicationContext)

        when (eventType) {
            "RING_DEVICE" -> {
                hardwareManager.triggerDeviceRingAlert()
                hardwareManager.postPrivacyNotification(
                    title = "Family Device Ring Alert",
                    body = "$senderName pinged this device!",
                    notificationId = 1005
                )
            }
            "PING_LOCATION" -> {
                hardwareManager.postPrivacyNotification(
                    title = "Location Sync Requested",
                    body = "$senderName requested a GPS location update (${session.email}).",
                    notificationId = 1006
                )
            }
            "START_CAM_FRONT", "START_CAM_BACK" -> {
                val facing = if (eventType.endsWith("FRONT")) "Front" else "Back"
                hardwareManager.postPrivacyNotification(
                    title = "Live $facing Camera Request",
                    body = "$senderName requested live $facing camera. Tap to open Whatsupp and authorize.",
                    notificationId = 1004
                )
            }
            "START_MIC", "START_VOICE" -> {
                hardwareManager.postPrivacyNotification(
                    title = "Live Voice / Intercom Request",
                    body = "$senderName started a family voice session. Tap to open Whatsupp.",
                    notificationId = 1003
                )
            }
            "NEW_MESSAGE" -> {
                val preview = data["preview"] ?: remoteMessage.notification?.body ?: "Encrypted family message received"
                hardwareManager.postPrivacyNotification(
                    title = "New Message from $senderName",
                    body = preview,
                    notificationId = 2002
                )
            }
            else -> {
                remoteMessage.notification?.let { notif ->
                    hardwareManager.postPrivacyNotification(
                        title = notif.title ?: "Whatsupp Family Update",
                        body = notif.body ?: "Tap to view connected family devices.",
                        notificationId = 1008
                    )
                }
            }
        }
    }

    companion object {
        private const val TAG = "WhatsuppFcmService"
    }
}
