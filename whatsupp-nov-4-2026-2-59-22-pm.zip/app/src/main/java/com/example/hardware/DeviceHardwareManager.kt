package com.example.hardware

import android.Manifest
import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.location.Geocoder
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.RingtoneManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.util.Base64
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.math.log10
import kotlin.math.sqrt

data class HardwareTelemetry(
    val batteryLevel: Int = 100,
    val isCharging: Boolean = false,
    val networkType: String = "Wi-Fi",
    val isOnline: Boolean = true,
    val latitude: Double = 37.4220,
    val longitude: Double = -122.0841,
    val accuracy: Double = 5.0,
    val locationLabel: String = "GPS Ready",
    val isPowerSaveMode: Boolean = false,
    val isDeviceIdleDoze: Boolean = false,
    val isScreenLocked: Boolean = false
)

class DeviceHardwareManager(context: Context) {
    val appContext: Context = context.applicationContext
    private var audioRecordJob: Job? = null
    private var audioFocusRequest: AudioFocusRequest? = null

    @Volatile
    private var isAudioPausedByInterruption: Boolean = false

    private val audioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                isAudioPausedByInterruption = true
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                isAudioPausedByInterruption = false
            }
            AudioManager.AUDIOFOCUS_LOSS -> {
                // Keep session alive for voice intercom unless permission is revoked, but unpause after transient loss
                isAudioPausedByInterruption = false
            }
        }
    }

    init {
        createNotificationChannel()
    }

    fun hasCameraPermission(): Boolean =
        ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    fun hasMicPermission(): Boolean =
        ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    fun isDeviceScreenLocked(): Boolean {
        val km = appContext.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        return km?.isKeyguardLocked == true
    }

    fun isPowerSaveOrDozeMode(): Boolean {
        val pm = appContext.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
        return pm.isPowerSaveMode || pm.isDeviceIdleMode
    }

    fun getStableDeviceId(): String {
        val prefs = appContext.getSharedPreferences("whatsupp_device_config", Context.MODE_PRIVATE)
        val savedId = prefs.getString("saved_installation_device_id", null)
        if (!savedId.isNullOrBlank() && savedId.startsWith("dev_")) {
            return savedId
        }
        val rawId = try {
            Settings.Secure.getString(appContext.contentResolver, Settings.Secure.ANDROID_ID)
        } catch (_: Exception) {
            null
        }
        val baseClean = (rawId ?: "${Build.MANUFACTURER}_${Build.MODEL}")
            .replace(Regex("[^a-zA-Z0-9]"), "")
            .take(12)
            .ifBlank { "android" }
        val uniqueSuffix = java.util.UUID.randomUUID().toString().replace("-", "").take(6)
        val generatedId = "dev_${baseClean}_$uniqueSuffix"
        prefs.edit().putString("saved_installation_device_id", generatedId).apply()
        return generatedId
    }

    fun getDefaultDeviceName(): String {
        val manufacturer = Build.MANUFACTURER?.replaceFirstChar { it.uppercase() } ?: "Android"
        val model = Build.MODEL ?: "Phone"
        return if (model.startsWith(manufacturer, ignoreCase = true)) model else "$manufacturer $model"
    }

    fun readBatteryAndNetwork(): HardwareTelemetry {
        val batteryIntent = try {
            appContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (_: Exception) {
            null
        }
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: 100
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: 100
        val pct = if (level >= 0 && scale > 0) ((level * 100f) / scale).toInt().coerceIn(0, 100) else 100
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNetwork = cm?.activeNetwork
        val caps = activeNetwork?.let { cm.getNetworkCapabilities(it) }
        val isOnline = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val netType = when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "5G / LTE"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Online"
        }

        val pm = appContext.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val isPowerSave = pm?.isPowerSaveMode == true
        val isDoze = pm?.isDeviceIdleMode == true

        return HardwareTelemetry(
            batteryLevel = pct,
            isCharging = isCharging,
            networkType = netType,
            isOnline = isOnline,
            isPowerSaveMode = isPowerSave,
            isDeviceIdleDoze = isDoze,
            isScreenLocked = isDeviceScreenLocked()
        )
    }

    fun registerNetworkReconnectCallback(
        onNetworkRestored: () -> Unit
    ): ConnectivityManager.NetworkCallback? {
        return registerNetworkTransitionCallback(
            onNetworkAvailableOrChanged = { onNetworkRestored() },
            onNetworkLost = {}
        )
    }

    fun registerNetworkTransitionCallback(
        onNetworkAvailableOrChanged: (networkType: String) -> Unit,
        onNetworkLost: () -> Unit
    ): ConnectivityManager.NetworkCallback? {
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return null
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                val telemetry = readBatteryAndNetwork()
                onNetworkAvailableOrChanged(telemetry.networkType)
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                val hasInternet = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                if (hasInternet) {
                    val netType = when {
                        networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                        networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "5G / LTE"
                        networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                        else -> "Online"
                    }
                    onNetworkAvailableOrChanged(netType)
                }
            }

            override fun onLost(network: Network) {
                val telemetry = readBatteryAndNetwork()
                if (!telemetry.isOnline) {
                    onNetworkLost()
                }
            }
        }
        return try {
            cm.registerDefaultNetworkCallback(callback)
            callback
        } catch (_: Exception) {
            null
        }
    }

    fun unregisterNetworkCallback(callback: ConnectivityManager.NetworkCallback?) {
        if (callback == null) return
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        try {
            cm?.unregisterNetworkCallback(callback)
        } catch (_: Exception) {
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun fetchCurrentGpsLocation(): HardwareTelemetry? = withContext(Dispatchers.IO) {
        val hasFine = ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasFine && !hasCoarse) return@withContext null

        return@withContext try {
            val client = LocationServices.getFusedLocationProviderClient(appContext)
            val priority = if (hasFine && !isPowerSaveOrDozeMode()) {
                Priority.PRIORITY_HIGH_ACCURACY
            } else {
                Priority.PRIORITY_BALANCED_POWER_ACCURACY
            }
            val loc = client.getCurrentLocation(priority, CancellationTokenSource().token).await()
                ?: client.lastLocation.await()
            if (loc != null) {
                val label = resolveAddressLabel(loc.latitude, loc.longitude)
                val base = readBatteryAndNetwork()
                base.copy(
                    latitude = loc.latitude,
                    longitude = loc.longitude,
                    accuracy = loc.accuracy.toDouble().coerceIn(1.0, 9999.0),
                    locationLabel = label
                )
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    @Suppress("DEPRECATION")
    private fun resolveAddressLabel(lat: Double, lng: Double): String {
        return try {
            val geocoder = Geocoder(appContext, Locale.getDefault())
            val list = geocoder.getFromLocation(lat, lng, 1)
            val addr = list?.firstOrNull()
            if (addr != null) {
                listOfNotNull(addr.thoroughfare ?: addr.featureName, addr.locality, addr.adminArea)
                    .joinToString(", ")
                    .ifBlank { "%.4f, %.4f".format(lat, lng) }
            } else {
                "%.4f, %.4f".format(lat, lng)
            }
        } catch (_: Exception) {
            "%.4f, %.4f".format(lat, lng)
        }
    }

    private fun requestCommunicationAudioFocusAndRoute() {
        val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        try {
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAcceptsDelayedFocusGain(true)
                    .setOnAudioFocusChangeListener(audioFocusChangeListener)
                    .build()
                audioFocusRequest = req
                audioManager.requestAudioFocus(req)
            } else {
                @Suppress("DEPRECATION")
                audioManager.requestAudioFocus(
                    audioFocusChangeListener,
                    AudioManager.STREAM_VOICE_CALL,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
                )
            }
            configurePreferredAudioRoute(audioManager)
        } catch (e: Exception) {
            Log.w(TAG, "Audio focus setup warning: ${e.message}")
        }
    }

    private fun configurePreferredAudioRoute(audioManager: AudioManager) {
        try {
            val outputDevices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            val hasExternalHeadset = outputDevices.any { dev ->
                dev.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                    dev.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                    dev.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                    dev.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                    dev.type == AudioDeviceInfo.TYPE_USB_HEADSET
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val commDevices = audioManager.availableCommunicationDevices
                val preferred = commDevices.firstOrNull {
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                        it.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                        it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                        it.type == AudioDeviceInfo.TYPE_USB_HEADSET
                } ?: commDevices.firstOrNull {
                    it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                }
                if (preferred != null) {
                    audioManager.setCommunicationDevice(preferred)
                }
            } else {
                @Suppress("DEPRECATION")
                audioManager.isSpeakerphoneOn = !hasExternalHeadset
            }
        } catch (_: Exception) {
        }
    }

    private fun abandonCommunicationAudioFocus() {
        val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(audioFocusChangeListener)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                audioManager.clearCommunicationDevice()
            }
            audioManager.mode = AudioManager.MODE_NORMAL
        } catch (_: Exception) {
        }
    }

    @SuppressLint("MissingPermission")
    fun startLiveAudioCapture(
        scope: CoroutineScope,
        onPermissionRevoked: (() -> Unit)? = null,
        onAudioMetrics: (dbLevel: Int, pcmChunkBase64: String) -> Unit
    ) {
        if (!hasMicPermission()) {
            onPermissionRevoked?.invoke()
            return
        }

        stopLiveAudioCapture()
        isAudioPausedByInterruption = false
        requestCommunicationAudioFocusAndRoute()

        audioRecordJob = scope.launch(Dispatchers.IO) {
            val sampleRate = 8000
            val minBuffer = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(1600)

            var consecutiveReadErrors = 0
            while (isActive) {
                if (!hasMicPermission()) {
                    onPermissionRevoked?.invoke()
                    break
                }

                if (isAudioPausedByInterruption) {
                    delay(400L)
                    continue
                }

                val recorder = try {
                    AudioRecord(
                        MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                        sampleRate,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        minBuffer
                    )
                } catch (_: Exception) {
                    null
                }

                if (recorder == null || recorder.state != AudioRecord.STATE_INITIALIZED) {
                    recorder?.release()
                    consecutiveReadErrors++
                    if (consecutiveReadErrors > 5) break
                    delay(1000L)
                    continue
                }

                val buffer = ShortArray(minBuffer / 2)
                try {
                    recorder.startRecording()
                    consecutiveReadErrors = 0
                    var tick = 0
                    while (isActive && !isAudioPausedByInterruption) {
                        if (!hasMicPermission()) {
                            onPermissionRevoked?.invoke()
                            break
                        }
                        val readCount = recorder.read(buffer, 0, buffer.size)
                        if (readCount > 0) {
                            var sum = 0.0
                            for (i in 0 until readCount) {
                                sum += buffer[i] * buffer[i].toDouble()
                            }
                            val rms = sqrt(sum / readCount)
                            val db = if (rms > 1.0) (20.0 * log10(rms)).toInt().coerceIn(10, 110) else 12
                            val encodedChunk = if (tick % 4 == 0) {
                                val byteBuf = ByteArray(readCount.coerceAtMost(400) * 2)
                                for (i in 0 until (byteBuf.size / 2)) {
                                    val s = buffer[i].toInt()
                                    byteBuf[i * 2] = (s and 0xFF).toByte()
                                    byteBuf[i * 2 + 1] = ((s shr 8) and 0xFF).toByte()
                                }
                                Base64.encodeToString(byteBuf, Base64.NO_WRAP)
                            } else ""
                            onAudioMetrics(db, encodedChunk)
                            tick++
                        } else if (readCount < 0) {
                            // Audio device route change (e.g., Bluetooth headset connected/disconnected) — reinitialize
                            break
                        }
                        delay(250L)
                    }
                } catch (_: Exception) {
                } finally {
                    try {
                        recorder.stop()
                    } catch (_: Exception) {
                    }
                    try {
                        recorder.release()
                    } catch (_: Exception) {
                    }
                }

                if (isActive && !isAudioPausedByInterruption) {
                    delay(350L)
                }
            }
            abandonCommunicationAudioFocus()
        }
    }

    fun stopLiveAudioCapture() {
        audioRecordJob?.cancel()
        audioRecordJob = null
        isAudioPausedByInterruption = false
        abandonCommunicationAudioFocus()
    }

    fun isAudioCaptureRunning(): Boolean = audioRecordJob?.isActive == true

    fun playIncomingPcmAudio(base64Pcm: String, scope: CoroutineScope) {
        if (base64Pcm.isBlank()) return
        scope.launch(Dispatchers.IO) {
            try {
                val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                if (audioManager != null) {
                    configurePreferredAudioRoute(audioManager)
                }
                val bytes = Base64.decode(base64Pcm, Base64.NO_WRAP)
                if (bytes.isEmpty()) return@launch
                val sampleRate = 8000
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bytes.size.coerceAtLeast(1600))
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(bytes, 0, bytes.size)
                track.play()
                delay(450L)
                track.stop()
                track.release()
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Captures a single low-resolution frame during an explicitly user-started foreground-service
     * camera session when the app is minimized. If Android OS background camera policy or screen lock
     * blocks camera access, it cleanly releases all camera resources and invokes [onCameraBlockedBySystem]
     * so the session pauses safely and automatically restores when the user returns to the foreground.
     */
    @SuppressLint("MissingPermission")
    suspend fun capturePermittedBackgroundFrameBase64(
        facing: String,
        onCameraBlockedBySystem: () -> Unit
    ): String? = withContext(Dispatchers.IO) {
        if (facing !in listOf("FRONT", "BACK") || !hasCameraPermission()) {
            onCameraBlockedBySystem()
            return@withContext null
        }
        if (isDeviceScreenLocked()) {
            // Android security policy restricts camera capture while keyguard is locked unless an activity is on top
            onCameraBlockedBySystem()
            return@withContext null
        }

        val cameraManager = appContext.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            ?: return@withContext null

        val desiredLensFacing = if (facing == "FRONT") {
            CameraCharacteristics.LENS_FACING_FRONT
        } else {
            CameraCharacteristics.LENS_FACING_BACK
        }

        val cameraId = try {
            cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.LENS_FACING) == desiredLensFacing
            } ?: cameraManager.cameraIdList.firstOrNull()
        } catch (_: Throwable) {
            null
        } ?: return@withContext null

        val handlerThread = HandlerThread("WhatsuppBgCameraThread").apply { start() }
        val handler = Handler(handlerThread.looper)
        var imageReader: ImageReader? = null
        var openedCamera: CameraDevice? = null
        var captureSession: CameraCaptureSession? = null

        try {
            withTimeoutOrNull(3500L) {
                suspendCancellableCoroutine<String?> { cont ->
                    try {
                        imageReader = ImageReader.newInstance(320, 240, ImageFormat.JPEG, 2)
                        imageReader?.setOnImageAvailableListener({ reader ->
                            val image = try {
                                reader.acquireLatestImage()
                            } catch (_: Throwable) {
                                null
                            }
                            if (image != null) {
                                try {
                                    val buffer = image.planes[0].buffer
                                    val bytes = ByteArray(buffer.remaining())
                                    buffer.get(bytes)
                                    val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                    val out = ByteArrayOutputStream()
                                    if (bitmap != null) {
                                        val scaled = Bitmap.createScaledBitmap(bitmap, 320, 240, true)
                                        scaled.compress(Bitmap.CompressFormat.JPEG, 52, out)
                                        if (scaled !== bitmap) scaled.recycle()
                                        bitmap.recycle()
                                    } else {
                                        out.write(bytes)
                                    }
                                    val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                                    if (cont.isActive) cont.resume(b64)
                                } catch (_: Throwable) {
                                    if (cont.isActive) cont.resume(null)
                                } finally {
                                    try {
                                        image.close()
                                    } catch (_: Throwable) {
                                    }
                                }
                            }
                        }, handler)

                        cameraManager.openCamera(
                            cameraId,
                            object : CameraDevice.StateCallback() {
                                override fun onOpened(camera: CameraDevice) {
                                    openedCamera = camera
                                    val surface = imageReader?.surface
                                    if (surface == null) {
                                        if (cont.isActive) cont.resume(null)
                                        return
                                    }
                                    try {
                                        val requestBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                                            addTarget(surface)
                                            set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                                        }
                                        @Suppress("DEPRECATION")
                                        camera.createCaptureSession(
                                            listOf(surface),
                                            object : CameraCaptureSession.StateCallback() {
                                                override fun onConfigured(session: CameraCaptureSession) {
                                                    captureSession = session
                                                    try {
                                                        session.capture(requestBuilder.build(), null, handler)
                                                    } catch (_: Throwable) {
                                                        if (cont.isActive) cont.resume(null)
                                                    }
                                                }

                                                override fun onConfigureFailed(session: CameraCaptureSession) {
                                                    if (cont.isActive) cont.resume(null)
                                                }
                                            },
                                            handler
                                        )
                                    } catch (_: Throwable) {
                                        onCameraBlockedBySystem()
                                        if (cont.isActive) cont.resume(null)
                                    }
                                }

                                override fun onDisconnected(camera: CameraDevice) {
                                    onCameraBlockedBySystem()
                                    if (cont.isActive) cont.resume(null)
                                }

                                override fun onError(camera: CameraDevice, error: Int) {
                                    onCameraBlockedBySystem()
                                    if (cont.isActive) cont.resume(null)
                                }
                            },
                            handler
                        )
                    } catch (_: SecurityException) {
                        onCameraBlockedBySystem()
                        if (cont.isActive) cont.resume(null)
                    } catch (_: Throwable) {
                        onCameraBlockedBySystem()
                        if (cont.isActive) cont.resume(null)
                    }
                }
            }
        } finally {
            try {
                captureSession?.close()
            } catch (_: Throwable) {
            }
            try {
                openedCamera?.close()
            } catch (_: Throwable) {
            }
            try {
                imageReader?.close()
            } catch (_: Throwable) {
            }
            try {
                handlerThread.quitSafely()
            } catch (_: Throwable) {
            }
        }
    }

    fun triggerDeviceRingAlert() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val ringtone = RingtoneManager.getRingtone(appContext, uri)
            ringtone?.play()
        } catch (_: Exception) {
        }
        try {
            val vibrator = appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(500L, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(500L)
            }
        } catch (_: Exception) {
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Whatsupp Family Privacy & Connection Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Visible notifications when camera, microphone, or GPS connection is active"
            }
            val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.createNotificationChannel(channel)
        }
    }

    @SuppressLint("MissingPermission")
    fun postPrivacyNotification(title: String, body: String, notificationId: Int = 1001) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                appContext,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }
        try {
            val openIntent = Intent(appContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                appContext,
                notificationId,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val stopStreamsIntent = Intent(appContext, WhatsuppConnectionService::class.java).apply {
                action = WhatsuppConnectionService.ACTION_STOP_ALL_STREAMS
            }
            val pendingStopStreams = PendingIntent.getService(
                appContext,
                notificationId + 500,
                stopStreamsIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(appContext, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_whatsupp_logo)
                .setContentTitle(title)
                .setContentText(body)
                .setContentIntent(pendingIntent)
                .addAction(
                    android.R.drawable.ic_media_pause,
                    "Stop Active Streams",
                    pendingStopStreams
                )
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(appContext).notify(notificationId, notification)
        } catch (_: Exception) {
        }
    }

    fun hasUsageStatsPermission(): Boolean {
        val appOps = appContext.getSystemService(Context.APP_OPS_SERVICE) as? android.app.AppOpsManager ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                appContext.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                appContext.packageName
            )
        }
        return mode == android.app.AppOpsManager.MODE_ALLOWED
    }

    fun queryTodayUsageStats(): List<com.example.data.model.AppUsageReport> {
        if (!hasUsageStatsPermission()) return emptyList()
        val usm = appContext.getSystemService(Context.USAGE_STATS_SERVICE) as? android.app.usage.UsageStatsManager ?: return emptyList()
        val cal = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }
        val startTime = cal.timeInMillis
        val endTime = System.currentTimeMillis()
        val stats = usm.queryUsageStats(android.app.usage.UsageStatsManager.INTERVAL_DAILY, startTime, endTime) ?: return emptyList()
        val pm = appContext.packageManager
        return stats.filter { it.totalTimeInForeground > 30000L }
            .map { stat ->
                val label = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(stat.packageName, 0)).toString()
                } catch (_: Exception) {
                    stat.packageName.substringAfterLast('.')
                }
                com.example.data.model.AppUsageReport(
                    packageName = stat.packageName,
                    appName = label,
                    totalTimeMinutes = stat.totalTimeInForeground / 60000L,
                    lastUsedTimestamp = stat.lastTimeUsed
                )
            }.sortedByDescending { it.totalTimeMinutes }
    }

    fun getUsageSettingsIntent(): Intent {
        return Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
    }

    private companion object {
        const val TAG = "DeviceHardwareMgr"
        const val CHANNEL_ID = "whatsupp_privacy_alerts"
    }
}
