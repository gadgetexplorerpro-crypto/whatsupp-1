package com.example.hardware

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.auth.FamilyAuthSessionManager
import com.example.data.model.FamilyDevice
import com.example.data.repository.WhatsuppRepository
import com.example.data.security.LocalCryptoManager
import com.example.ui.WhatsuppViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Smart Background Engine & Foreground Service for Whatsupp (Android 12 through Android 16).
 *
 * - Dynamically computes permitted Android 14/15/16 ForegroundServiceTypes (`dataSync`, `location`,
 *   `microphone`, `camera`, `mediaPlayback`) based on runtime permissions and active user sessions.
 * - Provides persistent visible notifications with one-tap "Stop Streams" and "Disconnect" controls.
 * - Continues user-initiated microphone/two-way voice and eligible camera/location sessions when
 *   the app is minimized or the screen is locked, and cleanly releases/restores camera hardware
 *   when Android OS background/keyguard policies require it.
 * - Uses exponential backoff and Doze/Battery-Saver awareness to avoid battery drain.
 */
class WhatsuppConnectionService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var heartbeatJob: Job? = null
    private var backgroundCameraJob: Job? = null
    private var devicesWatchJob: Job? = null
    private var messagesWatchJob: Job? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var screenStateReceiver: BroadcastReceiver? = null

    private lateinit var hardwareManager: DeviceHardwareManager
    private var activeUserId: String? = null
    private var activePairingCode: String? = null
    private var lastHandledCommand: String = "NONE"
    private var lastPlayedAudioHash: Int = 0
    private var lastNotifiedMessageId: String = ""
    private var isMicrophoneSessionPromoted: Boolean = false
    private var isCameraSessionPromoted: Boolean = false

    override fun onCreate() {
        super.onCreate()
        hardwareManager = DeviceHardwareManager(applicationContext)
        createServiceNotificationChannel()
        registerScreenLockReceiver()
        WhatsuppSyncWorker.schedulePeriodicSync(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP_SERVICE) {
            FamilyAuthSessionManager.saveDeviceConfig(
                context = applicationContext,
                userExplicitlyStoppedService = true,
                activeCameraFacing = "OFF",
                isMicStreaming = false,
                isTwoWayVoiceActive = false,
                cameraPausedBySystem = false
            )
            WhatsuppSyncWorker.cancelAllSyncWork(applicationContext)
            stopAllActiveStreamsAndNotifyFirestore()
            stopSelfCleanly()
            return START_NOT_STICKY
        }

        if (action == ACTION_STOP_ALL_STREAMS || action == ACTION_STOP_CAMERA || action == ACTION_STOP_AUDIO) {
            handleUserStopAction(action)
        }

        val session = FamilyAuthSessionManager.init(applicationContext)
        val firebaseUser = try {
            Firebase.auth.currentUser
        } catch (_: Exception) {
            null
        }
        val resolvedUserId = session?.userId
            ?: firebaseUser?.email?.let { LocalCryptoManager.generateFamilyUserId(it) }
            ?: firebaseUser?.uid
        val resolvedEmail = session?.email ?: firebaseUser?.email ?: "Family Account"

        if (resolvedUserId.isNullOrBlank()) {
            stopSelfCleanly()
            return START_NOT_STICKY
        }

        val config = FamilyAuthSessionManager.loadDeviceConfig(
            applicationContext,
            hardwareManager.getDefaultDeviceName()
        )
        if (config.userExplicitlyStoppedService && action != ACTION_START_SERVICE && action != ACTION_HANDOFF_BACKGROUND) {
            stopSelfCleanly()
            return START_NOT_STICKY
        }

        // Track whether camera/mic sessions were explicitly promoted while user was in foreground
        if (WhatsuppViewModel.isForegroundActive || action == ACTION_START_SERVICE || action == ACTION_HANDOFF_BACKGROUND) {
            if ((config.isMicStreaming || config.isTwoWayVoiceActive) && config.micConsentGranted && hardwareManager.hasMicPermission()) {
                isMicrophoneSessionPromoted = true
            }
            if (config.activeCameraFacing != "OFF" && config.cameraConsentGranted && hardwareManager.hasCameraPermission()) {
                isCameraSessionPromoted = true
            }
        }

        val notification = buildStatusNotification(
            role = config.deviceRole,
            deviceName = config.deviceName,
            email = resolvedEmail,
            activeCameraFacing = config.activeCameraFacing,
            isMicActive = config.isMicStreaming || config.isTwoWayVoiceActive,
            isCameraPausedBySystem = config.cameraPausedBySystem
        )
        val fgType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            if (config.locationConsentGranted && hardwareManager.hasLocationPermission()) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            }
            if ((config.isMicStreaming || config.isTwoWayVoiceActive) && config.micConsentGranted && hardwareManager.hasMicPermission() && isMicrophoneSessionPromoted) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            if (config.activeCameraFacing != "OFF" && config.cameraConsentGranted && hardwareManager.hasCameraPermission() && isCameraSessionPromoted && !config.cameraPausedBySystem) {
                type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            }
            type
        } else {
            0
        }
        try {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                fgType
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start foreground service: ${e.message}", e)
        }

        val hasActiveMediaStream = config.activeCameraFacing != "OFF" || config.isMicStreaming || config.isTwoWayVoiceActive
        if (hasActiveMediaStream) {
            acquireLocksIfNeeded()
        } else {
            releaseLocks()
        }



        if (activeUserId != resolvedUserId ||
            activePairingCode != config.pairingCode ||
            heartbeatJob?.isActive != true
        ) {
            activeUserId = resolvedUserId
            activePairingCode = config.pairingCode
            startBackgroundSyncLoops(resolvedUserId)
        }

        // If the app just moved to the background, immediately hand off active mic/camera sessions
        if (action == ACTION_HANDOFF_BACKGROUND || !WhatsuppViewModel.isForegroundActive) {
            ensureBackgroundMediaSessionsRunning(resolvedUserId)
        }

        _isServiceRunning.value = true
        return START_STICKY
    }

    private fun handleUserStopAction(action: String) {
        val defaultName = hardwareManager.getDefaultDeviceName()
        val cfg = FamilyAuthSessionManager.loadDeviceConfig(applicationContext, defaultName)
        val stopCam = action == ACTION_STOP_ALL_STREAMS || action == ACTION_STOP_CAMERA
        val stopAudio = action == ACTION_STOP_ALL_STREAMS || action == ACTION_STOP_AUDIO

        if (stopCam) {
            isCameraSessionPromoted = false
            backgroundCameraJob?.cancel()
            FamilyAuthSessionManager.saveDeviceConfig(
                applicationContext,
                activeCameraFacing = "OFF",
                cameraPausedBySystem = false
            )
        }
        if (stopAudio) {
            isMicrophoneSessionPromoted = false
            hardwareManager.stopLiveAudioCapture()
            FamilyAuthSessionManager.saveDeviceConfig(
                applicationContext,
                isMicStreaming = false,
                isTwoWayVoiceActive = false
            )
        }

        _streamControlEvents.tryEmit(action)

        val userId = activeUserId ?: FamilyAuthSessionManager.init(applicationContext)?.userId
        if (!userId.isNullOrBlank()) {
            serviceScope.launch {
                try {
                    val databaseId = applicationContext.getString(R.string.firestore_database_id)
                    val db = FirebaseFirestore.getInstance(databaseId)
                    val repo = WhatsuppRepository(db, userId) { cfg.pairingCode }
                    val thisDeviceId = hardwareManager.getStableDeviceId()
                    val updates = buildMap<String, Any> {
                        if (stopCam) {
                            put("activeCameraFacing", "OFF")
                            put("latestFrameBase64", "")
                        }
                        if (stopAudio) {
                            put("isMicStreaming", false)
                            put("isTwoWayVoiceActive", false)
                            put("audioLevelDb", 0L)
                            put("latestAudioBase64", "")
                        }
                    }
                    if (updates.isNotEmpty()) {
                        repo.updateDeviceFields(thisDeviceId, updates)
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun stopAllActiveStreamsAndNotifyFirestore() {
        isCameraSessionPromoted = false
        isMicrophoneSessionPromoted = false
        backgroundCameraJob?.cancel()
        hardwareManager.stopLiveAudioCapture()
        _streamControlEvents.tryEmit(ACTION_STOP_ALL_STREAMS)
    }



    private fun buildStatusNotification(
        role: String,
        deviceName: String,
        email: String,
        activeCameraFacing: String,
        isMicActive: Boolean,
        isCameraPausedBySystem: Boolean
    ): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopStreamsIntent = Intent(this, WhatsuppConnectionService::class.java).apply {
            action = ACTION_STOP_ALL_STREAMS
        }
        val pendingStopStreams = PendingIntent.getService(
            this,
            101,
            stopStreamsIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopServiceIntent = Intent(this, WhatsuppConnectionService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val pendingStopService = PendingIntent.getService(
            this,
            102,
            stopServiceIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val roleLabel = if (role == "CONNECTED") "Connected Device" else "Main Controller"
        val activeBadges = buildList {
            if (activeCameraFacing != "OFF") {
                if (isCameraPausedBySystem) {
                    add("Cam ($activeCameraFacing Paused in BG)")
                } else {
                    add("Cam ($activeCameraFacing Live)")
                }
            }
            if (isMicActive) add("Mic/Voice Active")
        }
        val titleText = if (activeBadges.isNotEmpty()) {
            "Whatsupp • ${activeBadges.joinToString(" + ")}"
        } else {
            "Whatsupp Active • $deviceName ($roleLabel)"
        }
        val bodyText = if (isCameraPausedBySystem) {
            "Camera paused by Android lock/background policy • Reopen app to resume"
        } else if (activeBadges.isNotEmpty()) {
            "Active session on $email • Tap Stop Streams anytime"
        } else {
            "Connected as $email • Real-time sync & wakeups ready"
        }

        val builder = NotificationCompat.Builder(this, SERVICE_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_whatsupp_logo)
            .setContentTitle(titleText)
            .setContentText(bodyText)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(
                if (activeBadges.isNotEmpty()) NotificationCompat.PRIORITY_DEFAULT
                else NotificationCompat.PRIORITY_LOW
            )
            .setCategory(NotificationCompat.CATEGORY_SERVICE)

        if (activeCameraFacing != "OFF" || isMicActive) {
            builder.addAction(
                android.R.drawable.ic_media_pause,
                "Stop Streams",
                pendingStopStreams
            )
        }
        builder.addAction(
            android.R.drawable.ic_menu_close_clear_cancel,
            "Disconnect",
            pendingStopService
        )

        return builder.build()
    }

    private fun ensureBackgroundMediaSessionsRunning(userId: String) {
        val defaultName = hardwareManager.getDefaultDeviceName()
        val cfg = FamilyAuthSessionManager.loadDeviceConfig(applicationContext, defaultName)
        val thisDeviceId = hardwareManager.getStableDeviceId()

        val db = try {
            val databaseId = applicationContext.getString(R.string.firestore_database_id)
            FirebaseFirestore.getInstance(databaseId)
        } catch (_: Exception) {
            null
        } ?: return

        val repository = WhatsuppRepository(
            db = db,
            activeUserId = userId,
            pairingCodeProvider = {
                FamilyAuthSessionManager.loadDeviceConfig(applicationContext, defaultName).pairingCode
            }
        )

        // 1. Continue user-initiated Microphone / Two-Way Voice session when minimized or screen locked
        if ((cfg.isMicStreaming || cfg.isTwoWayVoiceActive) && cfg.micConsentGranted) {
            if (hardwareManager.hasMicPermission() && isMicrophoneSessionPromoted) {
                if (!hardwareManager.isAudioCaptureRunning()) {
                    hardwareManager.startLiveAudioCapture(
                        scope = serviceScope,
                        onPermissionRevoked = {
                            handleUserStopAction(ACTION_STOP_AUDIO)
                        }
                    ) { dbLevel, chunk ->
                        if (chunk.isNotEmpty()) {
                            serviceScope.launch {
                                repository.updateDeviceFields(
                                    thisDeviceId,
                                    mapOf(
                                        "isMicStreaming" to true,
                                        "isTwoWayVoiceActive" to cfg.isTwoWayVoiceActive,
                                        "audioLevelDb" to dbLevel.toLong(),
                                        "latestAudioBase64" to chunk
                                    )
                                )
                            }
                        }
                    }
                }
            } else {
                // Permission was revoked or session was not eligible
                handleUserStopAction(ACTION_STOP_AUDIO)
            }
        }

        // 2. Handle user-initiated Camera session when minimized
        if (cfg.activeCameraFacing in listOf("FRONT", "BACK") && cfg.cameraConsentGranted) {
            if (!hardwareManager.hasCameraPermission()) {
                handleUserStopAction(ACTION_STOP_CAMERA)
                return
            }
            if (hardwareManager.isDeviceScreenLocked() || !isCameraSessionPromoted) {
                pauseCameraForBackgroundRestriction(repository, thisDeviceId, cfg.deviceRole, cfg.deviceName)
                return
            }
            if (backgroundCameraJob?.isActive != true) {
                backgroundCameraJob = serviceScope.launch {
                    while (isActive && !WhatsuppViewModel.isForegroundActive) {
                        val currentCfg = FamilyAuthSessionManager.loadDeviceConfig(applicationContext, defaultName)
                        if (currentCfg.activeCameraFacing !in listOf("FRONT", "BACK") || !currentCfg.cameraConsentGranted) {
                            break
                        }
                        if (hardwareManager.isDeviceScreenLocked() || !hardwareManager.hasCameraPermission()) {
                            pauseCameraForBackgroundRestriction(
                                repository,
                                thisDeviceId,
                                currentCfg.deviceRole,
                                currentCfg.deviceName
                            )
                            break
                        }
                        val frameBase64 = hardwareManager.capturePermittedBackgroundFrameBase64(
                            facing = currentCfg.activeCameraFacing,
                            onCameraBlockedBySystem = {
                                serviceScope.launch {
                                    pauseCameraForBackgroundRestriction(
                                        repository,
                                        thisDeviceId,
                                        currentCfg.deviceRole,
                                        currentCfg.deviceName
                                    )
                                }
                            }
                        )
                        if (!frameBase64.isNullOrBlank()) {
                            repository.updateDeviceFields(
                                thisDeviceId,
                                mapOf(
                                    "activeCameraFacing" to currentCfg.activeCameraFacing,
                                    "latestFrameBase64" to frameBase64.take(300000)
                                )
                            )
                        } else {
                            // Camera capture blocked by OS background policy — exit loop cleanly and restore on foreground
                            break
                        }
                        delay(2500L)
                    }
                }
            }
        }
    }

    private fun pauseCameraForBackgroundRestriction(
        repository: WhatsuppRepository,
        thisDeviceId: String,
        role: String,
        deviceName: String
    ) {
        backgroundCameraJob?.cancel()
        FamilyAuthSessionManager.saveDeviceConfig(
            applicationContext,
            cameraPausedBySystem = true
        )

        serviceScope.launch {
            repository.logConnectionEvent(
                deviceId = thisDeviceId,
                deviceName = deviceName,
                eventType = "CAMERA_PAUSED_BG",
                details = "Camera hardware released per Android background/lock-screen policy; will auto-restore when reopened"
            )
        }
    }

    private fun startBackgroundSyncLoops(userId: String) {
        heartbeatJob?.cancel()
        devicesWatchJob?.cancel()
        messagesWatchJob?.cancel()
        hardwareManager.unregisterNetworkCallback(networkCallback)

        val db = try {
            val databaseId = applicationContext.getString(R.string.firestore_database_id)
            FirebaseFirestore.getInstance(databaseId)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize Firestore in service", e)
            return
        }

        val thisDeviceId = hardwareManager.getStableDeviceId()
        val defaultName = hardwareManager.getDefaultDeviceName()
        val repository = WhatsuppRepository(
            db = db,
            activeUserId = userId,
            pairingCodeProvider = {
                FamilyAuthSessionManager.loadDeviceConfig(applicationContext, defaultName).pairingCode
            }
        )

        // 1. Adaptive Heartbeat with Exponential Backoff & Doze-Mode Battery Optimization
        heartbeatJob = serviceScope.launch {
            var failureCount = 0
            while (isActive) {
                val success = syncDeviceStateNow(repository, userId, thisDeviceId, defaultName)
                if (success) {
                    failureCount = 0
                } else {
                    failureCount = (failureCount + 1).coerceAtMost(4)
                }

                val baseDelayMs = when {
                    hardwareManager.isPowerSaveOrDozeMode() -> 45_000L
                    !WhatsuppViewModel.isForegroundActive -> 25_000L
                    else -> 15_000L
                }
                val backoffMultiplier = 1L shl failureCount // 1x, 2x, 4x, 8x, 16x
                val nextDelayMs = (baseDelayMs * backoffMultiplier).coerceAtMost(180_000L)
                delay(nextDelayMs)
            }
        }

        // 2. Network transition listener (Wi-Fi <-> Mobile Data switching & reconnection)
        networkCallback = hardwareManager.registerNetworkTransitionCallback(
            onNetworkAvailableOrChanged = { netType ->
                serviceScope.launch {
                    val cfg = FamilyAuthSessionManager.loadDeviceConfig(applicationContext, defaultName)
                    if (cfg.autoReconnect && !cfg.userExplicitlyStoppedService) {
                        syncDeviceStateNow(repository, userId, thisDeviceId, defaultName)
                        repository.logConnectionEvent(
                            deviceId = thisDeviceId,
                            deviceName = cfg.deviceName,
                            eventType = "RECONNECTED",
                            details = "Background connection active via $netType"
                        )
                    }
                }
            },
            onNetworkLost = {
                serviceScope.launch {
                    WhatsuppSyncWorker.enqueueImmediateRecoverySync(applicationContext)
                }
            }
        )

        // 3. Observe paired devices for remote commands & incoming audio when UI is minimized/locked
        devicesWatchJob = serviceScope.launch {
            repository.observeDevices(userId)
                .catch { e -> Log.w(TAG, "Service observeDevices error: ${e.message}") }
                .collect { devices ->
                    if (WhatsuppViewModel.isForegroundActive) {
                        // Foreground ViewModel handles commands and camera preview directly when app is open
                        backgroundCameraJob?.cancel()
                        return@collect
                    }
                    val myDoc = devices.find { it.id == thisDeviceId }
                    if (myDoc != null) {
                        val cmd = myDoc.remoteCommand
                        if (cmd != "NONE" && cmd != lastHandledCommand) {
                            lastHandledCommand = cmd
                            handleBackgroundRemoteCommand(repository, thisDeviceId, cmd)
                        } else if (cmd == "NONE") {
                            lastHandledCommand = "NONE"
                        }
                    }

                    // Play incoming live audio stream even when app is in background or screen is locked
                    val otherDevices = devices.filter { it.id != thisDeviceId }
                    val remoteStreamingDevice = otherDevices.firstOrNull {
                        (it.isMicStreaming || it.isTwoWayVoiceActive) && it.latestAudioBase64.isNotBlank()
                    }
                    if (remoteStreamingDevice != null) {
                        val hash = remoteStreamingDevice.latestAudioBase64.hashCode()
                        if (hash != lastPlayedAudioHash) {
                            lastPlayedAudioHash = hash
                            hardwareManager.playIncomingPcmAudio(
                                remoteStreamingDevice.latestAudioBase64,
                                serviceScope
                            )
                        }
                    }
                }
        }

        // 4. Observe encrypted chat messages so notifications arrive when app is minimized/closed
        messagesWatchJob = serviceScope.launch {
            repository.observeMessages(userId)
                .catch { e -> Log.w(TAG, "Service observeMessages error: ${e.message}") }
                .collect { messages ->
                    val latest = messages.lastOrNull() ?: return@collect
                    if (lastNotifiedMessageId.isEmpty()) {
                        lastNotifiedMessageId = latest.id
                        return@collect
                    }
                    if (latest.id != lastNotifiedMessageId && latest.senderDeviceId != thisDeviceId) {
                        lastNotifiedMessageId = latest.id
                        hardwareManager.postPrivacyNotification(
                            title = "New Message from ${latest.senderName}",
                            body = latest.plainPreview.ifBlank { "Encrypted family message received" },
                            notificationId = 2002
                        )
                    }
                }
        }
    }

    private suspend fun syncDeviceStateNow(
        repository: WhatsuppRepository,
        userId: String,
        thisDeviceId: String,
        defaultName: String
    ): Boolean {
        return withTimeoutOrNull(10_000L) {
            try {
                val cfg = FamilyAuthSessionManager.loadDeviceConfig(applicationContext, defaultName)
                val telemetry = hardwareManager.readBatteryAndNetwork()
                if (!telemetry.isOnline) return@withTimeoutOrNull false

                val gps = if (cfg.locationConsentGranted && hardwareManager.hasLocationPermission()) {
                    hardwareManager.fetchCurrentGpsLocation()
                } else {
                    null
                }

                val existing = repository.getDeviceById(userId, thisDeviceId).getOrNull()
                if (existing == null) {
                    val newDevice = FamilyDevice(
                        id = thisDeviceId,
                        userId = userId,
                        deviceName = cfg.deviceName,
                        role = cfg.deviceRole,
                        pairingCode = cfg.pairingCode,
                        isPaired = true,
                        isOnline = telemetry.isOnline,
                        autoReconnect = cfg.autoReconnect,
                        batteryLevel = telemetry.batteryLevel.toLong(),
                        isCharging = telemetry.isCharging,
                        networkType = telemetry.networkType,
                        latitude = gps?.latitude ?: 37.4220,
                        longitude = gps?.longitude ?: -122.0841,
                        locationAccuracy = gps?.accuracy ?: 5.0,
                        locationLabel = gps?.locationLabel ?: "Connected (Background Ready)",
                        cameraConsentGranted = cfg.cameraConsentGranted,
                        micConsentGranted = cfg.micConsentGranted,
                        locationConsentGranted = cfg.locationConsentGranted,
                        activeCameraFacing = cfg.activeCameraFacing,
                        isMicStreaming = cfg.isMicStreaming,
                        isTwoWayVoiceActive = cfg.isTwoWayVoiceActive
                    )
                    repository.registerOrSyncDevice(newDevice).isSuccess
                } else {
                    val updates = buildMap<String, Any> {
                        put("deviceName", cfg.deviceName.ifBlank { existing.deviceName })
                        put("role", cfg.deviceRole)
                        put("pairingCode", cfg.pairingCode)
                        put("isPaired", true)
                        put("isOnline", telemetry.isOnline)
                        put("autoReconnect", cfg.autoReconnect)
                        put("batteryLevel", telemetry.batteryLevel.toLong())
                        put("isCharging", telemetry.isCharging)
                        put("networkType", telemetry.networkType)
                        put("cameraConsentGranted", cfg.cameraConsentGranted)
                        put("micConsentGranted", cfg.micConsentGranted)
                        put("locationConsentGranted", cfg.locationConsentGranted)
                        if (gps != null) {
                            put("latitude", gps.latitude)
                            put("longitude", gps.longitude)
                            put("locationAccuracy", gps.accuracy)
                            put("locationLabel", gps.locationLabel)
                        }
                    }
                    repository.updateDeviceFields(thisDeviceId, updates).isSuccess
                }
            } catch (_: Exception) {
                false
            }
        } ?: false
    }

    private suspend fun handleBackgroundRemoteCommand(
        repository: WhatsuppRepository,
        thisDeviceId: String,
        command: String
    ) {
        val defaultName = hardwareManager.getDefaultDeviceName()
        val cfg = FamilyAuthSessionManager.loadDeviceConfig(applicationContext, defaultName)
        when (command) {
            "RING_DEVICE" -> {
                hardwareManager.triggerDeviceRingAlert()
                hardwareManager.postPrivacyNotification(
                    "Family Device Ring Alert",
                    "Main Controller pinged this phone!",
                    notificationId = 1005
                )
            }
            "PING_LOCATION" -> if (cfg.locationConsentGranted && hardwareManager.hasLocationPermission()) {
                val gps = hardwareManager.fetchCurrentGpsLocation()
                if (gps != null) {
                    repository.updateDeviceFields(
                        thisDeviceId,
                        mapOf(
                            "latitude" to gps.latitude,
                            "longitude" to gps.longitude,
                            "locationAccuracy" to gps.accuracy,
                            "locationLabel" to gps.locationLabel,
                            "batteryLevel" to gps.batteryLevel.toLong(),
                            "isCharging" to gps.isCharging,
                            "networkType" to gps.networkType,
                            "isOnline" to true
                        )
                    )
                }
            }
            "START_MIC" -> if (cfg.micConsentGranted && hardwareManager.hasMicPermission()) {
                if (isMicrophoneSessionPromoted) {
                    FamilyAuthSessionManager.saveDeviceConfig(applicationContext, isMicStreaming = true)
                    hardwareManager.postPrivacyNotification(
                        "Live Microphone Audio Active",
                        "Main Controller started listening to live microphone audio.",
                        notificationId = 1002
                    )
                    hardwareManager.startLiveAudioCapture(
                        scope = serviceScope,
                        onPermissionRevoked = { handleUserStopAction(ACTION_STOP_AUDIO) }
                    ) { db, chunk ->
                        if (chunk.isNotEmpty()) {
                            serviceScope.launch {
                                repository.updateDeviceFields(
                                    thisDeviceId,
                                    mapOf(
                                        "isMicStreaming" to true,
                                        "audioLevelDb" to db.toLong(),
                                        "latestAudioBase64" to chunk
                                    )
                                )
                            }
                        }
                    }
                } else {
                    // Android 14–16 prohibits starting a new microphone FGS from the background without user interaction
                    FamilyAuthSessionManager.saveDeviceConfig(applicationContext, isMicStreaming = true)
                    hardwareManager.postPrivacyNotification(
                        "Live Microphone Requested",
                        "Main Controller requested live microphone audio. Tap to open Whatsupp and activate.",
                        notificationId = 1002
                    )
                }
            }
            "STOP_MIC" -> {
                handleUserStopAction(ACTION_STOP_AUDIO)
            }
            "START_VOICE" -> if (cfg.micConsentGranted && hardwareManager.hasMicPermission()) {
                if (isMicrophoneSessionPromoted) {
                    FamilyAuthSessionManager.saveDeviceConfig(
                        applicationContext,
                        isTwoWayVoiceActive = true,
                        isMicStreaming = true
                    )
                    hardwareManager.postPrivacyNotification(
                        "Two-Way Voice Intercom Active",
                        "Two-way family voice communication is active.",
                        notificationId = 1003
                    )
                    hardwareManager.startLiveAudioCapture(
                        scope = serviceScope,
                        onPermissionRevoked = { handleUserStopAction(ACTION_STOP_AUDIO) }
                    ) { db, chunk ->
                        if (chunk.isNotEmpty()) {
                            serviceScope.launch {
                                repository.updateDeviceFields(
                                    thisDeviceId,
                                    mapOf(
                                        "isTwoWayVoiceActive" to true,
                                        "isMicStreaming" to true,
                                        "audioLevelDb" to db.toLong(),
                                        "latestAudioBase64" to chunk
                                    )
                                )
                            }
                        }
                    }
                } else {
                    FamilyAuthSessionManager.saveDeviceConfig(
                        applicationContext,
                        isTwoWayVoiceActive = true,
                        isMicStreaming = true
                    )
                    hardwareManager.postPrivacyNotification(
                        "Two-Way Voice Intercom Requested",
                        "Main Controller started a voice call. Tap to open Whatsupp and join.",
                        notificationId = 1003
                    )
                }
            }
            "STOP_VOICE" -> {
                handleUserStopAction(ACTION_STOP_AUDIO)
            }
            "START_CAM_FRONT", "START_CAM_BACK" -> if (cfg.cameraConsentGranted) {
                val facing = if (command == "START_CAM_FRONT") "FRONT" else "BACK"
                FamilyAuthSessionManager.saveDeviceConfig(
                    applicationContext,
                    activeCameraFacing = facing,
                    cameraPausedBySystem = !isCameraSessionPromoted || hardwareManager.isDeviceScreenLocked()
                )
                repository.updateDeviceFields(
                    thisDeviceId,
                    mapOf("activeCameraFacing" to facing)
                )
                hardwareManager.postPrivacyNotification(
                    "Live $facing Camera Requested",
                    "Main Controller requested $facing Camera. Tap to open Whatsupp and stream live video.",
                    notificationId = 1004
                )
                if (isCameraSessionPromoted && !hardwareManager.isDeviceScreenLocked()) {
                    activeUserId?.let { ensureBackgroundMediaSessionsRunning(it) }
                }
            }
            "STOP_CAM" -> {
                handleUserStopAction(ACTION_STOP_CAMERA)
            }
        }
        repository.updateDeviceFields(thisDeviceId, mapOf("remoteCommand" to "NONE"))
    }

    private fun registerScreenLockReceiver() {
        if (screenStateReceiver != null) return
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent?) {
                val defaultName = hardwareManager.getDefaultDeviceName()
                val cfg = FamilyAuthSessionManager.loadDeviceConfig(applicationContext, defaultName)
                when (intent?.action) {
                    Intent.ACTION_SCREEN_OFF -> {
                        // Screen locked: keep ongoing audio/location alive, pause camera hardware cleanly
                        if (cfg.activeCameraFacing != "OFF") {
                            backgroundCameraJob?.cancel()
                            FamilyAuthSessionManager.saveDeviceConfig(
                                applicationContext,
                                cameraPausedBySystem = true
                            )

                        }
                    }
                    Intent.ACTION_USER_PRESENT, Intent.ACTION_SCREEN_ON -> {
                        if (!hardwareManager.isDeviceScreenLocked() && cfg.cameraPausedBySystem) {
                            _streamControlEvents.tryEmit(ACTION_RESTORE_CAMERA_IF_ELIGIBLE)
                        }
                    }
                }
            }
        }
        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            ContextCompat.registerReceiver(
                this,
                receiver,
                filter,
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            screenStateReceiver = receiver
        } catch (_: Exception) {
        }
    }

    private fun unregisterScreenLockReceiver() {
        val receiver = screenStateReceiver ?: return
        screenStateReceiver = null
        try {
            unregisterReceiver(receiver)
        } catch (_: Exception) {
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // C. App removed from recent tasks: schedule WorkManager sync; do not illegally force-restart
        val session = FamilyAuthSessionManager.init(applicationContext)
        val cfg = FamilyAuthSessionManager.loadDeviceConfig(
            applicationContext,
            hardwareManager.getDefaultDeviceName()
        )
        if (session != null && !cfg.userExplicitlyStoppedService && (cfg.keepConnectedWhenClosed || cfg.autoReconnect)) {
            WhatsuppSyncWorker.schedulePeriodicSync(applicationContext)
            WhatsuppSyncWorker.enqueueImmediateRecoverySync(applicationContext)
        } else {
            stopSelfCleanly()
        }
    }

    override fun onDestroy() {
        _isServiceRunning.value = false
        releaseLocks()
        unregisterScreenLockReceiver()
        hardwareManager.unregisterNetworkCallback(networkCallback)
        backgroundCameraJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()

        val session = FamilyAuthSessionManager.init(applicationContext)
        val cfg = FamilyAuthSessionManager.loadDeviceConfig(
            applicationContext,
            if (::hardwareManager.isInitialized) hardwareManager.getDefaultDeviceName() else "Android Phone"
        )
        if (session != null && !cfg.userExplicitlyStoppedService && (cfg.keepConnectedWhenClosed || cfg.autoReconnect)) {
            WhatsuppSyncWorker.schedulePeriodicSync(applicationContext)
        }
    }

    private fun stopSelfCleanly() {
        _isServiceRunning.value = false
        releaseLocks()
        unregisterScreenLockReceiver()
        backgroundCameraJob?.cancel()
        hardwareManager.stopLiveAudioCapture()
        hardwareManager.unregisterNetworkCallback(networkCallback)
        heartbeatJob?.cancel()
        devicesWatchJob?.cancel()
        messagesWatchJob?.cancel()
        try {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {
        }
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.cancel(NOTIFICATION_ID)
        } catch (_: Exception) {
        }
        stopSelf()
    }

    private fun acquireLocksIfNeeded() {
        try {
            if (wakeLock?.isHeld != true) {
                val pm = applicationContext.getSystemService(Context.POWER_SERVICE) as? PowerManager
                wakeLock = pm?.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "Whatsupp:ActiveSessionWakeLock"
                )?.apply {
                    setReferenceCounted(false)
                    acquire(30 * 60 * 1000L) // 30-minute bounded lock for active audio/camera streams only
                }
            }
        } catch (_: Exception) {
        }
        try {
            if (wifiLock?.isHeld != true) {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                @Suppress("DEPRECATION")
                val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                } else {
                    WifiManager.WIFI_MODE_FULL_HIGH_PERF
                }
                wifiLock = wm?.createWifiLock(lockMode, "Whatsupp:ActiveSessionWifiLock")?.apply {
                    setReferenceCounted(false)
                    acquire()
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun releaseLocks() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        try {
            if (wifiLock?.isHeld == true) wifiLock?.release()
        } catch (_: Exception) {
        }
    }

    private fun createServiceNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                SERVICE_CHANNEL_ID,
                "Whatsupp Persistent Device Connection",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps family device paired and connected with visible stop controls"
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "WhatsuppConnService"
        private const val SERVICE_CHANNEL_ID = "whatsupp_persistent_service"
        private const val NOTIFICATION_ID = 1010
        const val ACTION_START_SERVICE = "com.example.action.START_CONNECTION_SERVICE"
        const val ACTION_HANDOFF_BACKGROUND = "com.example.action.HANDOFF_BACKGROUND"
        const val ACTION_STOP_SERVICE = "com.example.action.STOP_CONNECTION_SERVICE"
        const val ACTION_STOP_ALL_STREAMS = "com.example.action.STOP_ALL_STREAMS"
        const val ACTION_STOP_CAMERA = "com.example.action.STOP_CAMERA_STREAM"
        const val ACTION_STOP_AUDIO = "com.example.action.STOP_AUDIO_STREAM"
        const val ACTION_RESTORE_CAMERA_IF_ELIGIBLE = "com.example.action.RESTORE_CAMERA_IF_ELIGIBLE"

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

        private val _streamControlEvents = MutableStateFlow("NONE")
        val streamControlEvents: StateFlow<String> = _streamControlEvents.asStateFlow()

        fun clearStreamControlEvent() {
            _streamControlEvents.value = "NONE"
        }

        fun start(context: Context, isBackgroundHandoff: Boolean = false) {
            val appContext = context.applicationContext
            FamilyAuthSessionManager.saveDeviceConfig(
                context = appContext,
                userExplicitlyStoppedService = false
            )
            WhatsuppSyncWorker.schedulePeriodicSync(appContext)
            val intent = Intent(appContext, WhatsuppConnectionService::class.java).apply {
                action = if (isBackgroundHandoff) ACTION_HANDOFF_BACKGROUND else ACTION_START_SERVICE
            }
            try {
                appContext.startService(intent)
            } catch (e: Exception) {
                Log.w(TAG, "Service start deferred to WorkManager due to OS background restriction: ${e.message}")
                WhatsuppSyncWorker.enqueueImmediateRecoverySync(appContext)
            }
        }

        fun stop(context: Context) {
            val appContext = context.applicationContext
            FamilyAuthSessionManager.saveDeviceConfig(
                context = appContext,
                userExplicitlyStoppedService = true
            )
            WhatsuppSyncWorker.cancelAllSyncWork(appContext)
            try {
                val stopIntent = Intent(appContext, WhatsuppConnectionService::class.java).apply {
                    action = ACTION_STOP_SERVICE
                }
                appContext.startService(stopIntent)
            } catch (_: Exception) {
                try {
                    appContext.stopService(Intent(appContext, WhatsuppConnectionService::class.java))
                } catch (_: Exception) {
                }
            }
        }
    }
}

/**
 * BroadcastReceiver for `BOOT_COMPLETED`, `MY_PACKAGE_REPLACED`, and recovery intents.
 *
 * Strictly complies with Android 14, 15, and 16 `BOOT_COMPLETED` restrictions:
 * never attempts to start `camera` or `microphone` foreground services from boot!
 * Instead, schedules WorkManager periodic + immediate sync and resets stale media flags.
 */
class WhatsuppConnectionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val appContext = context.applicationContext
        val session = FamilyAuthSessionManager.init(appContext) ?: return
        val hardwareManager = DeviceHardwareManager(appContext)
        val cfg = FamilyAuthSessionManager.loadDeviceConfig(
            appContext,
            hardwareManager.getDefaultDeviceName()
        )

        if (cfg.userExplicitlyStoppedService) {
            return
        }

        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            // F. Phone restarted: clear stale camera/mic flags because Android 14–16 prohibits
            // starting camera/microphone foreground services from BOOT_COMPLETED without user interaction.
            FamilyAuthSessionManager.saveDeviceConfig(
                context = appContext,
                activeCameraFacing = "OFF",
                isMicStreaming = false,
                isTwoWayVoiceActive = false,
                cameraPausedBySystem = false
            )
        }

        if (cfg.keepConnectedWhenClosed || cfg.autoReconnect) {
            WhatsuppSyncWorker.schedulePeriodicSync(appContext)
            WhatsuppSyncWorker.enqueueImmediateRecoverySync(appContext)
            // Only start service if allowed by the current Android version
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE &&
                intent?.action != Intent.ACTION_BOOT_COMPLETED
            ) {
                WhatsuppConnectionService.start(appContext)
            }
        }
    }

    companion object {
        const val ACTION_RESTART_CONNECTION = "com.example.action.RESTART_WHATSUPP_CONNECTION"
    }
}
