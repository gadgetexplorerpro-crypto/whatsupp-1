package com.example.hardware

import android.content.Context
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.R
import com.example.data.auth.FamilyAuthSessionManager
import com.example.data.model.FamilyDevice
import com.example.data.repository.WhatsuppRepository
import com.example.data.security.LocalCryptoManager
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.concurrent.TimeUnit

/**
 * WorkManager worker for battery-efficient, Doze-compliant deferred telemetry synchronization,
 * heartbeat recovery, and post-reboot / post-network-outage session restoration.
 */
class WhatsuppSyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val session = FamilyAuthSessionManager.init(applicationContext)
        val firebaseUser = try {
            Firebase.auth.currentUser
        } catch (_: Exception) {
            null
        }
        val userId = session?.userId
            ?: firebaseUser?.email?.let { LocalCryptoManager.generateFamilyUserId(it) }
            ?: firebaseUser?.uid

        if (userId.isNullOrBlank()) {
            return Result.success()
        }

        val hardwareManager = DeviceHardwareManager(applicationContext)
        val defaultName = hardwareManager.getDefaultDeviceName()
        val cfg = FamilyAuthSessionManager.loadDeviceConfig(applicationContext, defaultName)

        // Respect user explicit stop or disabled background connection
        if (cfg.userExplicitlyStoppedService || (!cfg.keepConnectedWhenClosed && !cfg.autoReconnect)) {
            return Result.success()
        }

        return try {
            val databaseId = applicationContext.getString(R.string.firestore_database_id)
            val db = FirebaseFirestore.getInstance(databaseId)
            val repository = WhatsuppRepository(
                db = db,
                activeUserId = userId,
                pairingCodeProvider = { cfg.pairingCode }
            )
            val thisDeviceId = hardwareManager.getStableDeviceId()
            val telemetry = hardwareManager.readBatteryAndNetwork()
            val gps = if (cfg.locationConsentGranted && hardwareManager.hasLocationPermission()) {
                hardwareManager.fetchCurrentGpsLocation()
            } else {
                null
            }

            val existing = repository.getDeviceById(userId, thisDeviceId).getOrNull()
            if (existing == null) {
                repository.registerOrSyncDevice(
                    FamilyDevice(
                        id = thisDeviceId,
                        userId = userId,
                        deviceName = cfg.deviceName,
                        role = cfg.deviceRole,
                        pairingCode = cfg.pairingCode,
                        isPaired = true,
                        isOnline = telemetry.isOnline,
                        autoReconnect = cfg.autoReconnect,
                        batteryLevel = telemetry.batteryLevel.toLong(),
                        isCharging = telemetry.isCharging,
                        networkType = telemetry.networkType,
                        latitude = gps?.latitude ?: 37.4220,
                        longitude = gps?.longitude ?: -122.0841,
                        locationAccuracy = gps?.accuracy ?: 5.0,
                        locationLabel = gps?.locationLabel ?: "Connected (WorkManager Sync)",
                        cameraConsentGranted = cfg.cameraConsentGranted,
                        micConsentGranted = cfg.micConsentGranted,
                        locationConsentGranted = cfg.locationConsentGranted
                    )
                )
            } else {
                val updates = buildMap<String, Any> {
                    put("deviceName", cfg.deviceName.ifBlank { existing.deviceName })
                    put("role", cfg.deviceRole)
                    put("pairingCode", cfg.pairingCode)
                    put("isPaired", true)
                    put("isOnline", telemetry.isOnline)
                    put("autoReconnect", cfg.autoReconnect)
                    put("batteryLevel", telemetry.batteryLevel.toLong())
                    put("isCharging", telemetry.isCharging)
                    put("networkType", telemetry.networkType)
                    if (gps != null) {
                        put("latitude", gps.latitude)
                        put("longitude", gps.longitude)
                        put("locationAccuracy", gps.accuracy)
                        put("locationLabel", gps.locationLabel)
                    }
                }
                repository.updateDeviceFields(thisDeviceId, updates)
            }
            Result.success()
        } catch (e: Exception) {
            Log.w(TAG, "WorkManager sync transient failure, scheduling retry: ${e.message}")
            if (runAttemptCount < 4) Result.retry() else Result.success()
        }
    }

    companion object {
        private const val TAG = "WhatsuppSyncWorker"
        const val PERIODIC_WORK_NAME = "whatsupp_periodic_health_sync"
        const val IMMEDIATE_WORK_NAME = "whatsupp_immediate_recovery_sync"

        fun schedulePeriodicSync(context: Context) {
            try {
                val constraints = Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build()

                val periodicRequest = PeriodicWorkRequestBuilder<WhatsuppSyncWorker>(
                    15, TimeUnit.MINUTES
                )
                    .setConstraints(constraints)
                    .setBackoffCriteria(
                        BackoffPolicy.EXPONENTIAL,
                        30,
                        TimeUnit.SECONDS
                    )
                    .build()

                WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
                    PERIODIC_WORK_NAME,
                    ExistingPeriodicWorkPolicy.KEEP,
                    periodicRequest
                )
            } catch (e: Exception) {
                Log.w(TAG, "WorkManager periodic schedule skipped: ${e.message}")
            }
        }

        fun enqueueImmediateRecoverySync(context: Context) {
            try {
                val constraints = Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build()

                val oneTimeRequest = OneTimeWorkRequestBuilder<WhatsuppSyncWorker>()
                    .setConstraints(constraints)
                    .setBackoffCriteria(
                        BackoffPolicy.EXPONENTIAL,
                        15,
                        TimeUnit.SECONDS
                    )
                    .build()

                WorkManager.getInstance(context.applicationContext).enqueueUniqueWork(
                    IMMEDIATE_WORK_NAME,
                    ExistingWorkPolicy.KEEP,
                    oneTimeRequest
                )
            } catch (e: Exception) {
                Log.w(TAG, "WorkManager immediate sync skipped: ${e.message}")
            }
        }

        fun cancelAllSyncWork(context: Context) {
            try {
                val wm = WorkManager.getInstance(context.applicationContext)
                wm.cancelUniqueWork(PERIODIC_WORK_NAME)
                wm.cancelUniqueWork(IMMEDIATE_WORK_NAME)
            } catch (_: Exception) {
            }
        }
    }
}
