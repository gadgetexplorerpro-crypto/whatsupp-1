package com.example

import android.Manifest
import android.app.Application
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.unit.Density
import androidx.test.core.app.ApplicationProvider
import androidx.work.NetworkType
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.testing.WorkManagerTestInitHelper
import com.example.data.auth.EmailAuthResult
import com.example.data.auth.FamilyAuthSessionManager
import com.example.data.model.FamilyDevice
import com.example.data.model.SavedPlace
import com.example.data.security.LocalCryptoManager
import com.example.hardware.DeviceHardwareManager
import com.example.hardware.WhatsuppConnectionReceiver
import com.example.hardware.WhatsuppConnectionService
import com.example.hardware.WhatsuppSyncWorker
import com.example.ui.LocalDashboardState
import com.example.ui.UiState
import com.example.ui.WhatsuppViewModel
import com.example.ui.screens.DevicesDashboardTab
import com.example.ui.screens.EncryptedChatVaultTab
import com.example.ui.screens.FamilyHomeDashboardTab
import com.example.ui.screens.LiveGpsMapTab
import com.example.ui.theme.WhatsuppTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private lateinit var context: Context

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        WorkManagerTestInitHelper.initializeTestWorkManager(context)
    }

    @Test
    fun `read string from context and verify AES-256-GCM local encryption`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("Whatsupp", appName)

        val secretMsg = "Family Connected Device GPS: 37.4220, -122.0841"
        val encrypted = LocalCryptoManager.encrypt(secretMsg, "family_uid_123")
        val decrypted = LocalCryptoManager.decrypt(encrypted, "family_uid_123")
        assertEquals(secretMsg, decrypted)
    }

    @Test
    fun `google sign in and email auth produce identical family userId and persist across restarts`() {
        FamilyAuthSessionManager.clearSession(context)

        val googleSession = FamilyAuthSessionManager.saveGoogleAccountAndSession(
            context = context,
            googleEmail = "gadgetexplorerpro@gmail.com",
            displayName = "Gadget Explorer"
        )
        assertTrue(googleSession.userId.startsWith("fam_"))
        assertEquals("gadgetexplorerpro@gmail.com", googleSession.email)

        val emailAuth = FamilyAuthSessionManager.authenticateEmailAndPassword(
            context = context,
            email = "gadgetexplorerpro@gmail.com",
            password = "password123",
            isSignUpMode = true
        )
        assertTrue(emailAuth is EmailAuthResult.Success)
        val emailSession = (emailAuth as EmailAuthResult.Success).session
        assertEquals(googleSession.userId, emailSession.userId)

        val restored = FamilyAuthSessionManager.init(context)
        assertNotNull(restored)
        assertEquals(googleSession.userId, restored?.userId)
    }

    @Test
    fun `app minimized and screen locked preserve eligible sessions and auto-pause camera on keyguard`() {
        val app = context as Application
        val shadowApp = shadowOf(app)
        shadowApp.grantPermissions(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.POST_NOTIFICATIONS
        )

        FamilyAuthSessionManager.saveGoogleAccountAndSession(
            context = context,
            googleEmail = "family@gmail.com"
        )
        WhatsuppViewModel.isForegroundActive = true
        FamilyAuthSessionManager.saveDeviceConfig(
            context = context,
            deviceRole = "CONNECTED",
            deviceName = "Family Phone 2",
            pairingCode = "654321",
            cameraConsentGranted = true,
            micConsentGranted = true,
            locationConsentGranted = true,
            activeCameraFacing = "BACK",
            isMicStreaming = true,
            isTwoWayVoiceActive = true,
            autoReconnect = true,
            keepConnectedWhenClosed = true,
            userExplicitlyStoppedService = false
        )

        val serviceController = Robolectric.buildService(
            WhatsuppConnectionService::class.java,
            Intent(context, WhatsuppConnectionService::class.java).apply {
                action = WhatsuppConnectionService.ACTION_START_SERVICE
            }
        ).create().startCommand(0, 1)
        val service = serviceController.get()

        // 1. Simulate minimizing the app
        WhatsuppViewModel.isForegroundActive = false
        service.onStartCommand(
            Intent(context, WhatsuppConnectionService::class.java).apply {
                action = WhatsuppConnectionService.ACTION_HANDOFF_BACKGROUND
            },
            0,
            2
        )
        val minimizedCfg = FamilyAuthSessionManager.loadDeviceConfig(context, "Default")
        assertEquals("BACK", minimizedCfg.activeCameraFacing)
        assertTrue(minimizedCfg.isMicStreaming)
        assertTrue(minimizedCfg.isTwoWayVoiceActive)

        // 2. Simulate locking the screen (Keyguard locked)
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        shadowOf(km).setKeyguardLocked(true)
        val hardwareManager = DeviceHardwareManager(context)
        assertTrue(hardwareManager.isDeviceScreenLocked())

        // 3. Unlock screen
        shadowOf(km).setKeyguardLocked(false)
        assertFalse(hardwareManager.isDeviceScreenLocked())
        serviceController.destroy()
    }

    @Test
    fun `service initialization and stop actions respect user preferences`() {
        FamilyAuthSessionManager.saveGoogleAccountAndSession(context, "family@gmail.com")
        val serviceController = Robolectric.buildService(WhatsuppConnectionService::class.java).create()
        val service = serviceController.get()
        assertNotNull(service)
        serviceController.destroy()
    }

    @Test
    fun `notification stop controls and explicit stop service respect user termination and boot restrictions`() {
        FamilyAuthSessionManager.saveGoogleAccountAndSession(context, "family@gmail.com")
        FamilyAuthSessionManager.saveDeviceConfig(
            context = context,
            activeCameraFacing = "FRONT",
            isMicStreaming = true,
            isTwoWayVoiceActive = true,
            userExplicitlyStoppedService = false
        )

        val serviceController = Robolectric.buildService(WhatsuppConnectionService::class.java).create()
        val service = serviceController.get()

        // 1. Test ACTION_STOP_ALL_STREAMS stops camera and audio immediately
        service.onStartCommand(
            Intent(context, WhatsuppConnectionService::class.java).apply {
                action = WhatsuppConnectionService.ACTION_STOP_ALL_STREAMS
            },
            0,
            1
        )
        val afterStopStreams = FamilyAuthSessionManager.loadDeviceConfig(context, "Phone")
        assertEquals("OFF", afterStopStreams.activeCameraFacing)
        assertFalse(afterStopStreams.isMicStreaming)
        assertFalse(afterStopStreams.isTwoWayVoiceActive)
        assertFalse(afterStopStreams.userExplicitlyStoppedService)

        // 2. Test ACTION_BOOT_COMPLETED receiver clears stale camera/mic flags per Android 14-16 boot policy
        FamilyAuthSessionManager.saveDeviceConfig(
            context = context,
            activeCameraFacing = "BACK",
            isMicStreaming = true
        )
        val receiver = WhatsuppConnectionReceiver()
        receiver.onReceive(context, Intent(Intent.ACTION_BOOT_COMPLETED))
        val afterBoot = FamilyAuthSessionManager.loadDeviceConfig(context, "Phone")
        assertEquals("OFF", afterBoot.activeCameraFacing)
        assertFalse(afterBoot.isMicStreaming)

        // 3. Test ACTION_STOP_SERVICE marks userExplicitlyStoppedService = true
        service.onStartCommand(
            Intent(context, WhatsuppConnectionService::class.java).apply {
                action = WhatsuppConnectionService.ACTION_STOP_SERVICE
            },
            0,
            2
        )
        val afterExplicitStop = FamilyAuthSessionManager.loadDeviceConfig(context, "Phone")
        assertTrue(afterExplicitStop.userExplicitlyStoppedService)
        serviceController.destroy()
    }

    @Test
    fun `workManager schedules periodic and immediate recovery sync with network connected constraint`() {
        WhatsuppSyncWorker.schedulePeriodicSync(context)
        WhatsuppSyncWorker.enqueueImmediateRecoverySync(context)

        val wm = WorkManager.getInstance(context)
        val periodicInfos = wm.getWorkInfosForUniqueWork(WhatsuppSyncWorker.PERIODIC_WORK_NAME).get()
        assertTrue(periodicInfos.isNotEmpty())
        assertEquals(NetworkType.CONNECTED, periodicInfos.first().constraints.requiredNetworkType)

        val immediateInfos = wm.getWorkInfosForUniqueWork(WhatsuppSyncWorker.IMMEDIATE_WORK_NAME).get()
        assertTrue(immediateInfos.isNotEmpty())
        assertTrue(
            immediateInfos.first().state == WorkInfo.State.ENQUEUED ||
                immediateInfos.first().state == WorkInfo.State.RUNNING ||
                immediateInfos.first().state == WorkInfo.State.SUCCEEDED
        )
    }

    @Test
    @Config(qualifiers = "w320dp-h640dp-port")
    fun `320dp small screen and 1_3x font scale render Home and Devices actions cleanly and respond to clicks`() {
        var openedDevices = false
        var navigatedTab = -1
        val sampleDevice = FamilyDevice(
            id = "dev_remote_1",
            userId = "fam_test",
            deviceName = "Child Galaxy S24",
            role = "CONNECTED",
            isOnline = true,
            batteryLevel = 88
        )
        val localState = LocalDashboardState(
            thisDeviceId = "dev_local_0",
            thisDeviceName = "Parent Pixel",
            thisDeviceRole = "CONTROLLER",
            selectedTargetDeviceId = "dev_remote_1"
        )

        composeTestRule.setContent {
            val baseDensity = LocalDensity.current
            CompositionLocalProvider(
                LocalDensity provides Density(density = baseDensity.density, fontScale = 1.3f)
            ) {
                WhatsuppTheme(darkTheme = false) {
                    FamilyHomeDashboardTab(
                        localState = localState,
                        devicesState = UiState.Success(listOf(sampleDevice)),
                        safetyAlerts = emptyList(),
                        historyEvents = UiState.Success(emptyList()),
                        onOpenLiveCamera = { navigatedTab = 5 },
                        onOpenLiveVoice = { navigatedTab = 6 },
                        onOpenGpsMap = { navigatedTab = 2 },
                        onOpenChat = { navigatedTab = 7 },
                        onOpenDevicesTab = { openedDevices = true },
                        onOpenSafetyTab = { navigatedTab = 3 },
                        onTriggerSos = {},
                        onDismissSos = {},
                        onRingDevice = {},
                        onSelectTargetDevice = {}
                    )
                }
            }
        }

        composeTestRule.onNodeWithTag("home_sos_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("home_manage_devices_button").assertIsDisplayed().performClick()
        assertTrue(openedDevices)
        composeTestRule.onNodeWithTag("home_quick_camera").assertIsDisplayed().performClick()
        assertEquals(5, navigatedTab)
    }

    @Test
    @Config(qualifiers = "w360dp-h740dp-port")
    fun `360dp viewport PairedDeviceCard 2x2 action grid and Chat input strip work properly`() {
        var actionTab = -1
        val sampleDevice = FamilyDevice(
            id = "dev_remote_2",
            userId = "fam_test",
            deviceName = "Kitchen Tablet",
            role = "CONNECTED",
            isOnline = true,
            batteryLevel = 94
        )
        val localState = LocalDashboardState(
            thisDeviceId = "dev_local_0",
            thisDeviceName = "Controller Phone",
            thisDeviceRole = "CONTROLLER",
            selectedTargetDeviceId = "dev_remote_2"
        )

        composeTestRule.setContent {
            WhatsuppTheme(darkTheme = true) {
                DevicesDashboardTab(
                    localState = localState,
                    devicesState = UiState.Success(listOf(sampleDevice)),
                    historyState = UiState.Success(emptyList()),
                    onSwitchRole = {},
                    onUpdateDeviceName = {},
                    onCompletePairing = {},
                    onSelectTargetDevice = {},
                    onUpdateConsent = { _, _, _ -> },
                    onToggleAutoReconnect = {},
                    onSendRemoteCommand = {},
                    onRequestPermissions = {},
                    onNavigateToTab = { actionTab = it }
                )
            }
        }

        composeTestRule.onNodeWithTag("action_camera_dev_remote_2").assertIsDisplayed().performClick()
        assertEquals(1, actionTab)
        composeTestRule.onNodeWithTag("action_location_dev_remote_2").assertIsDisplayed().performClick()
        assertEquals(3, actionTab)
    }

    @Test
    @Config(qualifiers = "w393dp-h851dp-port")
    fun `393dp and 412dp viewports GPS Saved Places and Chat attachment buttons trigger callbacks`() {
        var voiceNoteTriggered = false
        val localState = LocalDashboardState(
            thisDeviceId = "dev_local_0",
            thisDeviceName = "Parent Phone",
            latitude = 37.4220,
            longitude = -122.0841,
            locationAccuracy = 8.0
        )

        composeTestRule.setContent {
            WhatsuppTheme(darkTheme = false) {
                EncryptedChatVaultTab(
                    localState = localState,
                    messagesState = UiState.Success(emptyList()),
                    savedVaultMedia = emptyList(),
                    currentUserId = "fam_test",
                    onSendTextMessage = {},
                    onSendVoiceNote = { voiceNoteTriggered = true },
                    onShareLocationPin = {},
                    onDeleteSavedMedia = {}
                )
            }
        }

        composeTestRule.onNodeWithTag("chat_voice_note_button").assertIsDisplayed().performClick()
        assertTrue(voiceNoteTriggered)
        composeTestRule.onNodeWithTag("chat_text_input").assertIsDisplayed()
    }
}
